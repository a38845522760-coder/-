# All Bat — سورس اندروید سازگار با GitHub Actions

این بسته دقیقاً برای Workflow موجود در مخزن `a38845522760-coder/-` آماده شده است.

## ساختار ZIP

محتویات پروژه داخل پوشهٔ `all-bat-android/` قرار دارد؛ چون Workflow ابتدا همین پوشه را از ZIP استخراج می‌کند و سپس فایل‌های آن را در ریشهٔ مخزن کپی می‌کند.

فایل `.github/workflows/build-apk.yml` عمداً داخل ZIP نیست. نسخهٔ Workflow باید در ریشهٔ مخزن باقی بماند و با استخراج سورس اندروید بازنویسی نشود.

## چه کاری در GitHub Actions انجام می‌شود؟

Workflow فعلی مخزن:

1. ZIP را استخراج می‌کند و وجود `app/build.gradle.kts` و `scripts/prepare_web_assets.py` را بررسی می‌کند.
2. رابط فعلی Hugging Face را دریافت و پل Native اندروید را به آن اضافه می‌کند.
3. با Java 17، Android SDK 35 و Gradle 8.9 نسخهٔ Debug را می‌سازد.
4. فایل `app-debug.apk` را با نام Artifact به‌صورت `all-bat-debug-apk` بارگذاری می‌کند؛ Artifact به مدت ۱۴ روز نگه داشته می‌شود.

## دربارهٔ بروزرسانی درون‌برنامه‌ای

کد Android شامل بررسی نسخهٔ جدید از GitHub Releases، دریافت APK، کنترل SHA-256، کنترل نام بسته و امضای APK، و سپردن نصب به نصب‌کنندهٔ رسمی Android است.

اما Workflow فعلی فقط `assembleDebug` اجرا می‌کند و APK را به‌صورت Artifact ذخیره می‌کند؛ این Workflow یک GitHub Release شامل `AllBat.apk` و `update.json` منتشر نمی‌کند. بنابراین قابلیت بررسی/نصب خودکار نسخه‌های بعدی تا زمانی که Workflow انتشار Release امضاشده اضافه نشود، فعال نمی‌شود.

برای انتشار واقعی بروزرسانی، نسخهٔ Release باید با همان keystore و alias نسخهٔ نصب‌شده امضا شود. Secrets موردنیاز کد Release عبارت‌اند از:

- `ALLBAT_KEYSTORE_BASE64`
- `ALLBAT_KEYSTORE_PASSWORD`
- `ALLBAT_KEY_ALIAS`
- `ALLBAT_SIGNING_CERT_SHA256`

کلید و رمز keystore را در سورس یا ZIP قرار نده. نسخه‌هایی که قبلاً با package name یا گواهی امضای دیگری ساخته شده‌اند، با این برنامه قابل جایگزینی نیستند.

## مخزن بروزرسانی

مقدار پیش‌فرض مخزن بروزرسانی روی `a38845522760-coder/-` تنظیم شده است. در GitHub Actions نیز مقدار `GITHUB_REPOSITORY` به‌صورت خودکار همین مخزن اجراکننده را به برنامه می‌دهد.

## بررسی‌های محلی

از ریشهٔ پروژه اجرا کن:

```bash
python -m py_compile scripts/prepare_web_assets.py scripts/validate_device_tool_contract.py scripts/validate_update_contract.py
node --check app/src/main/assets/native-bridge.js
node --check app/src/main/assets/fb-widget.js
node scripts/test_device_command_parser.js
python scripts/validate_device_tool_contract.py
python scripts/validate_update_contract.py
```

ساخت APK واقعی همچنان در GitHub Actions انجام می‌شود و به دسترسی شبکه به Hugging Face و Android SDK نیاز دارد.
