# All Bat Android — version 1.2.0

This bundle is the Android-native wrapper for the existing All Bat / Gemini web experience. It keeps the model API credentials on the server; no API key is embedded in the Android source.

## What changed in 1.2.0

- Added a movable, floating assistant orb for an explicitly started Live voice session. Tapping it opens a compact white/blue assistant panel; it can be collapsed without ending the conversation.
- Added native overlay controls for microphone mute, live camera, screen sharing, minimize, end-session, and read-aloud for the latest response. Selected controls use a pale-blue active state.
- Added live transcript/status updates so the floating panel can show the latest user utterance, assistant response, and a “Just a sec…” processing state.
- Added the system assistant’s compact bottom-sheet layout and updated the Home/default-assistant panel to reuse the existing chat rather than showing only a banner.
- Added Android’s explicit “Display over other apps” permission flow. If permission is denied, the normal in-app voice experience remains available but Android will not display the floating orb.
- Incremented Android `versionCode` to 3 and `versionName` to 1.2.0 to allow updating an installed 1.1.0 build without uninstalling it.

## Build through the repository workflow

The repository workflow expects this archive to be located at the repository root as `all-bat-android-source.zip`. Upload/replace that ZIP on the `main` branch to trigger the workflow. After a successful run, open **Actions → Build All Bat APK → Artifacts** and download `all-bat-debug-apk`.

## Important Android behavior

- Android controls whether the assistant session receives a screenshot. Secure windows, user privacy settings, device policy, or unsupported system behavior may result in no screenshot. In that case the UI reports that the screenshot is unavailable and does not substitute a full-screen capture.
- Android requires user approval for every MediaProjection session. Screen sharing cannot start silently.
- Camera, microphone, assistant-role, and notification permissions are governed by Android. The Home assistant panel does not start the microphone automatically.
- Actual APK compilation and device runtime behavior must be confirmed by the repository's GitHub Actions run and then tested on the target phone.

## Wake phrase status

“Hey Digi” is not enabled in this build. Android’s system hotword path is not generally available to ordinary apps on every device. A software wake-phrase listener would need an explicit opt-in, continuous microphone foreground service and notification, with additional battery/privacy implications; it should be implemented and device-tested separately rather than advertised as reliable before testing.
