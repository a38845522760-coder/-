#!/usr/bin/env node
'use strict';

const fs = require('fs');
const vm = require('vm');
const path = require('path');
const sourcePath = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'native-bridge.js');
const source = fs.readFileSync(sourcePath, 'utf8');
const start = source.indexOf('function parseOfflineDeviceCommand(raw) {');
const endMarker = '\n  }\n\n  async function runOfflineCommands';
const end = source.indexOf(endMarker, start);
if (start < 0 || end < 0) throw new Error('Could not isolate parseOfflineDeviceCommand from native-bridge.js');
const parserSource = source.slice(start, end + '\n  }'.length);

const context = {
  normalizeFa(value) {
    return String(value || '')
      .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - 0x06f0))
      .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))
      .replace(/ي/g, 'ی').replace(/ك/g, 'ک')
      .replace(/[\u200c\u200f\u200e]/g, ' ')
      .toLowerCase().replace(/[،؛,:!?؟.]+/g, ' ').replace(/\s+/g, ' ').trim();
  },
  replaceNumberWordsFa: value => value,
  localCalcFa: () => null,
  parseExtraOfflineCommand: () => null,
  cleanTargetFa: value => String(value || '')
    .replace(/^(?:آقای|اقای|خانم|دکتر)\s+/, '')
    .replace(/\s+عزیز$/, '').trim()
};
vm.createContext(context);
const extraStart = source.indexOf('function parseExtraOfflineCommand(t) {');
const extraEndMarker = '\n  }\n\n  // Returns [{ name, args }]';
const extraEnd = source.indexOf(extraEndMarker, extraStart);
if (extraStart < 0 || extraEnd < 0) throw new Error('Could not isolate parseExtraOfflineCommand');
vm.runInContext(source.slice(extraStart, extraEnd + '\n  }'.length), context);
vm.runInContext(parserSource, context);

const callCases = [
  ['با علی تماس بگیر', 'علی'],
  ['به علی زنگ بزن', 'علی'],
  ['تماس بگیر با علی', 'علی'],
  ['زنگ بزن به علی رضایی', 'علی رضایی'],
  ['علی رو تماس بگیر', 'علی'],
  ['تلفن کن با علی', 'علی'],
  ['Call contact Ali', 'ali']
];
for (const [input, expectedName] of callCases) {
  const result = context.parseOfflineDeviceCommand(input);
  if (!result || result.length !== 1 || result[0].name !== 'call_contact' || result[0].args.name !== expectedName) {
    throw new Error(`Call command parser failed for "${input}": ${JSON.stringify(result)}`);
  }
  process.stdout.write(`PASS ${input}\n`);
}

const nonAction = context.parseOfflineDeviceCommand('آیا می‌توانی با علی تماس بگیری؟');
if (nonAction !== null) throw new Error(`A question was incorrectly treated as a call command: ${JSON.stringify(nonAction)}`);
process.stdout.write('PASS natural-language question falls back to Gemini\n');

const featureCases = [
  ['یادداشت کن فردا کتاب را پس بدهم', 'save_note'],
  ['یادداشت های من رو لیست کن', 'list_notes'],
  ['جستجوی یادداشت خرید کتاب', 'search_notes'],
  ['رویدادهای تقویم رو بگو', 'list_calendar_events'],
  ['یک فایل PDF باز کن', 'open_document'],
  ['فایل را به اشتراک بگذار', 'share_document']
];
for (const [input, expectedTool] of featureCases) {
  const result = context.parseOfflineDeviceCommand(input);
  if (!result || result.length !== 1 || result[0].name !== expectedTool) {
    throw new Error(`Feature parser failed for "${input}": ${JSON.stringify(result)}`);
  }
  process.stdout.write(`PASS ${expectedTool} fast path\n`);
}

const routeStart = source.indexOf('function looksLikeDeviceAction(text) {');
const routeEndMarker = '\n  }\n\n  async function runOneShotDeviceAgent';
const routeEnd = source.indexOf(routeEndMarker, routeStart);
if (routeStart < 0 || routeEnd < 0) throw new Error('Could not isolate looksLikeDeviceAction');
vm.runInContext(source.slice(routeStart, routeEnd + '\n  }'.length), context);
for (const input of ['با علی تماس بگیر', 'به علی زنگ بزن', 'تلفن کن با علی', 'Call contact Ali', 'یادداشت کن فردا کتاب را پس بدهم', 'رویدادهای تقویم رو بگو', 'یک فایل PDF باز کن', 'فایل را به اشتراک بگذار', 'یادداشت های من رو لیست کن', 'جستجوی یادداشت خرید کتاب', 'متن صفحه رو بخون', 'متن این صفحه را توضیح بده', 'این عکس رو OCR کن', 'روشنایی صفحه را تنظیم کن', 'مزاحم نشوید را روشن کن', 'وضعیت باتری را تحلیل کن']) {
  if (!context.looksLikeDeviceAction(input)) throw new Error(`Device routing did not intercept: ${input}`);
  process.stdout.write(`PASS fast-route hint ${input}\n`);
}
