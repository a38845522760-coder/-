#!/usr/bin/env python3
"""Static checks for the All Bat app-side updater contract.

Release publishing is intentionally checked conditionally: the repository's current
build-apk.yml produces a debug artifact only, so app updater source can be verified
without falsely claiming that a GitHub Release is published.
"""
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP_GRADLE = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
UPDATER = (ROOT / "app/src/main/java/com/allbat/assistant/AppUpdateManager.kt").read_text(encoding="utf-8")
MAIN = (ROOT / "app/src/main/java/com/allbat/assistant/MainActivity.kt").read_text(encoding="utf-8")
MANIFEST = ET.parse(ROOT / "app/src/main/AndroidManifest.xml").getroot()
FILE_PATHS = ET.parse(ROOT / "app/src/main/res/xml/file_paths.xml").getroot()
WORKFLOW_PATH = ROOT / ".github/workflows/build-apk.yml"
WORKFLOW = WORKFLOW_PATH.read_text(encoding="utf-8") if WORKFLOW_PATH.is_file() else ""

ANDROID_NS = "{http://schemas.android.com/apk/res/android}"

def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"Updater contract failed: {message}")

permissions = {item.attrib.get(ANDROID_NS + "name") for item in MANIFEST.findall("uses-permission")}
cache_paths = {item.attrib.get("path") for item in FILE_PATHS}

require('applicationId = "com.allbat.assistant"' in APP_GRADLE, "applicationId changed unexpectedly")
require('buildConfigField("String", "UPDATE_REPOSITORY"' in APP_GRADLE, "update repository not injected")
require('"a38845522760-coder/-"' in APP_GRADLE, "default updater repository does not match the target GitHub repository")
require("1_000_000 + it" in APP_GRADLE, "CI versionCode high-water counter is missing")
require("android.permission.REQUEST_INSTALL_PACKAGES" in permissions, "Android install-source permission missing")
require("updates/" in cache_paths, "FileProvider does not expose the private updates cache")
require("releases/latest" in UPDATER, "updater does not query the latest GitHub release")
require("apkSha256" in UPDATER and "sha256(" in UPDATER, "APK checksum verification missing")
require("getPackageArchiveInfo" in UPDATER and "APP_SIGNING_CERT_SHA256" in UPDATER, "APK package/signature verification missing")
require("canRequestPackageInstalls" in UPDATER, "Android 8+ install permission flow missing")
require("ACTION_VIEW" in UPDATER and "FileProvider.getUriForFile" in UPDATER, "system package installer flow missing")
require("AppUpdateManager(this)" in MAIN and "checkForUpdates" in MAIN, "startup/manual updater hooks missing")

publishes_release = "softprops/action-gh-release@v2" in WORKFLOW and "assembleRelease" in WORKFLOW
if publishes_release:
    require("contents: write" in WORKFLOW, "release workflow lacks contents: write permission")
    require("update.json" in WORKFLOW and "AllBat.apk" in WORKFLOW, "release assets are incomplete")
    print("Release publishing workflow: detected and statically checked")
else:
    print("NOTICE: current GitHub workflow does not publish signed Releases/update.json; in-app automatic updates are not activated by that workflow.")

print("All Bat app-side updater contract: PASS")
