#!/usr/bin/env python3
"""Fetch the public AI Bale UI from Hugging Face and inject the Android bridge."""
from __future__ import annotations

import os
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSET_DIR = ROOT / "app" / "src" / "main" / "assets"
OUTPUT = ASSET_DIR / "index.html"
BRIDGE = ASSET_DIR / "native-bridge.js"
DEFAULT_SOURCE_URL = (
    "https://huggingface.co/spaces/Mohamad1039/Bot.gemini/resolve/main/index.html"
    "?download=true"
)
SOURCE_URL = os.environ.get("ALLBAT_HTML_SOURCE_URL", DEFAULT_SOURCE_URL)
MAX_HTML_BYTES = 5 * 1024 * 1024


def main() -> int:
    if not BRIDGE.is_file():
        print(f"Missing bridge file: {BRIDGE}", file=sys.stderr)
        return 2

    request = urllib.request.Request(
        SOURCE_URL,
        headers={"User-Agent": "AllBatAndroidBuilder/1.0", "Accept": "text/html,*/*;q=0.8"},
    )
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            final_url = response.geturl()
            raw = response.read(MAX_HTML_BYTES + 1)
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        print(f"Could not fetch the public Hugging Face UI: {exc}", file=sys.stderr)
        print("Check the Space's public access and network availability, then retry.", file=sys.stderr)
        return 3

    if len(raw) > MAX_HTML_BYTES:
        print(f"Source HTML exceeded the {MAX_HTML_BYTES}-byte safety limit.", file=sys.stderr)
        return 4

    try:
        html = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        print(f"Source HTML was not UTF-8: {exc}", file=sys.stderr)
        return 5

    lower = html.lower()
    if "<!doctype html" not in lower or "</html>" not in lower or "ai bale" not in lower:
        print(f"Unexpected response from {final_url}; refusing to package it as the app UI.", file=sys.stderr)
        return 6
    if "__allbatnativebridgeinstalled" in lower:
        print("Source already contains an injected bridge; refusing to double-inject.", file=sys.stderr)
        return 7

    bridge = BRIDGE.read_text(encoding="utf-8")
    injection = "\n<!-- All Bat Android native bridge; bundled at build time. -->\n<script>\n" + bridge + "\n</script>\n"
    match = re.search(r"</body\s*>", html, flags=re.IGNORECASE)
    if match:
        html = html[:match.start()] + injection + html[match.start():]
    else:
        match = re.search(r"</html\s*>", html, flags=re.IGNORECASE)
        if not match:
            print("The source HTML has no closing body/html tag.", file=sys.stderr)
            return 8
        html = html[:match.start()] + injection + html[match.start():]

    ASSET_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(html, encoding="utf-8", newline="")
    print(f"Prepared {OUTPUT.relative_to(ROOT)} ({len(html.encode('utf-8'))} bytes)")
    print(f"Source: {final_url}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
