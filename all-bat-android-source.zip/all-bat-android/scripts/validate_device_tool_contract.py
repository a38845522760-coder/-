#!/usr/bin/env python3
"""Static contract checks for Gemini function declarations and Android native tools."""
from __future__ import annotations

import re
import sys
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
JS = ROOT / "app/src/main/assets/native-bridge.js"
ENGINE = ROOT / "app/src/main/java/com/allbat/assistant/PhoneActionEngine.kt"
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"
GRADLE = ROOT / "app/build.gradle.kts"


def fail(message: str) -> None:
    print(f"DEVICE TOOL CONTRACT ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


js = JS.read_text(encoding="utf-8")
engine = ENGINE.read_text(encoding="utf-8")
manifest = ET.parse(MANIFEST).getroot()
gradle = GRADLE.read_text(encoding="utf-8").lower()

js_start = js.find("const DEVICE_FUNCTION_DECLARATIONS = [")
if js_start < 0:
    fail("Gemini function declarations are missing")
js_end = js.find("\n  ];", js_start)
if js_end < 0:
    fail("Gemini function declaration array is not closed")
declarations = js[js_start:js_end]
declared = set(re.findall(r"\bname:\s*'([a-z_]+)'", declarations))

engine_start = engine.find("fun executeTool(")
engine_end = engine.find("fun requiredPermission(", engine_start)
if engine_start < 0 or engine_end < 0:
    fail("PhoneActionEngine.executeTool dispatch is missing")
dispatch = engine[engine_start:engine_end]
implemented = set(re.findall(r'"([a-z_]+)"\s*->', dispatch))
if not declared:
    fail("no function names found in JS declarations")
if declared != implemented:
    fail(f"JS/Android tool mismatch: declared-only={sorted(declared-implemented)}, android-only={sorted(implemented-declared)}")

required_permissions = {
    node.attrib.get("{http://schemas.android.com/apk/res/android}name")
    for node in manifest.findall("uses-permission")
}
for permission in ("android.permission.READ_CONTACTS", "android.permission.CALL_PHONE"):
    if permission not in required_permissions:
        fail(f"required manifest permission absent: {permission}")
if 'Intent.ACTION_CALL' not in engine:
    fail("direct ACTION_CALL implementation missing")
if "toolResponse: { functionResponses" not in js:
    fail("Live function response round-trip missing")
if "runOneShotDeviceAgent" not in js or "window.__allbatAssistantSend" not in js:
    fail("one-shot agent route for text/default-assistant input missing")

for forbidden in ("com.google.android.gms", "play-services", "firebase-messaging"):
    if forbidden in gradle:
        fail(f"unexpected Google Play Services dependency detected: {forbidden}")

print("Device tool contract: OK")
print("Declared tools:", ", ".join(sorted(declared)))
print("Direct call permissions and model tool-response paths: OK")
