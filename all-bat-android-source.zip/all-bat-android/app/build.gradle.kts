plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.allbat.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.allbat.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 8
        versionName = "1.2.6"
        buildConfigField("String", "SPACE_BASE_URL", "\"https://mohamad1039-bot-gemini.hf.space/\"")
        buildConfigField("String", "SPACE_HOST", "\"mohamad1039-bot-gemini.hf.space\"")
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
