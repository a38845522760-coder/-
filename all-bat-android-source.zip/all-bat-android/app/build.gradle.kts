import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Signing secrets never live in the repository. They come from environment variables (GitHub Secrets)
// or from a git-ignored keystore.properties file (storeFile, storePassword, keyAlias, keyPassword).
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.isFile) f.inputStream().use { load(it) }
}
fun signingValue(env: String, prop: String): String? =
    System.getenv(env)?.takeIf { it.isNotBlank() } ?: keystoreProps.getProperty(prop)?.takeIf { it.isNotBlank() }
val ksFile = file(System.getenv("ALLBAT_KEYSTORE_FILE")?.takeIf { it.isNotBlank() } ?: keystoreProps.getProperty("storeFile") ?: "keystore/allbat-update.p12")
val ksPassword = signingValue("ALLBAT_KEYSTORE_PASSWORD", "storePassword")
val haveSigning = ksPassword != null && ksFile.isFile
// SHA-256 of the companion app's signing certificate (hex, no colons). Used to verify the offline app before talking to it.
val offlineCertPin = (System.getenv("ALLBAT_OFFLINE_CERT_SHA256")?.takeIf { it.isNotBlank() }
    ?: "c392cb991d8fb1c765d036b088fadc5d9e6ccb6fcc868fe05d238f1facca9eca").replace(":", "").lowercase()

android {
    namespace = "com.allbat.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.allbat.assistant"
        minSdk = 27
        targetSdk = 34
        // CI builds always get a higher versionCode than the previous one, so every build can update the last.
        versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()?.let { 100 + it }) ?: 21
        versionName = "1.5.4"
        // Vosk ships native libraries; keep the APK small by targeting real phones only.
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
        buildConfigField("String", "SPACE_BASE_URL", "\"https://mohamad1039-bot-gemini.hf.space/\"")
        buildConfigField("String", "SPACE_HOST", "\"mohamad1039-bot-gemini.hf.space\"")
        buildConfigField("String", "OFFLINE_CERT_SHA256", "\"$offlineCertPin\"")
    }

    // One fixed signing key for every release build: Android only allows an update over an installed app
    // when the signature matches. Keep a backup of the key, because a different key can never update an
    // installed app. The key and its password must NOT be committed to the repository.
    signingConfigs {
        if (haveSigning) {
            create("update") {
                storeFile = ksFile
                storeType = "pkcs12"
                storePassword = ksPassword
                keyAlias = signingValue("ALLBAT_KEY_ALIAS", "keyAlias") ?: "allbat"
                keyPassword = signingValue("ALLBAT_KEY_PASSWORD", "keyPassword") ?: ksPassword
            }
        }
    }

    buildTypes {
        getByName("release") {
            // Never ship a debuggable build: debuggable apps can be inspected and driven over adb / WebView debugging.
            isDebuggable = false
            isMinifyEnabled = false
            if (haveSigning) signingConfig = signingConfigs.getByName("update")
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        // JNA (used by Vosk) loads its native libraries by path, so keep them extracted on install.
        jniLibs { useLegacyPackaging = true }
        resources {
            excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    // Offline Persian speech recognition (Apache-2.0). The ~53 MB model is downloaded only on request.
    implementation("com.alphacephei:vosk-android:0.3.75")
    implementation("net.java.dev.jna:jna:5.18.1@aar")
}
