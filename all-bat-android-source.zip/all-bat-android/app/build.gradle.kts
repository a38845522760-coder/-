plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.allbat.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.allbat.assistant"
        minSdk = 27
        targetSdk = 34
        versionCode = 17
        versionName = "1.4.2"
        // Vosk ships native libraries; keep the APK small by targeting real phones only.
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
        buildConfigField("String", "SPACE_BASE_URL", "\"https://mohamad1039-bot-gemini.hf.space/\"")
        buildConfigField("String", "SPACE_HOST", "\"mohamad1039-bot-gemini.hf.space\"")
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        // JNA (used by Vosk) loads its native libraries by path, so keep them extracted on install.
        jniLibs { useLegacyPackaging = true }
        resources {
            excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    // Offline Persian speech recognition (Apache-2.0). The ~53 MB model is downloaded only on request.
    implementation("com.alphacephei:vosk-android:0.3.75")
    implementation("net.java.dev.jna:jna:5.18.1@aar")
}
