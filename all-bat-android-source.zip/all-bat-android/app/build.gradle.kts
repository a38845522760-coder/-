plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// A stable signing key is supplied only through CI environment variables / GitHub Secrets.
// Never commit a keystore or signing passwords to the source repository.
val releaseStorePath = System.getenv("ALLBAT_RELEASE_STORE_FILE")
val releaseStorePassword = System.getenv("ALLBAT_RELEASE_STORE_PASSWORD")
val releaseKeyAlias = System.getenv("ALLBAT_RELEASE_KEY_ALIAS")
val releaseKeyPassword = System.getenv("ALLBAT_RELEASE_KEY_PASSWORD")
val hasStableReleaseKey = !releaseStorePath.isNullOrBlank() &&
    !releaseStorePassword.isNullOrBlank() && !releaseKeyAlias.isNullOrBlank() &&
    !releaseKeyPassword.isNullOrBlank()

android {
    namespace = "com.allbat.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.allbat.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 16
        versionName = "1.2.15"
        buildConfigField("String", "SPACE_BASE_URL", "\"https://mohamad1039-bot-gemini.hf.space/\"")
        buildConfigField("String", "SPACE_HOST", "\"mohamad1039-bot-gemini.hf.space\"")
    }

    signingConfigs {
        if (hasStableReleaseKey) {
            create("stableRelease") {
                storeFile = file(releaseStorePath!!)
                storePassword = releaseStorePassword!!
                keyAlias = releaseKeyAlias!!
                keyPassword = releaseKeyPassword!!
            }
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            if (hasStableReleaseKey) {
                signingConfig = signingConfigs.getByName("stableRelease")
            }
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
