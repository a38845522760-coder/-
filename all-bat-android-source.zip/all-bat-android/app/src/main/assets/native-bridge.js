/*
 * Native Android bridge injected by scripts/prepare_web_assets.py.
 * Images are sent only while the user's Gemini Live session is active.
 * Screen capture starts only after Android MediaProjection consent.
 */
(() => {
  'use strict';
  if (window.__allBatNativeBridgeInstalled) return;
  window.__allBatNativeBridgeInstalled = true;

  const native = window.AndroidAssistant || null;

  document.addEventListener('click', event => {
    try {
      const target = event.target;
      if (!target || typeof target.closest !== 'function') return;
      if (target.closest('[data-act="pick-camera"]')) {
        native && native.markNextFileChooserAsCamera();
      }
      const liveButton = target.closest('[data-act="voicechat"]');
      if (!liveButton || !native || typeof native.hasFloatingAssistantOverlayPermission !== 'function') return;
      // In the regular app, request the special overlay permission before opening Live so Android
      // Settings cannot unexpectedly cover an already-running microphone session. The system's
      // default-assistant surface has its own lifecycle and asks only after Live is explicitly tapped.
      let systemAssistantSurface = false;
      try { systemAssistantSurface = typeof native.isAssistantSession === 'function' && !!native.isAssistantSession(); } catch (_) {}
      if (systemAssistantSurface || native.hasFloatingAssistantOverlayPermission()) return;
      // Ask only once automatically. If the user declines, Live still remains usable without the orb.
      if (typeof native.shouldPromptFloatingAssistantOverlay === 'function' && !native.shouldPromptFloatingAssistantOverlay()) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      try { native.requestFloatingAssistantOverlay(); } catch (_) {}
      setTimeout(() => setAssistantStatus('مجوز حباب شناور را فعال کن؛ بعد از بازگشت دوباره دکمهٔ گفت‌وگوی صوتی را بزن.'), 100);
    } catch (_) {}
  }, true);

  // If the WebView/Android audio stack cannot initialize capture, release native audio focus
  // before bubbling the original error to the Live UI. Native code prepares communication mode
  // when the WebView's own permission request is granted.
  try {
    const mediaDevices = navigator.mediaDevices;
    if (native && mediaDevices && typeof mediaDevices.getUserMedia === 'function' && !mediaDevices.__allBatAudioWrapped) {
      const originalGetUserMedia = mediaDevices.getUserMedia.bind(mediaDevices);
      const wrappedGetUserMedia = async function (constraints) {
        const wantsAudio = !!(constraints && constraints.audio);
        if (wantsAudio) {
          // Set communication mode before Chromium initializes the native audio source.
          try { native.prepareAudioSession(); } catch (_) {}
        }
        try {
          return await originalGetUserMedia(constraints);
        } catch (firstError) {
          // Some Android WebView/audio-driver combinations reject enhanced mic constraints
          // with NotReadableError even though the default microphone works. Retry once with
          // the browser's default audio constraints, then surface the original error if needed.
          const retryable = wantsAudio && constraints.audio && typeof constraints.audio === 'object' &&
            firstError && ['NotReadableError', 'AbortError', 'OverconstrainedError'].includes(firstError.name);
          if (retryable) {
            try {
              return await originalGetUserMedia({ audio: true, video: constraints.video || false });
            } catch (fallbackError) {
              console.warn('Default microphone fallback also failed', fallbackError);
            }
          }
          if (wantsAudio) {
            try { native.cancelAudioSession(); } catch (_) {}
          }
          throw firstError;
        }
      };
      Object.defineProperty(mediaDevices, '__allBatAudioWrapped', { value: true, configurable: false });
      mediaDevices.getUserMedia = wrappedGetUserMedia;
    }
  } catch (error) {
    console.warn('All Bat could not install audio cleanup wrapper', error);
  }

  let cameraStream = null;
  let cameraVideo = null;
  let cameraCanvas = null;
  let cameraTimer = 0;
  let cameraActive = false;
  let voiceServiceActive = false;
  let screenShareActive = false;
  let screenPermissionPending = false;
  let lastFrameSentAt = 0;

  const canSendLiveFrame = () => {
    try {
      return typeof state !== 'undefined' && !!state.voiceConversation &&
        typeof liveReady !== 'undefined' && !!liveReady &&
        typeof liveSocket !== 'undefined' && liveSocket &&
        liveSocket.readyState === WebSocket.OPEN;
    } catch (_) { return false; }
  };

  function pushFrame(base64Jpeg) {
    if (!base64Jpeg || !canSendLiveFrame()) return false;
    const now = Date.now();
    // Limit bandwidth, processing load and battery use when camera and screen are both enabled.
    if (now - lastFrameSentAt < 1_100) return false;
    try {
      liveSocket.send(JSON.stringify({
        realtimeInput: {
          video: { mimeType: 'image/jpeg', data: base64Jpeg }
        }
      }));
      lastFrameSentAt = now;
      setStatus('تصویر به گفت‌وگوی زنده فرستاده می‌شود');
      return true;
    } catch (_) {
      setStatus('اتصال زنده آمادهٔ دریافت تصویر نیست');
      return false;
    }
  }

  function setStatus(text) {
    const node = document.getElementById('__allbat_status');
    if (node) node.textContent = String(text || '');
  }

  const style = document.createElement('style');
  style.textContent = `
    #__allbat_widget{display:none!important}
    #__allbat_camera_preview{position:fixed;z-index:2147482998;left:10px;bottom:calc(88px + env(safe-area-inset-bottom,0px));width:min(44vw,210px);border:1px solid #ffffff55;border-radius:16px;overflow:hidden;background:#101522;box-shadow:0 8px 24px #0005;display:none}
    #__allbat_camera_preview video{display:block;width:100%;max-height:250px;object-fit:cover;transform:scaleX(1)}
    #__allbat_camera_preview .cap{padding:5px 8px;font-size:11px;color:#fff;background:#101522}
    #__allbat_assistant_mode_banner{display:none;position:fixed;z-index:2147483001;top:calc(8px + env(safe-area-inset-top,0px));left:10px;right:10px;padding:11px 12px;border:1px solid #ffffff24;border-radius:16px;background:#151a29f2;color:#fff;box-shadow:0 8px 28px #0004;direction:rtl;font:13px/1.5 system-ui,sans-serif;align-items:center;gap:10px}
    #__allbat_panel_status{display:none;position:fixed;z-index:2147483645;left:12px;right:12px;bottom:calc(84px + env(safe-area-inset-bottom,0px));padding:10px 13px;border:1px solid #dce5f4;border-radius:15px;background:rgba(20,28,44,.94);color:#fff;box-shadow:0 7px 24px #0003;direction:rtl;font:12px/1.55 system-ui,sans-serif;text-align:right;pointer-events:none}
    body.allbat-assistant-panel-mode #__allbat_panel_status.show{display:block}
    #__allbat_assistant_mode_banner.show{display:flex}
    #__allbat_assistant_mode_banner .desc{flex:1;min-width:0}
    #__allbat_assistant_mode_banner button{border:0;border-radius:12px;background:#5558f3;color:white;font-weight:700;padding:9px 11px;white-space:nowrap}
    #__allbat_region_modal{position:fixed;inset:0;z-index:2147483646;background:#080d18f5;display:flex;flex-direction:column;gap:10px;padding:calc(12px + env(safe-area-inset-top,0px)) 12px calc(12px + env(safe-area-inset-bottom,0px));box-sizing:border-box;color:#fff;direction:rtl;font:14px/1.5 system-ui,sans-serif;touch-action:pan-y}
    #__allbat_region_modal .region-head,#__allbat_region_modal .region-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}
    #__allbat_region_modal .region-head strong{font-size:15px}
    #__allbat_region_modal button{border:1px solid #ffffff26;border-radius:12px;background:#252c40;color:#fff;padding:10px 13px;font-weight:700}
    #__allbat_region_modal button.primary{background:#5558f3;border-color:transparent}
    #__allbat_region_modal button:disabled{opacity:.42}
    #__allbat_region_modal .region-help{font-size:12px;color:#c8d0e4}
    #__allbat_region_modal .region-stage{flex:1;min-height:80px;display:flex;align-items:center;justify-content:center;overflow:hidden;touch-action:none;user-select:none}
    #__allbat_region_modal .region-wrap{position:relative;display:inline-block;max-width:100%;max-height:calc(100vh - 200px);max-height:calc(100dvh - 200px);line-height:0;touch-action:none;user-select:none}
    #__allbat_region_modal .region-image{display:block;width:auto;height:auto;max-width:calc(100vw - 24px);max-height:calc(100vh - 200px);max-height:calc(100dvh - 200px);object-fit:contain;pointer-events:none;user-select:none}
    #__allbat_region_modal .region-box{position:absolute;display:none;border:2px solid #7c9dff;background:#587cff38;box-shadow:0 0 0 9999px #0005;pointer-events:none;box-sizing:border-box}
  `;
  document.documentElement.appendChild(style);

  const widget = document.createElement('div');
  widget.id = '__allbat_widget';
  widget.setAttribute('aria-hidden', 'true');
  widget.innerHTML = `
    <button id="__allbat_camera" type="button" tabindex="-1"></button>
    <button id="__allbat_screen" type="button" tabindex="-1"></button>
    <div id="__allbat_status" role="status"></div>
  `;
  document.body.appendChild(widget);

  const preview = document.createElement('div');
  preview.id = '__allbat_camera_preview';
  preview.innerHTML = '<video playsinline muted autoplay></video><div class="cap">پیش‌نمایش دوربین · ارسال فقط هنگام Live</div>';
  document.body.appendChild(preview);
  const previewVideo = preview.querySelector('video');

  const cameraButton = document.getElementById('__allbat_camera');
  const screenButton = document.getElementById('__allbat_screen');
  let assistantScreenshotDataUrl = '';
  let assistantPanelBanner = null;
  let assistantPanelStatus = null;
  let assistantPanelStatusTimer = 0;
  let regionModal = null;

  function setAssistantStatus(message) {
    const text = String(message || '');
    setStatus(text);
    if (assistantPanelBanner) {
      const status = assistantPanelBanner.querySelector('.desc');
      if (status) status.textContent = text;
    }
    if (document.body && document.body.classList.contains('allbat-assistant-panel-mode')) {
      if (!assistantPanelStatus || !assistantPanelStatus.isConnected) {
        assistantPanelStatus = document.createElement('div');
        assistantPanelStatus.id = '__allbat_panel_status';
        assistantPanelStatus.setAttribute('role', 'status');
        assistantPanelStatus.setAttribute('aria-live', 'polite');
        document.body.appendChild(assistantPanelStatus);
      }
      assistantPanelStatus.textContent = text;
      assistantPanelStatus.classList.add('show');
      if (assistantPanelStatusTimer) clearTimeout(assistantPanelStatusTimer);
      assistantPanelStatusTimer = setTimeout(() => {
        assistantPanelStatus?.classList.remove('show');
        assistantPanelStatusTimer = 0;
      }, 4200);
    }
  }

  function closeRegionModal(restoreNative = true) {
    if (regionModal) regionModal.remove();
    regionModal = null;
    if (restoreNative) {
      try { native && native.finishScreenRegionSelection(); } catch (_) {}
    }
  }

  function openAssistantRegionSelector() {
    if (!assistantScreenshotDataUrl) {
      setAssistantStatus('تصویر صفحه در دسترس نیست؛ ممکن است برنامهٔ فعلی اشتراک اسکرین‌شات را مسدود کرده باشد.');
      return;
    }
    closeRegionModal(false);
    try { native && native.beginScreenRegionSelection(); } catch (_) {}

    const modal = document.createElement('div');
    modal.id = '__allbat_region_modal';
    modal.innerHTML = `
      <div class="region-head"><strong>انتخاب سوژه از صفحه</strong><button type="button" data-region-cancel>لغو</button></div>
      <div class="region-help">دور سوژه با انگشت خط بکش؛ انتخاب به کادر مستطیلی تبدیل می‌شود و می‌توانی لبه‌هایش را تنظیم کنی.</div>
      <div class="region-stage"><div class="region-wrap"><img class="region-image" alt="تصویر صفحه برای انتخاب ناحیه"><svg class="region-lasso" aria-hidden="true"><polyline></polyline></svg><div class="region-box" aria-label="کادر انتخاب"><i class="region-handle nw" data-handle="nw"></i><i class="region-handle n" data-handle="n"></i><i class="region-handle ne" data-handle="ne"></i><i class="region-handle e" data-handle="e"></i><i class="region-handle se" data-handle="se"></i><i class="region-handle s" data-handle="s"></i><i class="region-handle sw" data-handle="sw"></i><i class="region-handle w" data-handle="w"></i></div></div></div>
      <div class="region-foot"><span class="region-help" data-region-status>برای انتخاب، دور سوژه خط بکش.</span><div class="region-actions"><button type="button" data-region-redo>انتخاب دوباره</button><button class="primary" type="button" data-region-send disabled>تأیید و افزودن</button></div></div>
    `;
    document.body.appendChild(modal);
    regionModal = modal;
    const image = modal.querySelector('.region-image');
    const wrap = modal.querySelector('.region-wrap');
    const box = modal.querySelector('.region-box');
    const polyline = modal.querySelector('.region-lasso polyline');
    const lassoSvg = modal.querySelector('.region-lasso');
    const sendButton = modal.querySelector('[data-region-send]');
    const redoButton = modal.querySelector('[data-region-redo]');
    const status = modal.querySelector('[data-region-status]');
    image.src = assistantScreenshotDataUrl;

    let selection = null;
    let gesture = null;
    let gestureStart = null;
    let points = [];
    let activePointerId = null;
    const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
    const imageRect = () => image.getBoundingClientRect();
    const pointFor = event => {
      const rect = imageRect();
      return { x: clamp(event.clientX - rect.left, 0, rect.width), y: clamp(event.clientY - rect.top, 0, rect.height) };
    };
    const clearLasso = () => {
      polyline.setAttribute('points', '');
      lassoSvg.style.display = 'none';
    };
    const drawLasso = () => {
      lassoSvg.style.display = 'block';
      polyline.setAttribute('points', points.map(point => `${point.x},${point.y}`).join(' '));
    };
    const drawBox = next => {
      selection = {
        left: clamp(next.left, 0, imageRect().width),
        top: clamp(next.top, 0, imageRect().height),
        width: clamp(next.width, 0, imageRect().width),
        height: clamp(next.height, 0, imageRect().height)
      };
      box.style.display = 'block';
      box.style.left = selection.left + 'px';
      box.style.top = selection.top + 'px';
      box.style.width = selection.width + 'px';
      box.style.height = selection.height + 'px';
      sendButton.disabled = selection.width < 14 || selection.height < 14;
    };
    const boundsFor = sourcePoints => {
      const xs = sourcePoints.map(point => point.x);
      const ys = sourcePoints.map(point => point.y);
      const left = Math.min(...xs), right = Math.max(...xs);
      const top = Math.min(...ys), bottom = Math.max(...ys);
      return { left, top, width: right - left, height: bottom - top };
    };
    const resetSelection = () => {
      selection = null;
      gesture = null;
      points = [];
      box.style.display = 'none';
      clearLasso();
      sendButton.disabled = true;
      status.textContent = 'برای انتخاب، دور سوژه خط بکش.';
    };

    wrap.addEventListener('pointerdown', event => {
      if (!image.naturalWidth || !image.naturalHeight) return;
      const handle = event.target && event.target.closest ? event.target.closest('[data-handle]') : null;
      event.preventDefault();
      activePointerId = event.pointerId;
      try { wrap.setPointerCapture(activePointerId); } catch (_) {}
      gestureStart = pointFor(event);
      if (handle && selection) {
        gesture = { type: 'resize', handle: handle.getAttribute('data-handle'), initial: { ...selection } };
        status.textContent = 'لبهٔ کادر را جابه‌جا کن تا محدوده دقیق شود.';
        return;
      }
      if (selection && event.target === box) {
        gesture = { type: 'move', initial: { ...selection } };
        status.textContent = 'کادر را جابه‌جا کن تا دقیقاً روی سوژه قرار بگیرد.';
        return;
      }
      gesture = { type: 'lasso' };
      points = [gestureStart];
      box.style.display = 'none';
      sendButton.disabled = true;
      drawLasso();
      status.textContent = 'دور سوژه را کامل کن؛ کادر به‌صورت خودکار ساخته می‌شود.';
    });

    wrap.addEventListener('pointermove', event => {
      if (!gesture || event.pointerId !== activePointerId) return;
      event.preventDefault();
      const current = pointFor(event);
      if (gesture.type === 'lasso') {
        const last = points[points.length - 1];
        const dx = current.x - last.x, dy = current.y - last.y;
        if ((dx * dx + dy * dy) >= 16 && points.length < 800) points.push(current);
        drawLasso();
        return;
      }
      const original = gesture.initial;
      if (gesture.type === 'move') {
        const rect = imageRect();
        drawBox({
          left: clamp(original.left + current.x - gestureStart.x, 0, rect.width - original.width),
          top: clamp(original.top + current.y - gestureStart.y, 0, rect.height - original.height),
          width: original.width, height: original.height
        });
        return;
      }
      const right0 = original.left + original.width;
      const bottom0 = original.top + original.height;
      let left = original.left, top = original.top, right = right0, bottom = bottom0;
      const h = gesture.handle;
      if (h.includes('w')) left = clamp(original.left + current.x - gestureStart.x, 0, right0 - 14);
      if (h.includes('e')) right = clamp(right0 + current.x - gestureStart.x, left + 14, imageRect().width);
      if (h.includes('n')) top = clamp(original.top + current.y - gestureStart.y, 0, bottom0 - 14);
      if (h.includes('s')) bottom = clamp(bottom0 + current.y - gestureStart.y, top + 14, imageRect().height);
      drawBox({ left, top, width: right - left, height: bottom - top });
    });

    const finishGesture = event => {
      if (!gesture || event.pointerId !== activePointerId) return;
      if (gesture.type === 'lasso') {
        const finalPoint = pointFor(event);
        const last = points[points.length - 1];
        if (!last || Math.hypot(finalPoint.x - last.x, finalPoint.y - last.y) >= 1) points.push(finalPoint);
        const bounds = points.length >= 3 ? boundsFor(points) : null;
        clearLasso();
        if (bounds && bounds.width >= 14 && bounds.height >= 14) {
          drawBox(bounds);
          status.textContent = 'کادر مستطیلی آماده است؛ با دستگیره‌ها لبه‌ها را تنظیم کن.';
        } else {
          selection = null;
          box.style.display = 'none';
          sendButton.disabled = true;
          status.textContent = 'انتخاب خیلی کوچک بود؛ دوباره دور سوژه خط بکش.';
        }
      } else if (selection && selection.width >= 14 && selection.height >= 14) {
        status.textContent = 'کادر تنظیم شد؛ تصویر فقط پس از تأیید پیوست می‌شود.';
      }
      gesture = null;
      gestureStart = null;
      activePointerId = null;
    };
    wrap.addEventListener('pointerup', finishGesture);
    wrap.addEventListener('pointercancel', finishGesture);

    redoButton.addEventListener('click', resetSelection);
    modal.querySelector('[data-region-cancel]').addEventListener('click', () => {
      closeRegionModal(true);
      setAssistantStatus('انتخاب صفحه لغو شد؛ تصویری ارسال نشد.');
    });
    sendButton.addEventListener('click', async () => {
      if (!selection || !image.naturalWidth || !image.naturalHeight) return;
      sendButton.disabled = true;
      status.textContent = 'در حال آماده‌سازی بخش انتخاب‌شده…';
      try {
        const rect = imageRect();
        const sx = image.naturalWidth / rect.width;
        const sy = image.naturalHeight / rect.height;
        let sx0 = Math.round(selection.left * sx), sy0 = Math.round(selection.top * sy);
        let sw = Math.round(selection.width * sx), sh = Math.round(selection.height * sy);
        sx0 = clamp(sx0, 0, image.naturalWidth - 1); sy0 = clamp(sy0, 0, image.naturalHeight - 1);
        sw = clamp(sw, 1, image.naturalWidth - sx0); sh = clamp(sh, 1, image.naturalHeight - sy0);
        const canvas = document.createElement('canvas');
        const scale = Math.min(1, 1600 / Math.max(sw, sh));
        canvas.width = Math.max(1, Math.round(sw * scale));
        canvas.height = Math.max(1, Math.round(sh * scale));
        const ctx = canvas.getContext('2d', { alpha: false });
        if (!ctx) throw new Error('canvas unavailable');
        ctx.drawImage(image, sx0, sy0, sw, sh, 0, 0, canvas.width, canvas.height);
        const blob = await new Promise((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error('crop failed')), 'image/jpeg', 0.88));
        const file = new File([blob], 'allbat-selected-screen-region.jpg', { type: 'image/jpeg', lastModified: Date.now() });
        let attached = false;
        try {
          if (typeof addFiles === 'function') { await Promise.resolve(addFiles([file])); attached = true; }
        } catch (error) { console.warn('Could not attach cropped assistant image', error); }
        if (!attached) {
          const input = document.getElementById('pickerPhoto') || document.querySelector('input[type="file"][accept*="image"]');
          if (input && typeof DataTransfer !== 'undefined') {
            const transfer = new DataTransfer(); transfer.items.add(file); input.files = transfer.files;
            input.dispatchEvent(new Event('change', { bubbles: true })); attached = true;
          }
        }
        if (!attached) throw new Error('composer attachment handler unavailable');
        closeRegionModal(true);
        setAssistantStatus('تصویر کوچکِ بخش انتخاب‌شده به پیش‌نویس پیوست شد. متن سؤال را بنویس و ارسال کن.');
      } catch (error) {
        console.warn('Selected screen region could not be attached', error);
        status.textContent = 'افزودن تصویر ناموفق بود؛ دوباره امتحان کن.';
        sendButton.disabled = false;
      }
    });
  }

  let panelModeStyle = null;
  let panelModeBooting = false;
  function ensureAssistantPanelStyles() {
    if (panelModeStyle) return;
    panelModeStyle = document.createElement('style');
    panelModeStyle.id = '__allbat_assistant_panel_styles';
    panelModeStyle.textContent = `
      html,body{height:100%!important;min-height:0!important;overflow:hidden!important;background:transparent!important}
      body.allbat-assistant-panel-mode{height:100%!important;min-height:0!important;overflow:hidden!important;overscroll-behavior:none!important}
      body.allbat-assistant-panel-mode .app{display:flex!important;flex-direction:column!important;height:100dvh!important;min-height:0!important;max-height:100dvh!important;max-width:none!important;margin:0!important;padding:0 0 2px!important;overflow:hidden!important;background:transparent!important;box-sizing:border-box!important}
      body.allbat-assistant-panel-mode .top,body.allbat-assistant-panel-mode .tabs,body.allbat-assistant-panel-mode #topMain,body.allbat-assistant-panel-mode #topChat{display:none!important}
      body.allbat-assistant-panel-mode .screen:not(.on){display:none!important}
      body.allbat-assistant-panel-mode .screen.on{display:flex!important;flex:1 1 auto!important;flex-direction:column!important;min-height:0!important;height:100%!important;max-height:100%!important;padding:0 8px!important;background:transparent!important;overflow:hidden!important}
      body.allbat-assistant-panel-mode .hero,body.allbat-assistant-panel-mode .sec{display:none!important}
      /* ===== Dark assistant card (matches the reference design) ===== */
      body.allbat-assistant-panel-mode{background:transparent!important;color-scheme:light!important}
      body.allbat-assistant-panel-mode :where(.app,.screen,main,section,article,header,footer,div,aside,nav):not(.comp):not(.dock):not(.shw):not(#__allbat_region_modal):not(#__allbat_region_modal *){background:transparent!important;background-image:none!important;box-shadow:none!important}
      body.allbat-assistant-panel-mode body::before,body.allbat-assistant-panel-mode body::after,body.allbat-assistant-panel-mode .app::before,body.allbat-assistant-panel-mode .app::after,body.allbat-assistant-panel-mode .screen::before,body.allbat-assistant-panel-mode .screen::after,body.allbat-assistant-panel-mode .msg::before,body.allbat-assistant-panel-mode .msg::after{display:none!important;content:none!important}
      body.allbat-assistant-panel-mode #msgs{direction:ltr!important;position:relative!important}
      body.allbat-assistant-panel-mode .msg > :not(.mb):not(.attachment):not(.file-preview):not(img){display:none!important}
      body.allbat-assistant-panel-mode{color:#1b1c21!important;font-family:Inter,"SF Pro Text",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif!important;-webkit-font-smoothing:antialiased}
      body.allbat-assistant-panel-mode .app{background:transparent!important;padding:0!important}
      body.allbat-assistant-panel-mode .screen.on{padding:0 20px!important;background:transparent!important}
      body.allbat-assistant-panel-mode .top,body.allbat-assistant-panel-mode .tabs,body.allbat-assistant-panel-mode .av,body.allbat-assistant-panel-mode .avatar,body.allbat-assistant-panel-mode .mh,body.allbat-assistant-panel-mode .ma{display:none!important}
      body.allbat-assistant-panel-mode #msgs{display:flex!important;flex:1 1 0!important;flex-direction:column!important;width:100%!important;height:0!important;min-height:65px!important;max-height:none!important;overflow-y:auto!important;overflow-x:hidden!important;overscroll-behavior-y:contain!important;-webkit-overflow-scrolling:touch!important;touch-action:pan-y!important;padding:58px 0 18px!important;gap:26px!important;scrollbar-width:none;box-sizing:border-box!important;overflow-anchor:auto!important;background:transparent!important}
      body.allbat-assistant-panel-mode #msgs::-webkit-scrollbar{display:none}
      body.allbat-assistant-panel-mode .msg{width:100%!important;max-width:none!important;display:flex!important;flex-direction:column!important;gap:0!important;padding:0!important;margin:0!important;border:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important;box-sizing:border-box!important}
      body.allbat-assistant-panel-mode .msg.user{align-items:flex-end!important}
      body.allbat-assistant-panel-mode .msg:not(.user){align-items:flex-start!important}
      body.allbat-assistant-panel-mode .msg .mb{max-width:82%!important;padding:0!important;margin:0!important;border:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important;color:#1b1c21!important;font-size:16px!important;line-height:1.38!important;font-weight:400!important;unicode-bidi:plaintext}
      body.allbat-assistant-panel-mode .msg.user .mb{text-align:right!important}
      body.allbat-assistant-panel-mode .msg:not(.user) .mb{text-align:start!important}
      body.allbat-assistant-panel-mode .msg .mb::after{content:none!important;display:none!important}
      body.allbat-assistant-panel-mode .msg .mb p{margin:0 0 8px!important}
      body.allbat-assistant-panel-mode .msg .mb p:last-child{margin-bottom:0!important}
      body.allbat-assistant-panel-mode .msg .mb a{color:#1a5fd0!important}
      body.allbat-assistant-panel-mode .msg .mb pre,body.allbat-assistant-panel-mode .msg .mb code{background:#0000000d!important;color:#1b1c21!important;border-radius:10px!important}
      body.allbat-assistant-panel-mode .msg .mb pre{padding:10px 12px!important;max-width:100%!important;overflow-x:auto!important}
      body.allbat-assistant-panel-mode .msg.user img,body.allbat-assistant-panel-mode .msg.user .attachment img,body.allbat-assistant-panel-mode .msg.user .file-preview img{width:auto!important;max-width:104px!important;height:auto!important;max-height:78px!important;object-fit:cover!important;border-radius:12px!important}
      /* "Thinking........" shows in the message flow while the answer has not started */
      body.allbat-assistant-panel-mode.allbat-thinking #msgs::after{content:"Thinking........";display:block;align-self:flex-start;color:#5f6368;font-size:16px;line-height:1.38;letter-spacing:.01em}
      body.allbat-assistant-panel-mode .allbat-pending-empty{display:none!important}
      /* Composer pinned to the bottom of the card */
      body.allbat-assistant-panel-mode .dock{display:none!important}
      body.allbat-assistant-panel-mode .rb{width:42px!important;height:42px!important;min-width:42px!important;flex:0 0 42px!important}
      body.allbat-assistant-panel-mode #micBtn,body.allbat-assistant-panel-mode #clipBtn,body.allbat-assistant-panel-mode #voiceChatBtn{display:none!important}
      body.allbat-assistant-panel-mode .allbat-panel-region{display:none!important}
      body.allbat-assistant-panel-mode.allbat-has-shot .allbat-panel-region{display:grid!important;place-items:center!important;flex:0 0 38px!important;width:38px!important;min-width:38px!important;height:38px!important;padding:0!important;border:0!important;border-radius:50%!important;background:#ffffff1f!important;color:#fff!important}
      body.allbat-assistant-panel-mode .allbat-panel-region svg{width:19px!important;height:19px!important;fill:none!important;stroke:currentColor!important;stroke-width:1.8!important;stroke-linecap:round!important;stroke-linejoin:round!important}
      body.allbat-assistant-panel-mode #sendBtn{flex:0 0 42px!important;width:42px!important;min-width:42px!important;height:42px!important;padding:0!important;border:0!important;border-radius:50%!important;background:#f2f2f2 url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23000' stroke-width='2.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M12 19V5M5.5 11.5L12 5l6.5 6.5'/%3E%3C/svg%3E") center/20px 20px no-repeat!important;color:transparent!important;font-size:0!important;box-shadow:none!important}
      body.allbat-assistant-panel-mode #sendBtn svg,body.allbat-assistant-panel-mode #sendBtn img,body.allbat-assistant-panel-mode #sendBtn .i{display:none!important}
      body.allbat-assistant-panel-mode #sendBtn.stopmode{background:#f2f2f2 url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Crect x='6' y='6' width='12' height='12' rx='2.5' fill='%23000'/%3E%3C/svg%3E") center/20px 20px no-repeat!important}
      body.allbat-assistant-panel-mode #sendBtn.busy{opacity:.65!important}
      body.allbat-assistant-panel-mode .start{padding:12px 0 5px!important;gap:6px!important;color:#5f6368!important;background:transparent!important}
      body.allbat-assistant-panel-mode .start h3{font-size:16px!important;color:#1b1c21!important}
      body.allbat-assistant-panel-mode .start p{font-size:12px!important;color:#80868b!important}
      body.allbat-assistant-panel-mode #__allbat_widget,body.allbat-assistant-panel-mode #__allbat_camera_preview{display:none!important}
      body.allbat-assistant-panel-mode #__allbat_panel_status{left:20px!important;right:20px!important;bottom:14px!important}
      body.allbat-assistant-panel-mode .shw{z-index:2147483647!important}
      #__allbat_region_modal{position:fixed;inset:0;z-index:2147483646;background:#11151d;display:flex;flex-direction:column;gap:8px;padding:calc(12px + env(safe-area-inset-top,0px)) 12px calc(12px + env(safe-area-inset-bottom,0px));box-sizing:border-box;color:#fff;direction:rtl;font:14px/1.5 system-ui,sans-serif;touch-action:pan-y}
      #__allbat_region_modal .region-head,#__allbat_region_modal .region-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}
      #__allbat_region_modal .region-head strong{font-size:15px}
      #__allbat_region_modal button{border:1px solid #ffffff26;border-radius:12px;background:#252c40;color:#fff;padding:9px 12px;font-weight:700}
      #__allbat_region_modal button.primary{background:#5558f3;border-color:transparent}
      #__allbat_region_modal button:disabled{opacity:.42}
      #__allbat_region_modal .region-help{font-size:12px;color:#c8d0e4}
      #__allbat_region_modal .region-stage{flex:1;min-height:80px;display:flex;align-items:center;justify-content:center;overflow:hidden;touch-action:none;user-select:none}
      #__allbat_region_modal .region-wrap{position:relative;display:inline-block;max-width:100%;max-height:calc(100dvh - 188px);line-height:0;touch-action:none;user-select:none}
      #__allbat_region_modal .region-image{display:block;width:auto;height:auto;max-width:calc(100vw - 24px);max-height:calc(100dvh - 188px);object-fit:contain;pointer-events:none;user-select:none}
      #__allbat_region_modal .region-lasso{position:absolute;inset:0;width:100%;height:100%;display:none;overflow:visible;pointer-events:none}
      #__allbat_region_modal .region-lasso polyline{fill:#587cff25;stroke:#a9c1ff;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round;vector-effect:non-scaling-stroke}
      #__allbat_region_modal .region-box{position:absolute;display:none;border:2px solid #91afff;background:#587cff28;box-shadow:0 0 0 9999px #0007;pointer-events:auto;box-sizing:border-box;cursor:move}
      #__allbat_region_modal .region-handle{position:absolute;display:block;width:15px;height:15px;border:2px solid #233b72;border-radius:50%;background:#fff;box-shadow:0 1px 5px #0006;transform:translate(-50%,-50%);pointer-events:auto;touch-action:none}
      #__allbat_region_modal .region-handle.nw{left:0;top:0;cursor:nwse-resize}
      #__allbat_region_modal .region-handle.n{left:50%;top:0;cursor:ns-resize}
      #__allbat_region_modal .region-handle.ne{left:100%;top:0;cursor:nesw-resize}
      #__allbat_region_modal .region-handle.e{left:100%;top:50%;cursor:ew-resize}
      #__allbat_region_modal .region-handle.se{left:100%;top:100%;cursor:nwse-resize}
      #__allbat_region_modal .region-handle.s{left:50%;top:100%;cursor:ns-resize}
      #__allbat_region_modal .region-handle.sw{left:0;top:100%;cursor:nesw-resize}
      #__allbat_region_modal .region-handle.w{left:0;top:50%;cursor:ew-resize}
      #__allbat_region_modal .region-actions{display:flex;gap:7px;align-items:center}
      @keyframes allbatPanelIn{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:translateY(0)}}
      body.allbat-assistant-panel-mode .app{animation:allbatPanelIn 170ms cubic-bezier(.2,.75,.25,1) both}
      @media(prefers-reduced-motion:reduce){body.allbat-assistant-panel-mode .app{animation:none!important}}
    `;
    document.head.appendChild(panelModeStyle);
  }

  // Match the reference answer card: compact feedback row plus a visible speaker button.
  try {
    if (typeof gemActs === 'function' && !gemActs.__allbatSpeechAction) {
      const originalGemActs = gemActs;
      const wrappedGemActs = function(message, isAssistant, meta) {
        const markup = originalGemActs.apply(this, arguments);
        if (!isAssistant || (meta && meta.pending) || !markup || !message) return markup;
        const id = typeof esc === 'function' ? esc(message.id) : String(message.id || '').replace(/[&<>"']/g, '');
        const button = `<button class="speak" type="button" data-allbat-readaloud="${id}" title="Read aloud" aria-label="Read aloud">${typeof ic === 'function' ? ic('speaker') : '◖))'}</button>`;
        const end = markup.lastIndexOf('</div>');
        return end < 0 ? markup : markup.slice(0, end) + button + markup.slice(end);
      };
      wrappedGemActs.__allbatSpeechAction = true;
      gemActs = wrappedGemActs;
      try { window.gemActs = wrappedGemActs; } catch (_) {}
    }
  } catch (error) { console.warn('Could not install answer read-aloud control', error); }
  const readAnswerAloud = messageId => {
    try {
      const session = typeof cur === 'function' ? cur() : null;
      const message = session && Array.isArray(session.messages) ? session.messages.find(m => String(m.id) === String(messageId)) : null;
      const text = String((message && (message.text || message.content)) || '').trim();
      if (!text) { if (typeof toast === 'function') toast('پاسخی برای خواندن پیدا نشد'); return; }
      if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') {
        if (typeof toast === 'function') toast('خواندن صوتی در این دستگاه در دسترس نیست'); return;
      }
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text.slice(0, 3500));
      utterance.lang = 'fa-IR'; utterance.rate = 1; utterance.pitch = 1;
      window.speechSynthesis.speak(utterance);
    } catch (error) { console.warn('Read aloud failed', error); if (typeof toast === 'function') toast('خواندن پاسخ انجام نشد'); }
  };
  document.addEventListener('click', event => {
    const button = event.target && event.target.closest ? event.target.closest('[data-allbat-readaloud]') : null;
    if (!button) return;
    event.preventDefault(); event.stopPropagation();
    readAnswerAloud(button.getAttribute('data-allbat-readaloud'));
  }, true);

  let panelMessagesObserver = null;
  let panelMessagesNode = null;
  let panelStickToBottom = true;
  let panelScrollTop = 0;
  let panelEnhancementTimer = 0;
  let panelDockResizeObserver = null;
  let panelDockNode = null;
  let panelModeGeneration = 0;
  let originalPanelRefreshSendState = null;

  function updatePanelThinking() {
    if (!document.body || !document.body.classList.contains('allbat-assistant-panel-mode')) return;
    let sending = false;
    try { sending = typeof state !== 'undefined' && !!state.sending; } catch (_) {}
    const messages = document.getElementById('msgs');
    let waiting = false;
    if (messages) {
      messages.querySelectorAll('.allbat-pending-empty').forEach(node => node.classList.remove('allbat-pending-empty'));
      if (sending) {
        const all = messages.querySelectorAll('.msg');
        const last = all.length ? all[all.length - 1] : null;
        if (!last || last.classList.contains('user')) {
          waiting = true;
        } else {
          const body = last.querySelector('.mb') || last;
          if (!String(body.textContent || '').trim() && !body.querySelector('img,video,canvas,pre,table')) {
            waiting = true;
            last.classList.add('allbat-pending-empty');
          }
        }
      }
    }
    const was = document.body.classList.contains('allbat-thinking');
    document.body.classList.toggle('allbat-thinking', waiting);
    if (waiting && !was && messages && panelStickToBottom) {
      requestAnimationFrame(() => { messages.scrollTop = messages.scrollHeight; panelScrollTop = messages.scrollTop; });
    }
  }

  let lastPanelTextSig = '';
  // Reduces markdown to readable plain text for the native answer card.
  function panelPlainText(md) {
    return String(md || '')
      .replace(/```[a-zA-Z0-9_-]*\n?/g, '')
      .replace(/!\[[^\]]*\]\([^)]*\)/g, '')
      .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
      .replace(/^\s{0,3}#{1,6}\s*/gm, '')
      .replace(/(\*\*|__)(.*?)\1/g, '$2')
      .replace(/^\s*[*-]\s+/gm, '• ')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }
  // Sends the latest answer (read from the chat data, not the DOM) to the native text card.
  function publishPanelText() {
    try {
      if (!native || typeof native.setPanelText !== 'function') return;
      let sending = false;
      try { sending = typeof state !== 'undefined' && !!state.sending; } catch (_) {}
      let chat = null;
      try { chat = typeof cur === 'function' ? cur() : null; } catch (_) {}
      const list = chat && Array.isArray(chat.messages) ? chat.messages : [];
      const last = list.length ? list[list.length - 1] : null;
      let text = '';
      if (last && last.role === 'ai') {
        text = panelPlainText(last.text);
        const meta = last.meta || {};
        if (!text && meta.media_url && !meta.pending) text = 'نتیجه آماده است؛ برای دیدن آن برنامه را باز کن.';
      }
      const thinking = !text && sending;
      const sig = (thinking ? '1' : '0') + '|' + text;
      if (sig === lastPanelTextSig) return;
      lastPanelTextSig = sig;
      native.setPanelText(text, thinking);
    } catch (_) {}
  }

  let lastReportedPanelHeight = 0;
  function reportPanelHeight() {
    if (!document.body || !document.body.classList.contains('allbat-assistant-panel-mode')) return;
    publishPanelText();
    try {
      if (!native || typeof native.setPanelContentHeight !== 'function') return;
      const messages = document.getElementById('msgs');
      const dock = document.querySelector('body.allbat-assistant-panel-mode .dock');
      if (!messages) return;
      const cs = getComputedStyle(messages);
      const padTop = parseFloat(cs.paddingTop) || 58;
      const padBottom = (dock ? Math.ceil(dock.getBoundingClientRect().height) : 70) + 20;
      let bottom = padTop;
      const kids = messages.children;
      if (kids.length) {
        const last = kids[kids.length - 1];
        bottom = last.offsetTop + last.offsetHeight;
      }
      if (document.body.classList.contains('allbat-thinking')) bottom += 48;
      const total = Math.ceil(bottom + padBottom);
      if (Math.abs(total - lastReportedPanelHeight) > 3) {
        lastReportedPanelHeight = total;
        native.setPanelContentHeight(total);
      }
    } catch (_) {}
  }

  function updatePanelComposerControls() {
    if (!document.body || !document.body.classList.contains('allbat-assistant-panel-mode')) return;
    updatePanelThinking();
    reportPanelHeight();
    const composer = document.querySelector('body.allbat-assistant-panel-mode .dock .comp');
    const voice = document.getElementById('voiceChatBtn');
    const mic = document.getElementById('micBtn');
    const attach = document.getElementById('clipBtn');
    if (mic) mic.style.display = 'none';
    if (attach) attach.style.display = 'none';
    let regionButton = document.getElementById('__allbat_panel_region');
    if (composer && !regionButton) {
      regionButton = document.createElement('button');
      regionButton.id = '__allbat_panel_region';
      regionButton.type = 'button';
      regionButton.className = 'allbat-panel-region';
      regionButton.title = 'انتخاب بخشی از صفحه';
      regionButton.setAttribute('aria-label', 'انتخاب بخشی از صفحه');
      regionButton.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3v13a2 2 0 0 0 2 2h12M3 7h13a2 2 0 0 1 2 2v12"/></svg>';
      regionButton.addEventListener('click', () => {
        try {
          if (native && typeof native.selectScreenRegion === 'function') native.selectScreenRegion();
          else setAssistantStatus('انتخاب بخش صفحه در این محیط در دسترس نیست.');
        } catch (error) {
          console.warn('Could not open screen-region selection', error);
          setAssistantStatus('بازکردن ابزار انتخاب بخش صفحه ناموفق بود.');
        }
      });
      composer.insertBefore(regionButton, voice || document.getElementById('sendBtn'));
    }
    if (!voice) return;
    let active = false;
    try { active = typeof state !== 'undefined' && !!state.voiceConversation; } catch (_) {}
    try {
      if (typeof ic === 'function') voice.innerHTML = ic(active ? 'x' : 'mic');
    } catch (_) { voice.textContent = active ? '×' : '🎙'; }
    voice.setAttribute('aria-label', active ? 'پایان گفت‌وگوی صوتی' : 'شروع گفت‌وگوی صوتی');
    voice.title = active ? 'پایان گفت‌وگوی صوتی' : 'شروع گفت‌وگوی صوتی';
    voice.setAttribute('aria-pressed', String(active));
  }

  function bindPanelMessageList() {
    if (!document.body || !document.body.classList.contains('allbat-assistant-panel-mode')) return;
    const dock = document.querySelector('body.allbat-assistant-panel-mode .dock');
    const messages = document.getElementById('msgs');
    if (dock && dock !== panelDockNode) {
      if (panelDockResizeObserver) panelDockResizeObserver.disconnect();
      panelDockNode = dock;
      if (typeof ResizeObserver === 'function') {
        panelDockResizeObserver = new ResizeObserver(() => updatePanelDockOffset());
        panelDockResizeObserver.observe(dock);
      }
    }
    updatePanelDockOffset();
    if (!messages) return;
    if (messages !== panelMessagesNode) {
      const shouldFollow = panelStickToBottom;
      const previousScrollTop = panelScrollTop;
      if (panelMessagesObserver) panelMessagesObserver.disconnect();
      panelMessagesNode = messages;
      messages.addEventListener('scroll', () => {
        const remaining = messages.scrollHeight - messages.scrollTop - messages.clientHeight;
        panelStickToBottom = remaining < 72;
        panelScrollTop = messages.scrollTop;
      }, { passive: true });
      panelMessagesObserver = new MutationObserver(() => {
        requestAnimationFrame(reportPanelHeight);
        if (!panelStickToBottom) return;
        requestAnimationFrame(() => {
          if (panelMessagesNode === messages && panelStickToBottom) {
            messages.scrollTop = messages.scrollHeight;
            panelScrollTop = messages.scrollTop;
          }
        });
      });
      panelMessagesObserver.observe(messages, { childList: true, subtree: true, characterData: true, attributes: false });
      requestAnimationFrame(() => {
        if (panelMessagesNode !== messages) return;
        if (shouldFollow) messages.scrollTop = messages.scrollHeight;
        else messages.scrollTop = Math.min(previousScrollTop, Math.max(0, messages.scrollHeight - messages.clientHeight));
        panelScrollTop = messages.scrollTop;
      });
    }
  }

  function updatePanelDockOffset() {
    if (!document.body || !document.body.classList.contains('allbat-assistant-panel-mode')) return;
    const dock = document.querySelector('body.allbat-assistant-panel-mode .dock');
    const messages = document.getElementById('msgs');
    if (!dock || !messages) return;
    const height = Math.ceil(dock.getBoundingClientRect().height + 20);
    if (messages.style.paddingBottom !== `${height}px`) messages.style.setProperty('padding-bottom', `${height}px`, 'important');
  }

  function installPanelChatEnhancements() {
    if (!document.body || !document.body.classList.contains('allbat-assistant-panel-mode')) return;
    updatePanelComposerControls();
    bindPanelMessageList();
    if (!panelEnhancementTimer) {
      panelEnhancementTimer = window.setInterval(() => {
        if (!document.body.classList.contains('allbat-assistant-panel-mode')) return;
        updatePanelComposerControls();
        bindPanelMessageList();
      }, 400);
    }
    // The existing send button already becomes a stop button while a response is streaming.
    // Wrap only the state refresh so the visible Live control uses a microphone glyph.
    if (!originalPanelRefreshSendState && typeof refreshSendState === 'function') {
      try {
        originalPanelRefreshSendState = refreshSendState;
        refreshSendState = function (...args) {
          const result = originalPanelRefreshSendState.apply(this, args);
          updatePanelComposerControls();
          return result;
        };
      } catch (error) {
        console.warn('Could not adapt assistant composer controls', error);
      }
    }
  }

  function resetPanelMessageTracking() {
    if (panelMessagesObserver) panelMessagesObserver.disconnect();
    if (panelDockResizeObserver) panelDockResizeObserver.disconnect();
    if (panelMessagesNode) panelMessagesNode.style.removeProperty('padding-bottom');
    panelMessagesObserver = null;
    panelMessagesNode = null;
    panelDockResizeObserver = null;
    panelDockNode = null;
    panelStickToBottom = true;
    panelScrollTop = 0;
    lastReportedPanelHeight = 0;
  }

  window.__allbatAssistantPanelMode = enabled => {
    if (!enabled) {
      panelModeGeneration += 1;
      panelModeBooting = false;
      document.body.classList.remove('allbat-assistant-panel-mode', 'allbat-thinking', 'allbat-has-shot');
      if (assistantPanelBanner) assistantPanelBanner.remove();
      if (assistantPanelStatus) assistantPanelStatus.remove();
      if (assistantPanelStatusTimer) clearTimeout(assistantPanelStatusTimer);
      assistantPanelBanner = null;
      assistantPanelStatus = null;
      assistantPanelStatusTimer = 0;
      if (panelEnhancementTimer) clearInterval(panelEnhancementTimer);
      panelEnhancementTimer = 0;
      resetPanelMessageTracking();
      if (regionModal) closeRegionModal(false);
      assistantScreenshotDataUrl = '';
      return;
    }
    ensureAssistantPanelStyles();
    lastPanelTextSig = '';
    document.body.classList.add('allbat-assistant-panel-mode');
    if (panelModeBooting) return;
    panelModeBooting = true;
    const generation = ++panelModeGeneration;
    resetPanelMessageTracking();
    // Each fresh Home invocation creates a new text conversation. The user explicitly starts
    // Live from the microphone control; invoking the system assistant never auto-starts audio.
    window.setTimeout(async () => {
      try {
        if (generation !== panelModeGeneration || !document.body.classList.contains('allbat-assistant-panel-mode')) return;
        if (typeof newSession === 'function') await Promise.resolve(newSession('text'));
        if (generation !== panelModeGeneration || !document.body.classList.contains('allbat-assistant-panel-mode')) return;
        if (typeof go === 'function') go('chat');
        if (typeof render === 'function') render();
        const input = document.getElementById('inp');
        if (input) {
          input.setAttribute('placeholder', 'Ask Anything........');
          input.setAttribute('dir', 'auto');
          input.setAttribute('aria-label', 'پیام به دستیار');
        }
        installPanelChatEnhancements();
        requestAnimationFrame(() => {
          const messages = document.getElementById('msgs');
          if (messages) {
            messages.scrollTop = messages.scrollHeight;
            panelScrollTop = messages.scrollTop;
            panelStickToBottom = true;
          }
        });
      } catch (error) {
        console.warn('Could not prepare the compact assistant chat', error);
      } finally {
        if (generation === panelModeGeneration) panelModeBooting = false;
      }
    }, 100);
  };

  // Called by the native dock: fills the (hidden) web composer and presses its send button.
  window.__allbatAssistantSend = text => {
    try {
      const input = document.getElementById('inp');
      const button = document.getElementById('sendBtn');
      const value = String(text || '').trim();
      if (!input || !button || !value) return false;
      if (typeof state !== 'undefined' && state.sending) return false;
      const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input), 'value');
      if (setter && setter.set) setter.set.call(input, value); else input.value = value;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      button.click();
      return true;
    } catch (error) { console.warn('Native send failed', error); return false; }
  };

  window.__allbatAssistantSetScreenshot = dataUrl => {
    if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/jpeg;base64,')) return;
    assistantScreenshotDataUrl = dataUrl;
    document.body.classList.add('allbat-has-shot');
    setAssistantStatus('تصویر صفحه آماده است؛ انتخاب کن کدام بخش به پیش‌نویس پیوست شود.');
  };
  window.__allbatAssistantScreenshotUnavailable = () => {
    assistantScreenshotDataUrl = '';
    document.body.classList.remove('allbat-has-shot');
    setAssistantStatus('اسکرین‌شات از برنامهٔ فعلی دریافت نشد؛ ممکن است تنظیمات حریم خصوصی یا سیستم آن را محدود کرده باشد.');
  };
  window.__allbatAssistantClearScreenshot = () => { assistantScreenshotDataUrl = ''; document.body.classList.remove('allbat-has-shot'); };
  window.__allbatAssistantStartRegionSelection = openAssistantRegionSelector;

  function stopCamera() {
    if (cameraTimer) clearInterval(cameraTimer);
    cameraTimer = 0;
    if (cameraStream) {
      try { cameraStream.getTracks().forEach(track => track.stop()); } catch (_) {}
    }
    cameraStream = null;
    cameraActive = false;
    try { previewVideo.pause(); previewVideo.srcObject = null; } catch (_) {}
    preview.style.display = 'none';
    cameraButton.textContent = '📷 روشن‌کردن دوربین زنده';
    try { native && native.stopCameraSession(); } catch (_) {}
    setStatus('دوربین خاموش شد');
  }

  async function startCamera() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setStatus('دسترسی دوربین در این نسخهٔ WebView در دسترس نیست');
      return;
    }
    try {
      setStatus('در انتظار مجوز دوربین…');
      // Camera access from the background (floating bubble) needs the camera foreground service first.
      try { native && native.startCameraSession(); } catch (_) {}
      cameraStream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 640 }, height: { ideal: 480 },
          frameRate: { ideal: 12, max: 15 }
        }
      });
      previewVideo.srcObject = cameraStream;
      await previewVideo.play();
      preview.style.display = 'block';
      cameraActive = true;
      cameraButton.textContent = '⏹ خاموش‌کردن دوربین';
      try { native && native.startCameraSession(); } catch (_) {}
      if (!cameraCanvas) cameraCanvas = document.createElement('canvas');
      const context = cameraCanvas.getContext('2d', { alpha: false });
      cameraTimer = setInterval(() => {
        if (!cameraActive || !previewVideo.videoWidth || !context) return;
        if (!canSendLiveFrame()) return;
        const scale = Math.min(1, 640 / previewVideo.videoWidth);
        cameraCanvas.width = Math.max(1, Math.round(previewVideo.videoWidth * scale));
        cameraCanvas.height = Math.max(1, Math.round(previewVideo.videoHeight * scale));
        try {
          context.drawImage(previewVideo, 0, 0, cameraCanvas.width, cameraCanvas.height);
          const dataUrl = cameraCanvas.toDataURL('image/jpeg', 0.5);
          pushFrame(dataUrl.slice(dataUrl.indexOf(',') + 1));
        } catch (_) {}
      }, 1_150);
      setStatus(canSendLiveFrame() ? 'دوربین آمادهٔ ارسال تصویر است' : 'پیش‌نمایش روشن است؛ برای ارسال تصویر، گفت‌وگوی زنده را شروع کن.');
    } catch (error) {
      stopCamera();
      setStatus('مجوز یا دسترسی دوربین فراهم نشد');
      console.warn('All Bat camera start failed', error);
    }
  }

  cameraButton.addEventListener('click', () => {
    if (cameraActive) stopCamera(); else startCamera();
  });

  screenButton.addEventListener('click', () => {
    if (screenPermissionPending) return;
    if (!native) {
      setAssistantStatus('پل اندروید در دسترس نیست');
      return;
    }
    if (screenShareActive) {
      try { native.stopScreenShare(); } catch (_) { setStatus('توقف اشتراک صفحه ممکن نشد'); }
      return;
    }
    if (!canSendLiveFrame()) {
      screenPermissionPending = false;
      setAssistantStatus('برای اشتراک‌گذاری صفحه، ابتدا گفت‌وگوی زنده را شروع کن؛ سپس همین دکمه را دوباره بزن.');
      return;
    }
    screenPermissionPending = true;
    setAssistantStatus('در انتظار مجوز اعلان و تأیید سیستم برای اشتراک صفحه…');
    try { native.startScreenShare(); }
    catch (_) {
      screenPermissionPending = false;
      setAssistantStatus('شروع اشتراک صفحه ممکن نشد');
    }
  });

  window.__allbatToggleMicrophone = () => {
    try {
      if (typeof toggleLiveMute === 'function') { toggleLiveMute(); return true; }
    } catch (error) { console.warn('Could not toggle Live microphone', error); }
    setAssistantStatus('کنترل میکروفون فقط هنگام فعال بودن گفت‌وگوی زنده در دسترس است.');
    return false;
  };
  window.__allbatToggleCamera = () => {
    try { cameraButton.click(); return true; }
    catch (error) { console.warn('Could not toggle Live camera', error); return false; }
  };
  window.__allbatToggleScreen = () => {
    try { screenButton.click(); return true; }
    catch (error) { console.warn('Could not toggle screen sharing', error); return false; }
  };
  window.__allbatOverlayOpenApp = () => {
    try { if (typeof go === 'function') go('chat'); } catch (_) {}
    try { document.getElementById('inp')?.focus({ preventScroll: true }); } catch (_) {}
    return true;
  };

  window.__assistantNativeFrame = pushFrame;
  window.__assistantNativeScreenStarted = () => {
    screenPermissionPending = false;
    screenShareActive = true;
    screenButton.textContent = '⏹ توقف اشتراک صفحه';
    setAssistantStatus('اشتراک صفحه فعال است؛ فریم‌ها فقط به Live فعال فرستاده می‌شوند');
  };
  window.__assistantNativeScreenStopped = () => {
    screenPermissionPending = false;
    screenShareActive = false;
    screenButton.textContent = '🖥️ اشتراک‌گذاری صفحه';
    setAssistantStatus('اشتراک صفحه متوقف شد');
  };
  window.__assistantNativeScreenDenied = () => {
    screenPermissionPending = false;
    setAssistantStatus('اشتراک صفحه لغو شد');
  };
  window.__allbatStopCurrentResponse = () => {
    try {
      if (typeof state !== 'undefined' && state.voiceConversation && typeof liveStopResponse === 'function') {
        liveStopResponse();
        return true;
      }
      if (typeof state !== 'undefined' && state.sending) {
        const sendButton = document.getElementById('sendBtn');
        if (sendButton && !sendButton.disabled) { sendButton.click(); return true; }
      }
    } catch (error) { console.warn('Could not stop the current response', error); }
    // Do not end the user's Live conversation just because a text response is still generating.
    setAssistantStatus('برای توقف این پاسخ، کنترل توقف را در صفحهٔ گفتگو بررسی کن.');
    return false;
  };

  window.__assistantNativeStopAll = () => {
    try { if (typeof stopVoiceConversation === 'function') stopVoiceConversation(false); } catch (_) {}
    stopCamera();
    try { native && native.stopVoiceSession(); } catch (_) {}
    try { native && native.stopScreenShare(); } catch (_) {}
    setStatus('نشست دستیار متوقف شد');
  };
  window.__assistantNativeStartVoiceConversation = () => {
    try {
      if (typeof state !== 'undefined' && state.voiceConversation) return true;
      if (typeof toggleVoiceConversation === 'function') {
        toggleVoiceConversation();
        setStatus('در حال شروع گفت‌وگوی زنده…');
        return true;
      }
    } catch (error) { console.warn('All Bat assistant launch failed', error); }
    setStatus('برای شروع گفت‌وگوی صوتی، صفحهٔ چت را باز کن');
    return false;
  };

  // Keep Android's foreground service alive only while the user-started Live mic is active.
  // The native layer receives a compact transcript/status snapshot for the floating orb.
  let lastOverlaySignature = '';
  let lastOverlayUser = '';
  let lastOverlayAnswer = '';
  let lastUserChangeAt = 0;
  let lastAnswerChangeAt = 0;
  const readLiveUserText = () => {
    try { return typeof liveTurnUserText === 'string' ? liveTurnUserText.trim() : ''; } catch (_) { return ''; }
  };
  const readLiveAnswerText = () => {
    try { return typeof liveTurnAssistantText === 'string' ? liveTurnAssistantText.trim() : ''; } catch (_) { return ''; }
  };
  function publishOverlayState(active, inputReady = true) {
    if (!native || typeof native.updateAssistantOverlay !== 'function') return;
    const now = Date.now();
    const userText = readLiveUserText();
    const answerText = readLiveAnswerText();
    if (userText !== lastOverlayUser) { lastOverlayUser = userText; lastUserChangeAt = now; }
    if (answerText !== lastOverlayAnswer) { lastOverlayAnswer = answerText; lastAnswerChangeAt = now; }
    const appGenerating = (() => { try { return !!(typeof state !== 'undefined' && state.sending); } catch (_) { return false; } })();
    const micMuted = (() => { try { return !!(typeof state !== 'undefined' && state.voiceMuted); } catch (_) { return false; } })();
    let generating = appGenerating;
    let status = active ? (inputReady ? 'گوش می‌دهم…' : 'در حال بازیابی اتصال صوتی…') : 'دستیار آماده است';
    if (active && inputReady) {
      if (answerText && now - lastAnswerChangeAt < 2100) {
        status = 'در حال پاسخ‌گویی…';
        generating = true;
      } else if (userText && !answerText && now - lastUserChangeAt > 900) {
        status = 'در حال پردازش پاسخ…';
        generating = true;
      } else if (userText && now - lastUserChangeAt < 1200) {
        status = 'در حال شنیدن…';
      }
    } else if (appGenerating) {
      status = 'Just a sec…';
    }
    const signature = JSON.stringify([userText, answerText, status, generating, micMuted, cameraActive, screenShareActive, active]);
    if (signature === lastOverlaySignature) return;
    lastOverlaySignature = signature;
    try {
      native.updateAssistantOverlay(userText, answerText, status, generating, micMuted, cameraActive, screenShareActive);
    } catch (error) { console.warn('Could not update native assistant overlay', error); }
  }
  // The foreground service follows the user's Live-session intent, NOT the current MediaStream.active
  // bit. Android/Chromium can temporarily end or recreate a track while the activity is backgrounded.
  // Previously one transient inactive sample stopped the native foreground service within 650 ms.
  let lastMicRecoveryAt = 0;
  let micRecoveryAttempts = 0;
  setInterval(() => {
    let requested = false;
    let streamReady = false;
    try {
      requested = typeof state !== 'undefined' && !!state.voiceConversation;
      if (typeof liveMicStream !== 'undefined' && liveMicStream) {
        const tracks = typeof liveMicStream.getAudioTracks === 'function' ? liveMicStream.getAudioTracks() : [];
        streamReady = !!liveMicStream.active && tracks.some(track => track && track.readyState === 'live');
      }
    } catch (_) {}

    if (requested && !voiceServiceActive) {
      voiceServiceActive = true;
      lastOverlaySignature = '';
      micRecoveryAttempts = 0;
      try { native && native.startVoiceSession(); } catch (_) {}
    } else if (!requested && voiceServiceActive) {
      // This is the one authoritative hang-up signal: the user or Live engine ended the session.
      voiceServiceActive = false;
      micRecoveryAttempts = 0;
      try { native && native.stopVoiceSession(); } catch (_) {}
    }

    if (requested && !streamReady) {
      const now = Date.now();
      const recoveryDelay = Math.min(15000, 2800 + micRecoveryAttempts * 600);
      if (now - lastMicRecoveryAt > recoveryDelay) {
        lastMicRecoveryAt = now;
        micRecoveryAttempts++;
        // Recovery reuses the existing Live audio graph; it does not create a second conversation.
        try {
          if (typeof liveAudioContext !== 'undefined' && liveAudioContext && liveAudioContext.state === 'suspended') {
            liveAudioContext.resume().catch(() => {});
          }
          if (typeof lvRestartMic === 'function') Promise.resolve(lvRestartMic()).catch(() => {});
        } catch (error) { console.warn('Live microphone recovery attempt failed', error); }
      }
    } else if (streamReady) {
      micRecoveryAttempts = 0;
    }
    publishOverlayState(requested, streamReady);
  }, 650);

  // ---- Live voice stability -------------------------------------------------
  // The page's own reconnect logic can hang forever (fetch without timeout), gives up after a
  // few seconds without internet, and ends the whole call on a transient upstream error.
  (function installLiveStability() {
    try {
      if (typeof liveReconnect !== 'function' || typeof liveScheduleReconnect !== 'function' ||
          typeof liveSetupConfig !== 'function' || typeof handleLiveMessage !== 'function') return;
      const MAX_TRIES = 25;
      let attemptId = 0, lastAttemptAt = 0, waitingOnline = false, wentOffline = false, badSince = 0;
      const timeout = (promise, ms, label) => Promise.race([
        promise, new Promise((_, reject) => setTimeout(() => reject(new Error(label || 'timeout')), ms))
      ]);
      const say = text => { try { voiceStatus(text); } catch (_) {} };

      liveScheduleReconnect = function (ev) {
        if (liveReconnecting || !state.voiceConversation) return;
        if (navigator.onLine === false) {
          waitingOnline = true;
          say('📶 اینترنت قطع است؛ به‌محض وصل شدن ادامه می‌دهم…');
          return;
        }
        if (liveReconnTries >= MAX_TRIES) {
          const code = String((ev && ev.code) || 0);
          stopVoiceConversation(false);
          if (typeof toast === 'function') toast('اتصال Gemini Live برقرار نشد (کد ' + code + ')؛ دوباره گفت‌وگوی صوتی را شروع کن.');
          return;
        }
        liveReconnecting = true;
        liveReconnTries++;
        say('🔄 اتصال قطع شد؛ در حال وصل شدن دوباره…');
        if (liveReconnTries >= 3) lvResume.h = null;
        const delay = lvResume.soft ? 0 : Math.min(300 * liveReconnTries, 4000);
        lvResume.soft = false;
        setTimeout(() => { try { liveReconnect(); } catch (_) { liveReconnecting = false; } }, delay);
      };

      liveReconnect = async function () {
        const mine = ++attemptId;
        lastAttemptAt = Date.now();
        let ws = null;
        try {
          if (!state.voiceConversation) { liveReconnecting = false; return; }
          liveReady = false; liveGenerating = false; liveDropAudio = false; liveTurnOpen = false; liveTurnStopped = false;
          liveResetInputResampler();
          liveStopPlayback();
          try {
            if (liveSocket && liveSocket.readyState <= 1) { liveSocket.onclose = null; liveSocket.close(); }
          } catch (_) {}
          const chat = cur();
          const voice = String((chat && chat.voice) || state.voice || 'Charon');
          const tk = await timeout(api('/api/live-token', { method: 'POST', body: JSON.stringify({ voice, mode: LV_MODEL() }) }), 12000, 'token timeout');
          if (mine !== attemptId) return;
          if (!state.voiceConversation) { liveReconnecting = false; return; }
          if (!tk || !tk.ticket) throw new Error('no ticket');
          ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/api/live-ws?ticket=' + encodeURIComponent(tk.ticket));
          ws.binaryType = 'arraybuffer';
          ws.onmessage = handleLiveMessage;
          liveSocket = ws;
          const thisSocket = ws;
          ws.onclose = ev => {
            if (thisSocket !== liveSocket) return;
            liveReady = false;
            if (!state.voiceConversation) return;
            if (liveSetupReject) {
              if (liveSetupTimer) clearTimeout(liveSetupTimer);
              liveSetupTimer = null;
              const reject = liveSetupReject;
              liveSetupResolve = null; liveSetupReject = null;
              reject(new Error('closed during setup ' + String((ev && ev.code) || 0)));
              return;
            }
            liveScheduleReconnect(ev);
          };
          await new Promise((resolve, reject) => {
            const t = setTimeout(() => reject(new Error('open timeout')), 12000);
            ws.addEventListener('open', () => { clearTimeout(t); resolve(); }, { once: true });
            ws.addEventListener('error', () => { clearTimeout(t); reject(new Error('ws error')); }, { once: true });
            ws.addEventListener('close', () => { clearTimeout(t); reject(new Error('closed before open')); }, { once: true });
          });
          if (mine !== attemptId) { try { ws.close(); } catch (_) {} return; }
          if (!state.voiceConversation) { liveReconnecting = false; try { ws.close(); } catch (_) {} return; }
          ws.send(JSON.stringify(liveSetupConfig(chat, tk.voice || voice)));
          await new Promise((resolve, reject) => {
            liveSetupResolve = resolve; liveSetupReject = reject;
            liveSetupTimer = setTimeout(() => { liveSetupResolve = null; liveSetupReject = null; reject(new Error('setup timeout')); }, 15000);
          });
          liveReconnTries = 0; liveReconnecting = false;
          if (liveAudioContext) liveAudioCursor = liveAudioContext.currentTime;
          say('🎙️ دوباره وصل شد؛ ادامه بده.');
        } catch (error) {
          if (mine !== attemptId) return;
          liveReconnecting = false;
          try { if (ws) { ws.onclose = null; ws.close(); } } catch (_) {}
          if (ws && liveSocket === ws) liveSocket = null;
          if (state.voiceConversation) liveScheduleReconnect(error);
        }
      };

      // A transient upstream error should trigger a reconnect, not hang up the whole call.
      const originalHandle = handleLiveMessage;
      handleLiveMessage = function (event) {
        try {
          let raw = event && event.data;
          if (typeof raw !== 'string') raw = raw && raw.byteLength < 4096 ? new TextDecoder().decode(raw) : '';
          if (raw && raw.length < 4096 && raw.indexOf('"error"') >= 0 && !liveSetupReject && state.voiceConversation) {
            const parsed = JSON.parse(raw);
            if (parsed && parsed.error) {
              console.warn('Live upstream error; reconnecting', parsed.error);
              liveReady = false;
              try { if (liveSocket) liveSocket.close(4002, 'upstream error'); } catch (_) {}
              return;
            }
          }
        } catch (_) {}
        return originalHandle.apply(this, arguments);
      };

      window.addEventListener('offline', () => { wentOffline = true; });
      window.addEventListener('online', () => {
        if (!state.voiceConversation) { wentOffline = false; waitingOnline = false; return; }
        liveReconnTries = 0;
        if (waitingOnline) { waitingOnline = false; wentOffline = false; liveScheduleReconnect(); return; }
        if (wentOffline) {
          wentOffline = false;
          // The old socket may be half-open after a network change; replace it.
          try { if (liveSocket && liveSocket.readyState === WebSocket.OPEN) liveSocket.close(4003, 'network changed'); } catch (_) {}
        }
      });

      // Watchdog: recovers from a stuck attempt or a lost "close" event.
      setInterval(() => {
        try {
          if (!state.voiceConversation) { badSince = 0; return; }
          const healthy = liveSocket && liveSocket.readyState === WebSocket.OPEN && liveReady;
          if (healthy) { badSince = 0; return; }
          if (state.voiceChatBusy && !liveReconnecting) return; // first connection is still being set up
          if (navigator.onLine === false) return;
          if (liveReconnecting) {
            if (Date.now() - lastAttemptAt > 45000) {
              liveReconnecting = false; attemptId++;
              try { if (liveSocket) { liveSocket.onclose = null; liveSocket.close(); } } catch (_) {}
              liveScheduleReconnect();
            }
            return;
          }
          if (!badSince) { badSince = Date.now(); return; }
          if (Date.now() - badSince > 6000) { badSince = 0; liveScheduleReconnect(); }
        } catch (_) {}
      }, 4000);
    } catch (error) { console.warn('Could not install Live stability layer', error); }
  })();

  // ---- Live shutdown guard -----------------------------------------------------------
  // The page's stopVoiceConversation() sets state.voiceConversation=false FIRST and then runs a long
  // chain of cleanup calls without try/catch around all of them. If any step throws, the UI looks
  // idle while the socket, microphone track and AudioContext keep running in the background.
  // 1) stopVoiceConversation is wrapped so cleanup always completes; 2) a watchdog releases any
  // Live resource that is still alive while the UI says no voice chat is active.
  function releaseLiveResources() {
    const attempt = fn => { try { fn(); } catch (_) {} };
    attempt(() => { if (liveSocket) { liveSocket.onclose = null; liveSocket.onerror = null; liveSocket.onmessage = null; liveSocket.close(1000, 'cleanup'); } });
    attempt(() => { liveSocket = null; });
    attempt(() => { liveStopInputPump(); });
    attempt(() => { if (liveProcessor) { liveProcessor.onaudioprocess = null; liveProcessor.disconnect(); } });
    attempt(() => { liveProcessor = null; });
    attempt(() => { if (liveMicSource) liveMicSource.disconnect(); });
    attempt(() => { liveMicSource = null; });
    attempt(() => { if (liveMuteGain) liveMuteGain.disconnect(); });
    attempt(() => { liveMuteGain = null; });
    attempt(() => { if (liveMicStream) liveMicStream.getTracks().forEach(track => track.stop()); });
    attempt(() => { liveMicStream = null; });
    attempt(() => { liveStopPlayback(); });
    attempt(() => { if (liveAudioContext && liveAudioContext.state !== 'closed') liveAudioContext.close(); });
    attempt(() => { liveAudioContext = null; });
    attempt(() => { liveReady = false; liveReconnecting = false; });
    attempt(() => { lvMediaSessionStop(); });
    attempt(() => { lvSessionStop(); });
    attempt(() => { voiceServiceActive = false; if (native && typeof native.stopVoiceSession === 'function') native.stopVoiceSession(); });
  }

  try {
    if (typeof stopVoiceConversation === 'function' && !stopVoiceConversation.__allBatSafeStop) {
      const originalStop = stopVoiceConversation;
      const safeStop = function () {
        let result;
        try { result = originalStop.apply(this, arguments); }
        catch (error) {
          console.warn('stopVoiceConversation threw; forcing full cleanup', error);
          try { state.voiceConversation = false; state.voiceMuted = false; state.voiceChatBusy = false; } catch (_) {}
          try { if (typeof refreshSendState === 'function') refreshSendState(); } catch (_) {}
        }
        releaseLiveResources();
        return result;
      };
      safeStop.__allBatSafeStop = true;
      stopVoiceConversation = safeStop;
    }
  } catch (error) { console.warn('Could not install the safe Live stop wrapper', error); }

  let liveOrphanSince = 0;
  setInterval(() => {
    let orphan = false;
    try {
      const wanted = typeof state !== 'undefined' && (!!state.voiceConversation || !!state.voiceChatBusy);
      if (!wanted) {
        const socketAlive = !!(liveSocket && liveSocket.readyState <= 1);
        const micAlive = !!(liveMicStream && liveMicStream.getTracks().some(track => track.readyState === 'live'));
        const contextAlive = !!(liveAudioContext && liveAudioContext.state !== 'closed');
        orphan = socketAlive || micAlive || contextAlive;
      }
    } catch (_) {}
    if (!orphan) { liveOrphanSince = 0; return; }
    const now = Date.now();
    if (!liveOrphanSince) { liveOrphanSince = now; return; }
    if (now - liveOrphanSince > 2500) {
      liveOrphanSince = 0;
      console.warn('Orphaned Live resources found while the UI is idle; releasing them');
      releaseLiveResources();
    }
  }, 1000);

  // If a native stop was ever lost while the app was in the background, repeat it once we are visible.
  document.addEventListener('visibilitychange', () => {
    try {
      if (document.visibilityState !== 'visible') return;
      if (typeof state !== 'undefined' && (state.voiceConversation || state.voiceChatBusy)) return;
      if (native && typeof native.stopVoiceSession === 'function') native.stopVoiceSession();
    } catch (_) {}
  });

  // Native device tools are exposed to Gemini Live as real function declarations.
  // The model chooses the function and arguments; Android executes only this allow-list.
  const DEVICE_FUNCTION_DECLARATIONS = [
    {
      name: 'call_contact',
      description: 'Place a phone call to a saved contact by name. Call only when the user explicitly asks to call now, not when asking a question or discussing a hypothetical call. The Android tool initiates the call directly after permission has been granted. If several contacts match (for example "Ali" matches "Ali Mohammadi" and "Ali Rezaei"), the tool returns a numbered list: read the numbered options to the user, e.g. "Ali 1 or Ali 2?", wait for the answer, then call again with choice.',
      parameters: { type: 'OBJECT', properties: { name: { type: 'STRING', description: 'Exact or distinctive saved contact name' }, choice: { type: 'INTEGER', description: 'Only after the tool reported several matching contacts and the user picked one: the 1-based number of the chosen contact. Never guess it.' } }, required: ['name'] }
    },
    {
      name: 'navigate_to',
      description: 'Open turn-by-turn navigation or show a place in the installed map app (any maps app, no Google service required). Use when the user asks to go to, route to or show an address/place.',
      parameters: { type: 'OBJECT', properties: { destination: { type: 'STRING', description: 'Place name or address as the user said it' } }, required: ['destination'] }
    },
    {
      name: 'web_search',
      description: 'Open a web search (DuckDuckGo) or a given http/https link in the phone browser. Use for requests to search the web or open a site.',
      parameters: { type: 'OBJECT', properties: { query: { type: 'STRING', description: 'Search words' }, url: { type: 'STRING', description: 'Full http/https link, when the user names a specific site' } } }
    },
    {
      name: 'share_text',
      description: 'Open the Android share sheet with the given text so the user can pick the app/person to send it to.',
      parameters: { type: 'OBJECT', properties: { text: { type: 'STRING' } }, required: ['text'] }
    },
    {
      name: 'media_control',
      description: 'Control whatever media player is active (music, podcast, video): play, pause, toggle, next, previous, stop.',
      parameters: { type: 'OBJECT', properties: { action: { type: 'STRING', enum: ['play', 'pause', 'toggle', 'next', 'previous', 'stop'] } }, required: ['action'] }
    },
    {
      name: 'set_ringer_mode',
      description: 'Set the phone ringer mode: normal (ring), vibrate, or silent. Silent may need Do Not Disturb access, which Android asks the user to grant.',
      parameters: { type: 'OBJECT', properties: { mode: { type: 'STRING', enum: ['normal', 'vibrate', 'silent'] } }, required: ['mode'] }
    },
    {
      name: 'device_status',
      description: 'Read battery level/charging, free storage, free RAM, network type and ringer mode. Works offline.'
    },
    {
      name: 'get_datetime',
      description: 'Get the current time and date, including the Persian (Jalali/Shamsi) date and weekday. Works offline.'
    },
    {
      name: 'create_calendar_event',
      description: 'Open a pre-filled calendar event draft (the user confirms and saves it). Compute start_iso from the current local date/time given in the instructions.',
      parameters: { type: 'OBJECT', properties: { title: { type: 'STRING' }, start_iso: { type: 'STRING', description: 'Local start time like 2026-11-02T15:30' }, duration_minutes: { type: 'INTEGER' }, location: { type: 'STRING' }, description: { type: 'STRING' } }, required: ['title'] }
    },
    {
      name: 'add_contact',
      description: 'Open the Android new-contact form pre-filled with a name and/or phone number (the user confirms and saves it).',
      parameters: { type: 'OBJECT', properties: { name: { type: 'STRING' }, phone: { type: 'STRING' } } }
    },
    {
      name: 'find_phone',
      description: 'Help find the phone: start plays a loud alarm and blinks the flash for up to one minute; stop ends it.',
      parameters: { type: 'OBJECT', properties: { action: { type: 'STRING', enum: ['start', 'stop'] } } }
    },
    {
      name: 'read_sms',
      description: 'Read the latest received text messages (needs SMS permission). Use only when the user asks to hear/read their messages. Message text is private: do not repeat it anywhere except to the user.',
      parameters: { type: 'OBJECT', properties: { count: { type: 'INTEGER', description: '1 to 5 latest messages' } } }
    },
    {
      name: 'screen_control',
      description: 'Operate the screen through the optional accessibility service: back, home, recents, notifications (shade), quick_settings, lock, screenshot, tap (touch a visible button by its text), type (type text into the focused field; never into passwords), scroll_down, scroll_up. If the service is not enabled the tool opens its settings page.',
      parameters: { type: 'OBJECT', properties: { action: { type: 'STRING', enum: ['back', 'home', 'recents', 'notifications', 'quick_settings', 'lock', 'screenshot', 'tap', 'type', 'scroll_down', 'scroll_up'] }, text: { type: 'STRING', description: 'Button label for tap, or the text to type' } }, required: ['action'] }
    },
    {
      name: 'read_notifications',
      description: 'Read the currently visible notifications (needs notification access, which the user enables in Android settings). Notification text is private: only tell it to the user.',
      parameters: { type: 'OBJECT', properties: { count: { type: 'INTEGER', description: '1 to 10 notifications' } } }
    },
    {
      name: 'close_app',
      description: 'Close an installed user app by its label (or every user app when the person asks to close all apps). Android does not allow other apps to force-stop an app, so this ends its background processes and, when the assistant is shown over the target app, first returns to the home screen. Say honestly that an app may restart itself. This is a device action: call the function.',
      parameters: { type: 'OBJECT', properties: { app_name: { type: 'STRING', description: 'Installed app display name or package identifier' }, all: { type: 'BOOLEAN', description: 'true only when the person explicitly asks to close all apps' } } }
    },
    {
      name: 'install_offline_speech',
      description: 'Install the offline Persian speech-recognition engine (about 53 MB, needs internet once) so voice commands also work without internet, or open Android\'s page for installing offline text-to-speech voices. Call only when the person asks to install or enable offline voice/speech.',
      parameters: { type: 'OBJECT', properties: { component: { type: 'STRING', enum: ['recognition', 'voice'], description: 'recognition = offline speech-to-text engine (default); voice = Android offline text-to-speech voice data' } } }
    },
    {
      name: 'open_app',
      description: 'Open any installed Android app that has a launcher icon. Use the app label visible on the phone or its package name. This is a device action: call the function rather than telling the user how to open it.',
      parameters: { type: 'OBJECT', properties: { app_name: { type: 'STRING', description: 'Installed app display name or package identifier, in the language shown by Android' } }, required: ['app_name'] }
    },
    {
      name: 'set_volume',
      description: 'Adjust media volume on the phone.',
      parameters: { type: 'OBJECT', properties: { action: { type: 'STRING', enum: ['up', 'down', 'mute', 'unmute'] }, steps: { type: 'INTEGER', description: 'Number of volume steps from 1 to 10' } }, required: ['action'] }
    },
    {
      name: 'set_flashlight',
      description: 'Turn the phone flashlight on or off.',
      parameters: { type: 'OBJECT', properties: { enabled: { type: 'BOOLEAN' } }, required: ['enabled'] }
    },
    {
      name: 'set_connection',
      description: 'Open the Android system Internet panel or Bluetooth approval/settings for Wi-Fi, Bluetooth, or mobile data. For Wi-Fi and mobile data this opens the system internet panel; never claim the radio changed unless the system reports/visibly confirms it. Android may require the user to finish the change.',
      parameters: { type: 'OBJECT', properties: { type: { type: 'STRING', enum: ['wifi', 'bluetooth', 'mobile_data'] }, enabled: { type: 'BOOLEAN' } }, required: ['type', 'enabled'] }
    },
    {
      name: 'set_alarm',
      description: 'Create a system alarm at a specific local time using the Clock app integration. Android Clock may honor the request without showing its UI; report success only from the tool result.',
      parameters: { type: 'OBJECT', properties: { hour: { type: 'INTEGER', description: 'Hour from 0 to 23' }, minute: { type: 'INTEGER', description: 'Minute from 0 to 59' }, label: { type: 'STRING' } }, required: ['hour', 'minute'] }
    },
    {
      name: 'set_timer',
      description: 'Create a system timer in seconds using the Clock app integration. Android Clock may honor the request without showing its UI; report success only from the tool result.',
      parameters: { type: 'OBJECT', properties: { seconds: { type: 'INTEGER', description: 'Duration from 1 to 86400 seconds' }, label: { type: 'STRING' } }, required: ['seconds'] }
    },
    {
      name: 'open_settings',
      description: 'Open an Android system settings section.',
      parameters: { type: 'OBJECT', properties: { section: { type: 'STRING', enum: ['main', 'wifi', 'bluetooth', 'sound', 'apps', 'display', 'battery', 'assistant'], description: 'assistant = choose the default digital assistant / enable holding the power button for it' } }, required: ['section'] }
    },
    {
      name: 'create_sms_draft',
      description: 'Prepare an SMS addressed to a saved contact and show the native editable confirmation card. Never send automatically; the user must review the recipient and message and explicitly tap Send in the card.',
      parameters: { type: 'OBJECT', properties: { name: { type: 'STRING' }, message: { type: 'STRING' }, choice: { type: 'INTEGER', description: 'Only after several contacts matched and the user picked one: the 1-based number of the chosen contact.' } }, required: ['name', 'message'] }
    }
  ];

  function installDeviceToolCalling() {
    try {
      if (typeof liveSetupConfig === 'function' && !liveSetupConfig.__allBatToolsWrapped) {
        const originalSetup = liveSetupConfig;
        const wrappedSetup = function () {
          const result = originalSetup.apply(this, arguments);
          const setup = result && result.setup;
          if (setup) {
            const currentTools = Array.isArray(setup.tools) ? setup.tools.slice() : [];
            currentTools.push({ functionDeclarations: DEVICE_FUNCTION_DECLARATIONS });
            setup.tools = currentTools;
            const parts = setup.systemInstruction && Array.isArray(setup.systemInstruction.parts)
              ? setup.systemInstruction.parts : null;
            if (parts && parts.length) {
              parts[0].text = String(parts[0].text || '') +
                '\n\n' + deviceClockLine() + '\n\nANDROID DEVICE AGENT: You have native Android tools. When the user asks you to perform a phone action, choose and call the appropriate function instead of merely describing how. You may call multiple tools in sequence when needed. Wait for each function response before claiming success. Never invent tool results. For an unambiguous call_contact request, place the call directly; do not ask the user to press another Call button after the tool succeeds. Ask which contact only when the match is ambiguous. For network settings, explain when Android itself requires the user to approve or finish the change. SMS is draft-only and must never be sent without the user tapping Send.';
            }
          }
          return result;
        };
        wrappedSetup.__allBatToolsWrapped = true;
        liveSetupConfig = wrappedSetup;
      }

      if (typeof handleLiveMessage === 'function' && !handleLiveMessage.__allBatToolsWrapped) {
        const originalHandler = handleLiveMessage;
        const wrappedHandler = function (event) {
          let incoming = null;
          try {
            const raw = event && event.data;
            incoming = typeof raw === 'string' ? JSON.parse(raw) : raw;
          } catch (_) { incoming = null; }
          const functionCalls = incoming && incoming.toolCall && Array.isArray(incoming.toolCall.functionCalls)
            ? incoming.toolCall.functionCalls : null;
          if (functionCalls && functionCalls.length) {
            // Keep the reply on the same Live WebSocket that delivered the tool call.
            const responseSocket = this && typeof this.send === 'function' ? this : liveSocket;
            void (async () => {
              const functionResponses = [];
              for (const call of functionCalls.slice(0, 8)) {
                const executed = executeDeviceFunctionCall(call);
                functionResponses.push(executed);
              }
              try {
                if (responseSocket && responseSocket.readyState === WebSocket.OPEN) {
                  responseSocket.send(JSON.stringify({ toolResponse: { functionResponses } }));
                  setAssistantStatus('نتیجهٔ ابزار به مدل برگشت؛ در حال ادامهٔ مکالمه…');
                }
              } catch (error) {
                console.warn('Could not return Android tool results to Live model', error);
                setAssistantStatus('ابزار اجرا شد، اما نتیجه به مدل برنگشت؛ اتصال صوتی را بررسی کن.');
              }
            })();
            return;
          }
          return originalHandler.apply(this, arguments);
        };
        wrappedHandler.__allBatToolsWrapped = true;
        handleLiveMessage = wrappedHandler;
      }
    } catch (error) {
      console.warn('All Bat device tool calling could not be installed', error);
    }
  }

  installDeviceToolCalling();

  function parseDeviceToolResult(raw) {
    try { return JSON.parse(String(raw || '{}')); }
    catch (_) { return { ok: false, message: 'پاسخ ابزار اندروید قابل خواندن نیست.' }; }
  }

  function executeDeviceFunctionCall(call) {
    const name = String(call && call.name || '');
    const id = String(call && call.id || '');
    let result;
    try {
      if (!native || typeof native.executeDeviceTool !== 'function') {
        result = { ok: false, message: 'پل بومی اندروید در دسترس نیست.' };
      } else {
        const args = call && call.args && typeof call.args === 'object' ? call.args : {};
        result = parseDeviceToolResult(native.executeDeviceTool(name, JSON.stringify(args)));
      }
    } catch (error) {
      result = { ok: false, message: String(error && error.message || 'اجرای ابزار ناموفق بود').slice(0, 240) };
    }
    return { id, name, response: result || { ok: false, message: 'ابزار نتیجه‌ای برنگرداند.' } };
  }

  // ---- Ambiguous contact: ask which one ---------------------------------------------
  // Native returns data.action === 'contact_choice_required' with numbered choices. In text mode, the
  // system-assistant panel and offline mode a native-looking sheet asks the user; in Live voice the
  // model reads the numbered options aloud and calls the tool again with `choice`.
  const toFaDigits = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
  function showContactChoiceDialog(choices, toolName) {
    return new Promise(resolve => {
      try {
        const previous = document.getElementById('allbat-contact-choice');
        if (previous) previous.remove();
        const dark = document.documentElement.classList.contains('dark') ||
          (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches && !document.documentElement.classList.contains('light'));
        const bg = dark ? '#202226' : '#ffffff', fg = dark ? '#f1f2f4' : '#14161a';
        const btnBg = dark ? '#2f3338' : '#eef2f8', btnBorder = dark ? '#40454c' : '#d5dce8';
        const wrap = document.createElement('div');
        wrap.id = 'allbat-contact-choice';
        wrap.setAttribute('dir', 'rtl');
        wrap.setAttribute('role', 'dialog');
        wrap.setAttribute('aria-modal', 'true');
        wrap.style.cssText = 'position:fixed;inset:0;z-index:2147483000;display:flex;align-items:flex-end;justify-content:center;background:rgba(0,0,0,.45);';
        const card = document.createElement('div');
        card.style.cssText = 'width:100%;max-width:520px;max-height:80vh;overflow:auto;box-sizing:border-box;border-radius:22px 22px 0 0;padding:18px 16px calc(16px + env(safe-area-inset-bottom,0px));box-shadow:0 -8px 30px rgba(0,0,0,.3);font-family:inherit;background:' + bg + ';color:' + fg + ';';
        const title = document.createElement('div');
        title.textContent = toolName === 'create_sms_draft' ? 'برای پیامک، کدام مخاطب؟' : 'با کدام مخاطب تماس بگیرم؟';
        title.style.cssText = 'font-size:17px;font-weight:700;margin:0 4px 12px;';
        card.appendChild(title);
        let finished = false;
        let timer = 0;
        const done = value => {
          if (finished) return;
          finished = true;
          if (timer) clearTimeout(timer);
          try { wrap.remove(); } catch (_) {}
          resolve(value);
        };
        (Array.isArray(choices) ? choices.slice(0, 8) : []).forEach((item, i) => {
          const index = Number(item && item.index) || (i + 1);
          const button = document.createElement('button');
          button.type = 'button';
          button.style.cssText = 'display:flex;width:100%;align-items:center;justify-content:space-between;gap:12px;margin:0 0 8px;padding:14px 14px;border-radius:14px;border:1px solid ' + btnBorder + ';background:' + btnBg + ';color:' + fg + ';font:inherit;font-size:16px;text-align:right;cursor:pointer;';
          const label = document.createElement('span');
          label.textContent = toFaDigits(index) + '. ' + String((item && item.name) || '');
          const hint = document.createElement('span');
          hint.textContent = String((item && item.hint) || '');
          hint.style.cssText = 'opacity:.65;font-size:13px;direction:ltr;unicode-bidi:plaintext;';
          button.appendChild(label); button.appendChild(hint);
          button.addEventListener('click', () => done(index));
          card.appendChild(button);
        });
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.textContent = 'لغو';
        cancel.style.cssText = 'width:100%;margin-top:4px;padding:13px;border-radius:14px;border:0;background:transparent;color:' + fg + ';font:inherit;font-size:16px;opacity:.75;cursor:pointer;';
        cancel.addEventListener('click', () => done(0));
        card.appendChild(cancel);
        wrap.appendChild(card);
        wrap.addEventListener('click', event => { if (event.target === wrap) done(0); });
        (document.body || document.documentElement).appendChild(wrap);
        timer = setTimeout(() => done(0), 60000);
      } catch (error) {
        console.warn('Could not show contact chooser', error);
        resolve(0);
      }
    });
  }

  // Same as executeDeviceFunctionCall, but resolves "which contact?" by asking the user on screen.
  async function executeDeviceFunctionCallInteractive(call) {
    let executed = executeDeviceFunctionCall(call);
    for (let round = 0; round < 2; round++) {
      const data = executed && executed.response && executed.response.data;
      if (!data || data.action !== 'contact_choice_required' || !Array.isArray(data.choices) || !data.choices.length) break;
      const picked = await showContactChoiceDialog(data.choices, String(call && call.name || ''));
      if (!picked) {
        return { id: executed.id, name: executed.name, response: { ok: false, cancelled: true, message: 'کاربر مخاطبی را انتخاب نکرد؛ عملیات لغو شد.' } };
      }
      const baseArgs = call && call.args && typeof call.args === 'object' ? call.args : {};
      executed = executeDeviceFunctionCall({ id: call && call.id, name: call && call.name, args: Object.assign({}, baseArgs, { choice: picked }) });
    }
    return executed;
  }

  function deviceClockLine() {
    try {
      const d = new Date();
      const pad = n => String(n).padStart(2, '0');
      const iso = d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());
      return 'Current local date/time on the phone: ' + iso + ' (' + ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][d.getDay()] + '). Use it to resolve words like today, tomorrow, tonight.';
    } catch (_) { return ''; }
  }

  function looksLikeDeviceAction(text) {
    const value = String(text || '').trim().toLowerCase();
    // This is only a cheap routing hint; the model, not this regular expression,
    // decides which native operation (if any) is actually appropriate.
    const action = /(تماس بگیر|زنگ بزن|زنگ بگیر|شماره بگیر|باز کن|بازش کن|بازش\s*کن|اجرا کن|لانچ کن|راه\s*اندازی کن|بیار بالا|وارد شو|برو تو|برو به|روشن کن|روشنش کن|خاموش کن|خاموشش کن|فعال کن|غیرفعال کن|وصل کن|وصل شو|قطع کن|قطعش کن|کم کن|کمتر کن|زیاد کن|بیشتر کن|بی\s*صدا کن|ساکت کن|تنظیم کن|بذار|قرار بده|ایجاد کن|اضافه کن|بساز|ببند|ببندش|ببندی|ببندید|بسته\s*کن|نصب\s*کن|بفرست|ارسال کن|پیام بده|پیامک بده|پیامک بفرست|اس\s*ام\s*اس\s*(?:بده|بفرست|ارسال کن)|یادآور بذار|آلارم بذار|تایمر بذار|call|phone|open|launch|close|quit|kill|install|turn on|turn off|switch on|switch off|send a message|send text|text|set|create|start|enable|disable|mute|unmute|increase|decrease|raise|lower)/i;
    const device = /(مخاطب|تماس|زنگ|شماره|برنامه|اپلیکیشن|اپ\b|وای\s*فای|wifi|wi-?fi|بلوتوث|bluetooth|اینترنت|دیتا|mobile data|چراغ.?قوه|فلش گوشی|صدا|ولوم|volume|آلارم|زنگ هشدار|تایمر|پیامک|پیام|اس\s*ام\s*اس|sms|تنظیمات|settings|دوربین|گالری|ماشین\s*حساب|ساعت)/i;
    // App labels are arbitrary (YouTube, Maps, a Persian bank app, etc.); do not
    // require them to appear in a hard-coded list before asking the model.
    const openAppIntent = /(?:باز\s*کن|بازش\s*کن|اجرا\s*کن|لانچ\s*کن|بیار\s*بالا|open|launch)\s+.{1,90}/i.test(value) ||
      /.{1,90}\s+(?:رو|را)\s+(?:باز\s*کن|اجرا\s*کن|لانچ\s*کن)/i.test(value);
    const explicitPhoneAction = /(تماس|زنگ|مخاطب|پیامک|اس\s*ام\s*اس|sms|wifi|wi-?fi|وای\s*فای|بلوتوث|bluetooth|اینترنت|دیتا|چراغ.?قوه|ولوم|volume|آلارم|تایمر|یادآور|تنظیمات|settings|آفلاین|گفتار|call|phone|contact|message|text message)/i.test(value);
    const closeAppIntent = /(?:ببند|ببندش|ببندی|ببندید|بسته\s*کن|close|quit)\s*.{0,90}/i.test(value) && /(?:رو|را|برنامه|اپ|app|همه|تمام|close|quit|ببند)/i.test(value);
    const extraIntent = /(مسیریابی|مسیر\s+(?:تا|به)|برو\s*به\s+\S+|آهنگ\s*(?:بعدی|قبلی)|موزیک|مکث|ویبره|لرزش|حالت\s*(?:بی\s*صدا|سایلنت)|باتری|ساعت\s*چند|تاریخ|امروز\s*چند|گوشی\s*(?:م|منو|من)?\s*(?:رو\s*)?پیدا|گوشیم\s*کجا|بخون|بخوان|اعلان|نوتیف|اسکرین\s*شات|صفحه\s*اصلی|برگرد|جستجو\s*کن|سرچ\s*کن|تایپ\s*کن|روی\s+.+\s+(?:بزن|کلیک|لمس)|تقویم|رویداد|جلسه|قرار\s+(?:بذار|بگذار)|مخاطب\s*جدید|ذخیره\s*کن|به\s*اشتراک|شیر\s*کن|اسکرول|قفل\s*کن|navigate|directions|screenshot|battery|what time|notifications|find my phone)/i.test(value);
    return (action.test(value) && (device.test(value) || openAppIntent || closeAppIntent || explicitPhoneAction)) || extraIntent;
  }

  async function runOneShotDeviceAgent(text, chat) {
    // The page's own Live setup uses AUDIO output (text-only is rejected by native-audio models), so
    // start with AUDIO + output transcription (audio is discarded, text kept) and fall back to TEXT.
    try {
      return await runOneShotDeviceAgentWith(text, chat, 'AUDIO');
    } catch (firstError) {
      if (firstError && (firstError.deviceToolExecuted || firstError.networkDown)) throw firstError;
      console.warn('AUDIO-modality tool session failed; retrying with TEXT', firstError);
      return await runOneShotDeviceAgentWith(text, chat, 'TEXT');
    }
  }

  async function runOneShotDeviceAgentWith(text, chat, modality) {
    if (!native || typeof native.executeDeviceTool !== 'function' || typeof api !== 'function' ||
        typeof WebSocket === 'undefined') return { attempted: false };
    let socket = null;
    let toolUsed = false;
    let finished = false;
    let setupResolve = null;
    let setupReject = null;
    let turnResolve = null;
    let turnReject = null;
    let timeout = 0;
    let finalText = '';
    const finish = (error, value) => {
      if (finished) return;
      finished = true;
      if (timeout) clearTimeout(timeout);
      try { if (socket) socket.close(); } catch (_) {}
      if (error && setupReject) {
        const rejectSetup = setupReject;
        setupResolve = setupReject = null;
        rejectSetup(error);
      }
      if (error) turnReject && turnReject(error);
      else turnResolve && turnResolve(value);
    };
    try {
      const voice = String((chat && chat.voice) || (typeof state !== 'undefined' && state.voice) || 'Charon');
      const mode = (typeof LV_MODEL === 'function' && LV_MODEL() === 'advanced') ? 'advanced' : 'standard';
      let tokenResult;
      try { tokenResult = await api('/api/live-token', { method: 'POST', body: JSON.stringify({ voice, mode }) }); }
      catch (netErr) { try { netErr.networkDown = true; } catch (_) {} throw netErr; }
      if (!tokenResult || !tokenResult.ticket) throw new Error('بلیت نشست ابزار از سرور دریافت نشد.');
      const url = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/api/live-ws?ticket=' + encodeURIComponent(tokenResult.ticket);
      socket = new WebSocket(url);
      socket.binaryType = 'arraybuffer';
      const setupReady = new Promise((resolve, reject) => { setupResolve = resolve; setupReject = reject; });
      const turnDone = new Promise((resolve, reject) => { turnResolve = resolve; turnReject = reject; });
      // Attach a rejection observer immediately; the promise is awaited after the setup handshake.
      void turnDone.catch(() => {});
      socket.onmessage = event => {
        let message;
        try {
          const raw = event && event.data;
          message = typeof raw === 'string' ? JSON.parse(raw) : null;
        } catch (_) { return; }
        if (message && message.error) {
          const err = new Error(String(message.error.message || message.error).slice(0, 220));
          if (setupReject) { setupReject(err); setupResolve = setupReject = null; }
          else finish(err);
          return;
        }
        if (message && message.setupComplete) {
          if (setupResolve) { const resolve = setupResolve; setupResolve = setupReject = null; resolve(); }
          return;
        }
        const calls = message && message.toolCall && Array.isArray(message.toolCall.functionCalls)
          ? message.toolCall.functionCalls : null;
        if (calls && calls.length) {
          toolUsed = true;
          void (async () => {
            const responses = [];
            for (const call of calls.slice(0, 8)) responses.push(await executeDeviceFunctionCallInteractive(call));
            if (socket && socket.readyState === WebSocket.OPEN) {
              socket.send(JSON.stringify({ toolResponse: { functionResponses: responses } }));
            } else {
              finish(new Error('اتصال نشست ابزار پیش از بازگشت نتیجه بسته شد.'));
            }
          })();
          return;
        }
        const content = message && message.serverContent;
        if (content) {
          const parts = content.modelTurn && Array.isArray(content.modelTurn.parts) ? content.modelTurn.parts : [];
          for (const part of parts) if (typeof part.text === 'string') finalText += part.text;
          if (content.outputTranscription && typeof content.outputTranscription.text === 'string') finalText += content.outputTranscription.text;
          if (content.turnComplete) finish(null, { attempted: true, toolUsed, text: finalText.trim() });
        }
      };
      socket.onerror = () => finish(new Error('اتصال نشست ابزار با سرور برقرار نشد.'));
      socket.onclose = event => {
        if (!finished) finish(new Error('اتصال نشست ابزار پیش از تکمیل درخواست بسته شد.'));
      };
      await Promise.race([
        new Promise((resolve, reject) => {
          socket.addEventListener('open', resolve, { once: true });
          socket.addEventListener('error', () => reject(new Error('اتصال ابزار باز نشد.')), { once: true });
        }),
        new Promise((_, reject) => setTimeout(() => reject(Object.assign(new Error('اتصال ابزار بیش از حد طول کشید.'), { networkDown: true })), 8000))
      ]);
      // Build a dedicated text-only Live setup here instead of relying on the voice UI's
      // liveSetupConfig wrapper. This guarantees that ordinary chat and the system-assistant
      // composer receive the same native tool declarations as an active voice session.
      const selectedModel = String(tokenResult.model || (mode === 'advanced' ? 'gemini-3.8-live-extended-thinking' : 'gemini-3.8-live'));
      const setupPacket = { setup: {
        model: selectedModel.startsWith('models/') ? selectedModel : 'models/' + selectedModel,
        generationConfig: { responseModalities: [modality === 'AUDIO' ? 'AUDIO' : 'TEXT'], maxOutputTokens: 1400 },
        ...(modality === 'AUDIO' ? { outputAudioTranscription: {} } : {}),
        tools: [{ functionDeclarations: DEVICE_FUNCTION_DECLARATIONS }],
        systemInstruction: { parts: [{ text:
          deviceClockLine() + ' You are the device-control agent for All Bat on Android. Use the supplied native function declarations whenever the user asks to perform an action on their phone. Choose the correct function and arguments yourself; you may call multiple functions in sequence. Do not merely explain how to do an action. Never claim an action succeeded before receiving its function response. If the message is not a phone action supported by these functions, output exactly NO_DEVICE_TOOL. Match Persian contact/app names as spoken, ask a short clarification only when the target is ambiguous; when several contacts match, the app itself shows the user a numbered picker and returns the chosen result. For SMS, create the preview only; the Android app requires the user to review and tap Send.'
        }] }
      } };
      socket.send(JSON.stringify(setupPacket));
      await Promise.race([setupReady, new Promise((_, reject) => setTimeout(() => reject(new Error('تأیید نشست ابزار دریافت نشد.')), 20000))]);
      timeout = setTimeout(() => finish(new Error('زمان اجرای درخواست دستگاه به پایان رسید.')), 160000);
      socket.send(JSON.stringify({ clientContent: { turns: [{ role: 'user', parts: [{ text:
        'این یک درخواست برای کنترل دستگاه اندروید است. اگر واقعاً به یک عملیات روی گوشی مربوط می‌شود، از ابزارهای دستگاه استفاده کن. اگر درخواست با ابزارهای دستگاه مرتبط نیست، دقیقاً فقط بنویس NO_DEVICE_TOOL و هیچ پاسخ دیگری نده. متن درخواست کاربر: ' + String(text || '').slice(0, 3000)
      }] }], turnComplete: true } }));
      return await turnDone;
    } catch (error) {
      try { error.deviceToolExecuted = toolUsed; } catch (_) {}
      try { if (socket) socket.close(); } catch (_) {}
      throw error;
    }
  }

  // ---- Offline direct-command mode -------------------------------------------------
  // With no internet the model cannot choose tools, so a small local parser maps clear commands
  // (call, SMS draft, open app, flashlight, volume, Wi-Fi/Bluetooth, timer, alarm) to the SAME
  // allow-listed native tools. Anything unclear is queued; when the connection returns, executed
  // commands are logged into the chat and fresh unexecuted ones are handed to the AI agent.
  const OFFLINE_QUEUE_KEY = 'allbat.offlineQueue.v1';
  const OFFLINE_STALE_MS = 3 * 60 * 1000;
  const isOffline = () => { try { return navigator.onLine === false || probeOffline; } catch (_) { return probeOffline; } };
  const loadOfflineQueue = () => { try { const q = JSON.parse(localStorage.getItem(OFFLINE_QUEUE_KEY) || '[]'); return Array.isArray(q) ? q : []; } catch (_) { return []; } };
  const saveOfflineQueue = q => { try { localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(q.slice(-20))); } catch (_) {} };
  const pushOfflineQueue = entry => { const q = loadOfflineQueue(); q.push(entry); saveOfflineQueue(q); };

  const APP_ALIASES = {
    'دوربین': ['Camera', 'دوربین'], 'گالری': ['Gallery', 'Photos', 'گالری'], 'ماشین حساب': ['Calculator', 'ماشین حساب'],
    'ساعت': ['Clock', 'ساعت'], 'مرورگر': ['Chrome', 'Browser', 'Internet', 'مرورگر'], 'مخاطبین': ['Contacts', 'مخاطبین'],
    'پیامک': ['Messages', 'پیام‌ها', 'پیامک'], 'تقویم': ['Calendar', 'تقویم'], 'یادداشت': ['Notes', 'یادداشت']
  };

  function normalizeFa(input) {
    return String(input || '')
      .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - 0x06F0))
      .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))
      .replace(/ي/g, 'ی').replace(/ك/g, 'ک')
      .replace(/[\u200c\u200f\u200e]/g, ' ')
      .toLowerCase().replace(/[،؛,:!?؟.]+/g, ' ').replace(/\s+/g, ' ').trim();
  }
  // Persian number words (voice recognition often returns words, not digits): "پنج دقیقه" -> "5 دقیقه".
  const FA_ONES = { 'صفر': 0, 'یک': 1, 'دو': 2, 'سه': 3, 'چهار': 4, 'پنج': 5, 'شش': 6, 'هفت': 7, 'هشت': 8, 'نه': 9, 'ده': 10,
    'یازده': 11, 'دوازده': 12, 'سیزده': 13, 'چهارده': 14, 'پانزده': 15, 'شانزده': 16, 'هفده': 17, 'هجده': 18, 'نوزده': 19 };
  const FA_TENS = { 'بیست': 20, 'سی': 30, 'چهل': 40, 'پنجاه': 50, 'شصت': 60, 'هفتاد': 70, 'هشتاد': 80, 'نود': 90 };
  function replaceNumberWordsFa(text) {
    const tokens = String(text || '').split(' ');
    const out = [];
    for (let i = 0; i < tokens.length; i++) {
      const word = tokens[i];
      if (Object.prototype.hasOwnProperty.call(FA_TENS, word)) {
        let value = FA_TENS[word];
        if (tokens[i + 1] === 'و' && Object.prototype.hasOwnProperty.call(FA_ONES, tokens[i + 2]) && FA_ONES[tokens[i + 2]] < 10) {
          value += FA_ONES[tokens[i + 2]]; i += 2;
        }
        out.push(String(value));
      } else if (Object.prototype.hasOwnProperty.call(FA_ONES, word) && word !== 'نه' && word !== 'ده') {
        out.push(String(FA_ONES[word]));
      } else if ((word === 'ده' || word === 'نه') && /^(?:ثانیه|دقیقه|ساعت)$/.test(tokens[i + 1] || '')) {
        out.push(String(FA_ONES[word]));
      } else out.push(word);
    }
    return out.join(' ');
  }

  // Connectivity probe: navigator.onLine is true on Wi-Fi without internet, so also ask the Space origin.
  let probeOffline = false;
  async function probeConnectivity() {
    try {
      if (navigator.onLine === false) { probeOffline = true; return; }
      if (!location.origin || location.origin === 'null' || !/^https:/.test(location.origin)) return;
      const controller = typeof AbortController === 'function' ? new AbortController() : null;
      const timer = controller ? setTimeout(() => controller.abort(), 3500) : 0;
      try {
        await fetch(location.origin + '/?_probe=' + Date.now(), { method: 'HEAD', cache: 'no-store', mode: 'no-cors', signal: controller ? controller.signal : undefined });
        if (timer) clearTimeout(timer);
        const wasOffline = probeOffline;
        probeOffline = false;
        if (wasOffline) setTimeout(() => { flushOfflineQueue().catch(() => {}); }, 800);
      } catch (error) {
        if (timer) clearTimeout(timer);
        if (error && error.name === 'AbortError') return; // slow, not proven offline
        probeOffline = true;
      }
    } catch (_) {}
  }
  setInterval(() => { if (document.visibilityState === 'visible') probeConnectivity(); }, 12000);
  window.addEventListener('offline', () => { probeOffline = true; });
  window.addEventListener('online', () => { probeOffline = false; setTimeout(probeConnectivity, 500); });
  setTimeout(probeConnectivity, 1500);

  // Offline text-to-speech through the system voice (only if an offline Persian voice is installed).
  function speakOffline(text) {
    try {
      if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance !== 'function') return;
      const voices = window.speechSynthesis.getVoices() || [];
      const voice = voices.find(v => /^fa/i.test(v.lang) && v.localService) || voices.find(v => /^fa/i.test(v.lang));
      if (!voice) return;
      const utterance = new SpeechSynthesisUtterance(String(text || '').slice(0, 160));
      utterance.voice = voice; utterance.lang = voice.lang;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utterance);
    } catch (_) {}
  }
  const cleanTargetFa = v => String(v || '').replace(/^(?:آقای|اقای|خانم|دکتر)\s+/, '').replace(/\s+عزیز$/, '').trim();

  // ---- Local calculator / unit conversion (works with no model and no internet) ----
  const UNIT_NAMES = ['سانتی متر', 'سانتی گراد', 'کیلومتر', 'کیلوگرم', 'فارنهایت', 'اینچ', 'مایل', 'پوند', 'متر', 'فوت'];
  const UNIT_KEY = { 'سانتی متر': 'cm', 'سانتی گراد': 'c', 'کیلومتر': 'km', 'کیلوگرم': 'kg', 'فارنهایت': 'f', 'اینچ': 'in', 'مایل': 'mi', 'پوند': 'lb', 'متر': 'm', 'فوت': 'ft' };
  const UNIT_CONVERT = {
    'km>mi': x => x * 0.621371, 'mi>km': x => x * 1.609344, 'kg>lb': x => x * 2.204623, 'lb>kg': x => x * 0.453592,
    'm>ft': x => x * 3.28084, 'ft>m': x => x * 0.3048, 'cm>in': x => x * 0.393701, 'in>cm': x => x * 2.54,
    'c>f': x => x * 9 / 5 + 32, 'f>c': x => (x - 32) * 5 / 9
  };
  const formatNumberFa = n => {
    if (!isFinite(n)) return '';
    const rounded = Math.abs(n) >= 1000 ? Math.round(n) : Math.round(n * 100) / 100;
    return String(rounded).replace(/\B(?=(\d{3})+(?!\d))/g, '٬').replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
  };
  function localCalcFa(t) {
    let m;
    if ((m = t.match(/^(\d+(?:\.\d+)?)\s*(?:درصد|٪|%)\s*(?:از\s*)?(\d+(?:\.\d+)?)\s*(هزار|میلیون|میلیارد)?(?:\s*(?:تومان|ریال))?$/))) {
      const mult = m[3] === 'هزار' ? 1e3 : m[3] === 'میلیون' ? 1e6 : m[3] === 'میلیارد' ? 1e9 : 1;
      const base = parseFloat(m[2]) * mult;
      return formatNumberFa(parseFloat(m[1])) + '٪ از ' + formatNumberFa(base) + ' برابر است با ' + formatNumberFa(base * parseFloat(m[1]) / 100);
    }
    if ((m = t.match(/^(\d+(?:\.\d+)?)\s*(\+|به علاوه|بعلاوه|جمع|-|منهای|×|\*|ضرب در|در|\/|÷|تقسیم بر)\s*(\d+(?:\.\d+)?)(?:\s*(?:چنده|میشه|می شه|چند میشه|چقدر میشه|می‌شود))?$/))) {
      const a = parseFloat(m[1]), b = parseFloat(m[3]);
      const op = /^(?:\+|به علاوه|بعلاوه|جمع)$/.test(m[2]) ? '+' : /^(?:-|منهای)$/.test(m[2]) ? '-' : /^(?:×|\*|ضرب در|در)$/.test(m[2]) ? '*' : '/';
      if (op === '/' && b === 0) return 'تقسیم بر صفر ممکن نیست.';
      const r = op === '+' ? a + b : op === '-' ? a - b : op === '*' ? a * b : a / b;
      return formatNumberFa(a) + ' ' + m[2] + ' ' + formatNumberFa(b) + ' می‌شود ' + formatNumberFa(r);
    }
    const unitAlt = UNIT_NAMES.join('|');
    const unitRe = new RegExp('^(\\d+(?:\\.\\d+)?)\\s*(?:درجه\\s*)?(' + unitAlt + ')\\s*(?:چند|به)\\s*(?:درجه\\s*)?(' + unitAlt + ')(?:\\s*(?:است|میشه|می شه|بشه|هست))?$');
    if ((m = t.match(unitRe))) {
      const fn = UNIT_CONVERT[UNIT_KEY[m[2]] + '>' + UNIT_KEY[m[3]]];
      if (fn) return formatNumberFa(parseFloat(m[1])) + ' ' + m[2] + ' برابر است با ' + formatNumberFa(fn(parseFloat(m[1]))) + ' ' + m[3];
    }
    return null;
  }

  // Extra offline commands for the newer tools. Patterns are deliberately specific.
  function parseExtraOfflineCommand(t) {
    let m;
    const one = (name, args) => [{ name, args: args || {} }];
    const calc = localCalcFa(t);
    if (calc) return [{ name: '__local', args: { text: calc } }];
    // screen control (accessibility service)
    if (/^(?:برگرد|برگرد عقب|بک بزن|برو عقب|صفحه قبل(?:ی)?(?: رو)?(?: باز کن)?)$/.test(t)) return one('screen_control', { action: 'back' });
    if (/^(?:برو(?: به)? صفحه اصلی|برو هوم|هوم بزن|صفحه اصلی)$/.test(t)) return one('screen_control', { action: 'home' });
    if (/^برنامه ها(?:ی)? اخیر(?: رو)?(?: باز کن)?$/.test(t)) return one('screen_control', { action: 'recents' });
    if (/^(?:پرده(?: ی)? اعلان(?: ها)?|اعلان ها رو (?:پایین بکش|باز کن))$/.test(t)) return one('screen_control', { action: 'notifications' });
    if (/^تنظیمات سریع(?: رو)?(?: باز کن)?$/.test(t)) return one('screen_control', { action: 'quick_settings' });
    if (/^(?:صفحه|گوشی)?(?: رو)? ?قفل کن$/.test(t)) return one('screen_control', { action: 'lock' });
    if (/^(?:اسکرین ?شات(?: بگیر| بزن)?|از صفحه عکس بگیر|عکس از صفحه بگیر)$/.test(t)) return one('screen_control', { action: 'screenshot' });
    if ((m = t.match(/^(?:روی|رو)\s+(.+?)\s+(?:بزن|کلیک کن|لمس کن|ضربه بزن)$/))) return one('screen_control', { action: 'tap', text: m[1] });
    if ((m = t.match(/^(?:تایپ کن|بنویس)\s+(.+)$/))) return one('screen_control', { action: 'type', text: m[1] });
    if ((m = t.match(/^(?:اسکرول(?: کن)?|برو) (پایین|بالا)$/))) return one('screen_control', { action: m[1] === 'پایین' ? 'scroll_down' : 'scroll_up' });
    // notifications / SMS reading
    if (/^(?:اعلان|اعلانات|نوتیفیکیشن|نوتیف)(?: ها)?(?: رو| را)? (?:بخون|بخوان|بگو)$/.test(t)) return one('read_notifications', { count: 5 });
    if (/^(?:آخرین|اخرین) (?:پیامک|پیام|اس ام اس)(?: رو| را)? (?:بخون|بخوان|بگو)$/.test(t)) return one('read_sms', { count: 1 });
    if (/^(?:پیامک|پیام|اس ام اس) ها(?: ی من)?(?: رو| را)? (?:بخون|بخوان|بگو)$/.test(t)) return one('read_sms', { count: 3 });
    // information
    if (/^(?:الان )?(?:ساعت چنده|ساعت چند است|تاریخ(?: امروز)?(?: چنده| چیه)?|امروز چندمه|امروز چندم است|امروز چه روزیه|امروز چه روزی است|ساعت و تاریخ)$/.test(t)) return one('get_datetime');
    if (/^(?:باتری(?: گوشی)?(?: چنده| چقدره| چند درصده| چقدر مونده)?|وضعیت (?:گوشی|باتری)|فضای(?: گوشی)? چقدره|چقدر فضا دارم)$/.test(t)) return one('device_status');
    // media
    if ((m = t.match(/^(?:(?:آهنگ|اهنگ|موزیک) )?(بعدی|قبلی)(?: رو| را)?(?: بذار| بزن| پخش کن)?$/)) && (/(?:آهنگ|اهنگ|موزیک)/.test(t) || /(?:بذار|بزن|پخش کن)$/.test(t)))
      return one('media_control', { action: m[1] === 'بعدی' ? 'next' : 'previous' });
    if (/^(?:مکث|متوقف|استوپ|پاز)(?: کن)?(?: (?:آهنگ|اهنگ|موزیک|پخش))?$/.test(t) || /^(?:آهنگ|اهنگ|موزیک)(?: رو| را)? (?:مکث|متوقف|قطع|پاز) کن$/.test(t))
      return one('media_control', { action: 'pause' });
    if (/^(?:آهنگ|اهنگ|موزیک)(?: رو| را)? (?:پخش کن|بزن|ادامه بده)$/.test(t) || /^(?:پخش|ادامه)(?: بده| کن)?$/.test(t))
      return one('media_control', { action: 'play' });
    // ringer mode
    if ((m = t.match(/^(?:(?:گوشی|موبایل)(?: رو| را)?(?: روی)?|حالت) (بی صدا|ساکت|سایلنت|ویبره|لرزش|زنگ دار|زنگدار|عادی)(?: رو)?(?: کن| بذار| فعال کن)?$/)))
      return one('set_ringer_mode', { mode: /بی صدا|ساکت|سایلنت/.test(m[1]) ? 'silent' : /ویبره|لرزش/.test(m[1]) ? 'vibrate' : 'normal' });
    // find phone
    if (/^(?:گوشی(?: م| منو| من)?(?: رو)? پیدا کن|گوشیم کجاست|گوشی من کجاست|پیدا کردن گوشی)$/.test(t)) return one('find_phone', { action: 'start' });
    if (/^(?:(?:آلارم|زنگ) پیدا کردن(?: گوشی)?(?: رو)? (?:قطع|خاموش|متوقف) کن|گوشی پیدا شد|پیدا شد|پیداش کردم)$/.test(t)) return one('find_phone', { action: 'stop' });
    // contacts / web / navigation
    if ((m = t.match(/^(?:مخاطب جدید|ذخیره کن|ثبت کن)\s+(.+?)\s+(?:با شماره|شماره)\s+([\d +\-]{5,20})$/))) return one('add_contact', { name: m[1], phone: m[2].replace(/\s+/g, '') });
    if ((m = t.match(/^(?:جستجو کن|سرچ کن|search)\s+(.+)$/)) || (m = t.match(/^(.+?)\s+(?:رو|را)\s+(?:جستجو کن|سرچ کن)$/))) return one('web_search', { query: m[1] });
    if ((m = t.match(/^(?:مسیریابی|مسیر|برو)(?: به| تا)?\s+(.+)$/)) && !/^(?:صفحه|پایین|بالا|عقب|هوم)/.test(m[1])) return one('navigate_to', { destination: m[1] });
    return null;
  }

  // Returns [{ name, args }] or null. Deliberately strict: when unsure, return null (never guess).
  function parseOfflineDeviceCommand(raw) {
    const t = replaceNumberWordsFa(normalizeFa(raw).replace(/^(?:لطفا|لطفاً|please)\s+/, ''));
    if (!t) return null;
    const extraCommand = parseExtraOfflineCommand(t);
    if (extraCommand) return extraCommand;
    let m;
    if ((m = t.match(/^(?:با|به)\s+(.+?)\s+(?:تماس\s+بگیر|زنگ\s+بزن|زنگ\s+بگیر)$/)) ||
        (m = t.match(/^(.+?)\s+(?:رو|را)\s+(?:زنگ\s+بزن|تماس\s+بگیر)$/)) ||
        (m = t.match(/^call\s+(.+)$/))) return [{ name: 'call_contact', args: { name: cleanTargetFa(m[1]) } }];
    // SMS text keeps the user's exact characters (half-spaces, punctuation); only the lead-in is matched.
    const light = String(raw || '').replace(/ي/g, 'ی').replace(/ك/g, 'ک').trim().replace(/^(?:لطفا|لطفاً|please)\s+/i, '');
    if ((m = light.match(/^(?:به|برای)\s+(.+?)\s+پیام(?:ک)?\s+(?:بده|بفرست|بنویس)[\s،,]*(?:که\s+)?([\s\S]*)$/)) ||
        (m = light.match(/^(?:text|sms|message)\s+(\S+)\s+([\s\S]+)$/i))) {
      const message = String(m[2] || '').trim();
      if (!message) return null;
      return [{ name: 'create_sms_draft', args: { name: cleanTargetFa(m[1]), message } }];
    }
    const FLASH = '(?:چراغ\\s*قوه|فلش(?:\\s*گوشی)?|چراغ\\s*گوشی)';
    const FLASH_ON = '(?:روشن\\s*کن|روشنش\\s*کن|بزن|فعال\\s*کن)';
    const FLASH_OFF = '(?:خاموش\\s*کن|خاموشش\\s*کن|ببند|غیرفعال\\s*کن|قطع\\s*کن)';
    const flashRe = (noun, verb) => new RegExp('^(?:' + noun + '(?:\\s*(?:رو|را))?\\s*' + verb + '|' + verb + '\\s*' + noun + '(?:\\s*(?:رو|را))?)$');
    if (flashRe(FLASH, FLASH_ON).test(t) || /^(?:turn on|enable)\s+(?:the\s+)?flash ?light$/.test(t))
      return [{ name: 'set_flashlight', args: { enabled: true } }];
    if (flashRe(FLASH, FLASH_OFF).test(t) || /^(?:چراغ\s*قوه|فلش(?:\s*گوشی)?)\s*خاموش$/.test(t) || /^(?:turn off|disable)\s+(?:the\s+)?flash ?light$/.test(t))
      return [{ name: 'set_flashlight', args: { enabled: false } }];
    if (/^(?:صدا(?:ی\s*(?:گوشی|رسانه))?)(?:\s*(?:رو|را))?\s*(?:زیاد|بیشتر)\s*کن$/.test(t)) return [{ name: 'set_volume', args: { action: 'up', steps: 2 } }];
    if (/^(?:صدا(?:ی\s*(?:گوشی|رسانه))?)(?:\s*(?:رو|را))?\s*(?:کم|کمتر)\s*کن$/.test(t)) return [{ name: 'set_volume', args: { action: 'down', steps: 2 } }];
    if (/^(?:صدا(?:ی\s*(?:گوشی|رسانه))?)(?:\s*(?:رو|را))?\s*(?:قطع\s*کن|بی\s*صدا\s*کن|ساکت\s*کن)$/.test(t)) return [{ name: 'set_volume', args: { action: 'mute' } }];
    if ((m = t.match(/^(وای\s*فای|wifi|wi-fi|بلوتوث|bluetooth|اینترنت|دیتا|داده\s*همراه)(?:\s*(?:رو|را))?\s*(روشن|خاموش)\s*کن$/))) {
      const kind = /وای|wi/.test(m[1]) ? 'wifi' : /بلوتوث|bluetooth/.test(m[1]) ? 'bluetooth' : 'mobile_data';
      return [{ name: 'set_connection', args: { type: kind, enabled: m[2] === 'روشن' } }];
    }
    if ((m = t.match(/^تایمر\s+(\d{1,4})\s*(ثانیه|دقیقه|ساعت)(?:\s*(?:بذار|بزن|تنظیم\s*کن))?$/))) {
      const mult = m[2] === 'ساعت' ? 3600 : m[2] === 'دقیقه' ? 60 : 1;
      const seconds = parseInt(m[1], 10) * mult;
      return seconds >= 1 && seconds <= 86400 ? [{ name: 'set_timer', args: { seconds } }] : null;
    }
    if ((m = t.match(/^(?:آلارم|زنگ\s*هشدار|هشدار)\s*(?:ساعت\s*)?(\d{1,2})(?:[: ](\d{2}))?(?:\s*(?:بذار|بزن|تنظیم\s*کن))?$/))) {
      const hour = parseInt(m[1], 10), minute = m[2] ? parseInt(m[2], 10) : 0;
      return hour <= 23 && minute <= 59 ? [{ name: 'set_alarm', args: { hour, minute } }] : null;
    }
    if (/(?:دکمه\s*(?:ی\s*)?پاور|دستیار(?:\s*دیجیتال)?).*(?:فعال|تنظیم|انتخاب)|(?:فعال|تنظیم).*(?:دکمه\s*(?:ی\s*)?پاور)/.test(t)) return [{ name: 'open_settings', args: { section: 'assistant' } }];
    if (/^تنظیمات(?:\s*(?:رو|را))?\s*(?:باز\s*کن)?$/.test(t)) return [{ name: 'open_settings', args: { section: 'main' } }];
    if (/^(?:همه|تمام|همهٔ|همه ی)\s*(?:برنامه|اپ|اپلیکیشن)\s*ها(?:\s*(?:رو|را))?\s*(?:ببند|ببندش|ببندید|ببندی|بسته\s*کن)$/.test(t) ||
        /^(?:close|quit)\s+all\s+(?:apps|applications)$/.test(t))
      return [{ name: 'close_app', args: { all: true } }];
    if ((m = t.match(/^(?:برنامه|اپلیکیشن|اپ)?\s*(.+?)\s+(?:رو|را)\s+(?:ببند|ببندش|ببندید|ببندی|بسته\s*کن)$/)) ||
        (m = t.match(/^(?:ببند|بستن|close|quit)\s+(?:برنامه|اپلیکیشن|اپ)?\s*(.+)$/))) {
      const app = String(m[1] || '').replace(/^(?:برنامه|اپلیکیشن|اپ)\s+/, '').trim();
      return app && app.length <= 60 ? [{ name: 'close_app', args: { app_name: app } }] : null;
    }
    if (/(?:موتور|بسته|تشخیص)?\s*(?:تشخیص\s*)?(?:گفتار|صوتی|صدا)\s*آفلاین/.test(t) && /(?:نصب|دانلود|فعال)/.test(t)) {
      return [{ name: 'install_offline_speech', args: { component: /(?:تبدیل\s*متن|خروجی|صدای\s*آفلاین|tts)/.test(t) ? 'voice' : 'recognition' } }];
    }
    if ((m = t.match(/^(?:برنامه|اپلیکیشن|اپ)?\s*(.+?)\s+(?:رو|را)\s+(?:باز\s*کن|بازش\s*کن|اجرا\s*کن|لانچ\s*کن)$/)) ||
        (m = t.match(/^(?:باز\s*کن|اجرا\s*کن|لانچ\s*کن)\s+(?:برنامه|اپلیکیشن|اپ)?\s*(.+)$/)) ||
        (m = t.match(/^(?:open|launch)\s+(.+)$/))) {
      const app = String(m[1] || '').replace(/^(?:برنامه|اپلیکیشن|اپ)\s+/, '').trim();
      return app && app.length <= 60 ? [{ name: 'open_app', args: { app_name: app } }] : null;
    }
    return null;
  }

  async function runOfflineCommands(commands) {
    const results = [];
    for (const command of commands) {
      if (command.name === '__local') { results.push({ id: '', name: '__local', response: { ok: true, message: String(command.args && command.args.text || '') } }); continue; }
      let executed = await executeDeviceFunctionCallInteractive({ id: '', name: command.name, args: command.args });
      if (command.name === 'open_app' && !(executed.response && executed.response.ok)) {
        const key = normalizeFa(command.args.app_name);
        for (const alt of (APP_ALIASES[key] || [])) {
          const retry = executeDeviceFunctionCall({ id: '', name: 'open_app', args: { app_name: alt } });
          if (retry.response && retry.response.ok) { executed = retry; break; }
        }
      }
      results.push(executed);
    }
    return results;
  }

  async function handleOfflineText(textValue, reason) {
    const commands = parseOfflineDeviceCommand(textValue);
    if (commands && commands.length) {
      const results = await runOfflineCommands(commands);
      const summary = results.map(r => String((r.response && r.response.message) || (r.response && r.response.ok ? 'انجام شد' : 'ناموفق'))).join(' | ');
      pushOfflineQueue({ text: textValue, ts: Date.now(), executed: true, summary: summary.slice(0, 400) });
      if (typeof toast === 'function') toast((reason || 'حالت آفلاین') + ': ' + summary.slice(0, 140));
      speakOffline(summary.split(' | ')[0]);
      return true;
    }
    pushOfflineQueue({ text: textValue, ts: Date.now(), executed: false, summary: '' });
    if (typeof toast === 'function') toast('اینترنت نیست و دستور برای اجرای مستقیم واضح نبود؛ ذخیره شد و با وصل‌شدن اینترنت هوش مصنوعی بررسی می‌کند.');
    return true;
  }

  let flushingOfflineQueue = false;
  async function flushOfflineQueue() {
    if (flushingOfflineQueue || isOffline()) return;
    const queue = loadOfflineQueue();
    if (!queue.length || typeof api !== 'function') return;
    flushingOfflineQueue = true;
    try {
      let chat = typeof cur === 'function' ? cur() : null;
      if (!chat && typeof newSession === 'function') {
        try { await Promise.resolve(newSession('text')); } catch (_) {}
        chat = typeof cur === 'function' ? cur() : null;
      }
      if (!chat) return; // keep the queue for the next opportunity
      saveOfflineQueue([]);
      const keep = [];
      for (const entry of queue) {
        const turnId = 'offline_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
        try {
          if (entry.executed) {
            await api('/api/live-save', { method: 'POST', body: JSON.stringify({ chat_id: chat.id, user_text: entry.text,
              assistant_text: '(در حالت آفلاین مستقیماً اجرا شد) ' + (entry.summary || 'انجام شد'), turn_id: turnId }) });
          } else if (Date.now() - Number(entry.ts || 0) <= OFFLINE_STALE_MS) {
            const result = await runOneShotDeviceAgent(entry.text, chat);
            if (result && result.toolUsed) {
              await api('/api/live-save', { method: 'POST', body: JSON.stringify({ chat_id: chat.id, user_text: entry.text,
                assistant_text: result.text || 'عملیات دستگاه اجرا شد.', turn_id: turnId }) });
            }
          } else if (typeof toast === 'function') {
            toast('دستور قدیمی بدون اجرا کنار گذاشته شد: ' + String(entry.text).slice(0, 60));
          }
        } catch (error) {
          console.warn('Offline queue entry failed', error);
          if (!(error && error.deviceToolExecuted)) keep.push(entry);
        }
      }
      if (keep.length) saveOfflineQueue(keep);
      try {
        const r = await api('/api/chats/' + encodeURIComponent(chat.id));
        if (r && r.chat && typeof norm === 'function') {
          state.sessions[chat.id] = norm(r.chat);
          if (state.cid === chat.id && state.page === 'chat' && typeof paint === 'function') paint(true);
        }
      } catch (_) {}
    } finally { flushingOfflineQueue = false; }
  }
  window.addEventListener('online', () => setTimeout(() => { flushOfflineQueue().catch(() => {}); }, 1500));
  setTimeout(() => { flushOfflineQueue().catch(() => {}); }, 5000);

  // For likely phone-control requests in normal chat, let Gemini choose a native function first.
  // Routing is done in the capture phase on the send button / Enter key, so it works no matter
  // how the page bound its own send handler. Non-device messages continue through the normal path.
  try {
    if (!window.__allBatDeviceRouteInstalled) {
      window.__allBatDeviceRouteInstalled = true;
      const agentBusyChats = new Set();
      let agentRunning = false;
      let bypass = false;
      const proceedNormally = () => {
        bypass = true;
        try {
          const button = document.getElementById('sendBtn');
          if (button) button.click();
          else if (typeof send === 'function') send();
        } finally { bypass = false; }
      };
      const shouldIntercept = () => {
        if (bypass || agentRunning) return false;
        if (!native || typeof native.executeDeviceTool !== 'function') return false;
        const input = document.getElementById('inp');
        const textValue = input ? String(input.value || '').trim() : '';
        if (!textValue) return false;
        if (!(looksLikeDeviceAction(textValue) || (isOffline() && parseOfflineDeviceCommand(textValue)))) return false;
        if (typeof state !== 'undefined' && state.voiceConversation) return false;
        const chat = typeof cur === 'function' ? cur() : null;
        if (chat && typeof activeChatRequests !== 'undefined' && activeChatRequests[chat.id]) return false;
        return true;
      };
      const runRoute = async () => {
        const input = document.getElementById('inp');
        const textValue = input ? String(input.value || '').trim() : '';
        let chat = typeof cur === 'function' ? cur() : null;
        // First command typed on the Home screen: create the normal text chat, then route this text.
        if (!chat && typeof state !== 'undefined' && state.page === 'home' && typeof newSession === 'function') {
          try { await Promise.resolve(newSession('text')); } catch (_) {}
          chat = typeof cur === 'function' ? cur() : null;
          if (input && input.value !== textValue) {
            const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input), 'value');
            if (setter && setter.set) setter.set.call(input, textValue); else input.value = textValue;
            input.dispatchEvent(new Event('input', { bubbles: true }));
          }
        }
        // No internet: run clear commands directly through the same native allow-list; queue the rest.
        if (isOffline()) {
          await handleOfflineText(textValue, 'حالت آفلاین');
          if (input) { input.value = ''; input.style.height = ''; }
          if (typeof refreshSendState === 'function') refreshSendState();
          return;
        }
        if (!chat || agentBusyChats.has(chat.id)) { proceedNormally(); return; }
        agentBusyChats.add(chat.id);
        let fallThrough = true;
        try {
          if (typeof toast === 'function') toast('مدل در حال انتخاب ابزار مناسب دستگاه است…');
          const result = await runOneShotDeviceAgent(textValue, chat);
          if (result && result.toolUsed) {
            fallThrough = false;
            const saved = await api('/api/live-save', { method: 'POST', body: JSON.stringify({
              chat_id: chat.id,
              user_text: textValue,
              assistant_text: result.text || 'عملیات دستگاه اجرا شد.',
              turn_id: 'device_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 9)
            }) });
            if (saved && saved.chat && typeof norm === 'function') {
              state.sessions[chat.id] = norm(saved.chat);
              if (state.cid === chat.id && state.page === 'chat' && typeof paint === 'function') paint(true);
            }
            if (input) { input.value = ''; input.style.height = ''; }
            if (typeof refreshSendState === 'function') refreshSendState();
          }
        } catch (error) {
          console.warn('One-shot Android tool agent failed', error);
          if (error && error.deviceToolExecuted) {
            fallThrough = false;
            if (typeof toast === 'function') toast('ابزار اجرا شد، اما پاسخ نهایی مدل دریافت نشد: ' + String(error.message || '').slice(0, 100));
          } else if (error && error.networkDown && parseOfflineDeviceCommand(textValue)) {
            // Weak/no connection to the model: execute the clear command locally instead of failing.
            fallThrough = false;
            await handleOfflineText(textValue, 'اینترنت ضعیف؛ اجرای مستقیم');
            if (input) { input.value = ''; input.style.height = ''; }
            if (typeof refreshSendState === 'function') refreshSendState();
          } else if (typeof toast === 'function') {
            toast('اتصال ابزارهای دستیار برقرار نشد: ' + String(error && error.message || '').slice(0, 110));
          }
        } finally {
          agentBusyChats.delete(chat.id);
        }
        if (fallThrough) proceedNormally();
      };
      const intercept = event => {
        if (!shouldIntercept()) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        agentRunning = true;
        runRoute().catch(error => {
          console.warn('Device routing crashed', error);
          proceedNormally();
        }).finally(() => { agentRunning = false; });
      };
      document.addEventListener('click', event => {
        const target = event.target;
        if (target && typeof target.closest === 'function' && target.closest('#sendBtn')) intercept(event);
      }, true);
      document.addEventListener('keydown', event => {
        if (event.key !== 'Enter' || event.shiftKey || event.isComposing) return;
        const target = event.target;
        if (target && target.id === 'inp') intercept(event);
      }, true);
    }
  } catch (error) { console.warn('Could not install the text-mode device agent', error); }

  window.addEventListener('beforeunload', () => {
    // Normal backgrounding does not unload the document; actual page teardown releases camera.
    stopCamera();
  });
})();
