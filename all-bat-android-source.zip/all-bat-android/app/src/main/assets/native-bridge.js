/*
 * Native Android bridge injected by scripts/prepare_web_assets.py.
 * Images are sent only while the user's Gemini Live session is active.
 * Screen capture starts only after Android MediaProjection consent.
 */
(() => {
  'use strict';
  if (window.__allBatNativeBridgeInstalled) return;
  window.__allBatNativeBridgeInstalled = true;

  const native = window.AndroidAssistant || null;

  document.addEventListener('click', event => {
    try {
      const target = event.target;
      if (!target || typeof target.closest !== 'function') return;
      if (target.closest('[data-act="pick-camera"]')) {
        native && native.markNextFileChooserAsCamera();
      }
      const liveButton = target.closest('[data-act="voicechat"]');
      if (!liveButton || !native || typeof native.hasFloatingAssistantOverlayPermission !== 'function') return;
      // In the regular app, request the special overlay permission before opening Live so Android
      // Settings cannot unexpectedly cover an already-running microphone session. The system's
      // default-assistant surface has its own lifecycle and asks only after Live is explicitly tapped.
      let systemAssistantSurface = false;
      try { systemAssistantSurface = typeof native.isAssistantSession === 'function' && !!native.isAssistantSession(); } catch (_) {}
      if (systemAssistantSurface || native.hasFloatingAssistantOverlayPermission()) return;
      // Ask only once automatically. If the user declines, Live still remains usable without the orb.
      if (typeof native.shouldPromptFloatingAssistantOverlay === 'function' && !native.shouldPromptFloatingAssistantOverlay()) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      try { native.requestFloatingAssistantOverlay(); } catch (_) {}
      setTimeout(() => setAssistantStatus('مجوز حباب شناور را فعال کن؛ بعد از بازگشت دوباره دکمهٔ گفت‌وگوی صوتی را بزن.'), 100);
    } catch (_) {}
  }, true);

  // If the WebView/Android audio stack cannot initialize capture, release native audio focus
  // before bubbling the original error to the Live UI. Native code prepares communication mode
  // when the WebView's own permission request is granted.
  try {
    const mediaDevices = navigator.mediaDevices;
    if (native && mediaDevices && typeof mediaDevices.getUserMedia === 'function' && !mediaDevices.__allBatAudioWrapped) {
      const originalGetUserMedia = mediaDevices.getUserMedia.bind(mediaDevices);
      const wrappedGetUserMedia = async function (constraints) {
        const wantsAudio = !!(constraints && constraints.audio);
        if (wantsAudio) {
          // Set communication mode before Chromium initializes the native audio source.
          try { native.prepareAudioSession(); } catch (_) {}
        }
        try {
          return await originalGetUserMedia(constraints);
        } catch (firstError) {
          // Some Android WebView/audio-driver combinations reject enhanced mic constraints
          // with NotReadableError even though the default microphone works. Retry once with
          // the browser's default audio constraints, then surface the original error if needed.
          const retryable = wantsAudio && constraints.audio && typeof constraints.audio === 'object' &&
            firstError && ['NotReadableError', 'AbortError', 'OverconstrainedError'].includes(firstError.name);
          if (retryable) {
            try {
              return await originalGetUserMedia({ audio: true, video: constraints.video || false });
            } catch (fallbackError) {
              console.warn('Default microphone fallback also failed', fallbackError);
            }
          }
          if (wantsAudio) {
            try { native.cancelAudioSession(); } catch (_) {}
          }
          throw firstError;
        }
      };
      Object.defineProperty(mediaDevices, '__allBatAudioWrapped', { value: true, configurable: false });
      mediaDevices.getUserMedia = wrappedGetUserMedia;
    }
  } catch (error) {
    console.warn('All Bat could not install audio cleanup wrapper', error);
  }

  let cameraStream = null;
  let cameraVideo = null;
  let cameraCanvas = null;
  let cameraTimer = 0;
  let cameraActive = false;
  let voiceServiceActive = false;
  let screenShareActive = false;
  let screenPermissionPending = false;
  let lastFrameSentAt = 0;
  let menuOpen = false;

  const canSendLiveFrame = () => {
    try {
      return typeof state !== 'undefined' && !!state.voiceConversation &&
        typeof liveReady !== 'undefined' && !!liveReady &&
        typeof liveSocket !== 'undefined' && liveSocket &&
        liveSocket.readyState === WebSocket.OPEN;
    } catch (_) { return false; }
  };

  function pushFrame(base64Jpeg) {
    if (!base64Jpeg || !canSendLiveFrame()) return false;
    const now = Date.now();
    // Limit bandwidth, processing load and battery use when camera and screen are both enabled.
    if (now - lastFrameSentAt < 1_100) return false;
    try {
      liveSocket.send(JSON.stringify({
        realtimeInput: {
          video: { mimeType: 'image/jpeg', data: base64Jpeg }
        }
      }));
      lastFrameSentAt = now;
      setStatus('تصویر به گفت‌وگوی زنده فرستاده می‌شود');
      return true;
    } catch (_) {
      setStatus('اتصال زنده آمادهٔ دریافت تصویر نیست');
      return false;
    }
  }

  function setStatus(text) {
    const node = document.getElementById('__allbat_status');
    if (node) node.textContent = String(text || '');
  }

  const style = document.createElement('style');
  style.textContent = `
    #__allbat_widget{position:fixed;z-index:2147483000;right:10px;bottom:calc(88px + env(safe-area-inset-bottom,0px));font:13px/1.45 system-ui,sans-serif;direction:rtl;color:#f8f9ff;max-width:calc(100vw - 20px)}
    #__allbat_toggle{border:0;border-radius:999px;background:linear-gradient(135deg,#5558f3,#15aeca);color:#fff;padding:11px 15px;box-shadow:0 6px 22px #0004;font-weight:700}
    #__allbat_menu{display:none;min-width:210px;margin-bottom:8px;padding:9px;border:1px solid #ffffff2a;border-radius:18px;background:#151a29f5;box-shadow:0 12px 32px #0005;backdrop-filter:blur(18px)}
    #__allbat_menu.open{display:flex;flex-direction:column;gap:7px}
    #__allbat_menu button{border:1px solid #ffffff18;border-radius:12px;background:#252c40;color:#f7f8ff;padding:10px;text-align:right}
    #__allbat_status{padding:4px 3px;color:#c6cce2;font-size:11px;min-height:18px}
    #__allbat_camera_preview{position:fixed;z-index:2147482998;left:10px;bottom:calc(88px + env(safe-area-inset-bottom,0px));width:min(44vw,210px);border:1px solid #ffffff55;border-radius:16px;overflow:hidden;background:#101522;box-shadow:0 8px 24px #0005;display:none}
    #__allbat_camera_preview video{display:block;width:100%;max-height:250px;object-fit:cover;transform:scaleX(1)}
    #__allbat_camera_preview .cap{padding:5px 8px;font-size:11px;color:#fff;background:#101522}
    #__allbat_assistant_mode_banner{display:none;position:fixed;z-index:2147483001;top:calc(8px + env(safe-area-inset-top,0px));left:10px;right:10px;padding:11px 12px;border:1px solid #ffffff24;border-radius:16px;background:#151a29f2;color:#fff;box-shadow:0 8px 28px #0004;direction:rtl;font:13px/1.5 system-ui,sans-serif;align-items:center;gap:10px}
    #__allbat_assistant_mode_banner.show{display:flex}
    #__allbat_assistant_mode_banner .desc{flex:1;min-width:0}
    #__allbat_assistant_mode_banner button{border:0;border-radius:12px;background:#5558f3;color:white;font-weight:700;padding:9px 11px;white-space:nowrap}
    #__allbat_region_modal{position:fixed;inset:0;z-index:2147483646;background:#080d18f5;display:flex;flex-direction:column;gap:10px;padding:calc(12px + env(safe-area-inset-top,0px)) 12px calc(12px + env(safe-area-inset-bottom,0px));box-sizing:border-box;color:#fff;direction:rtl;font:14px/1.5 system-ui,sans-serif;touch-action:pan-y}
    #__allbat_region_modal .region-head,#__allbat_region_modal .region-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}
    #__allbat_region_modal .region-head strong{font-size:15px}
    #__allbat_region_modal button{border:1px solid #ffffff26;border-radius:12px;background:#252c40;color:#fff;padding:10px 13px;font-weight:700}
    #__allbat_region_modal button.primary{background:#5558f3;border-color:transparent}
    #__allbat_region_modal button:disabled{opacity:.42}
    #__allbat_region_modal .region-help{font-size:12px;color:#c8d0e4}
    #__allbat_region_modal .region-stage{flex:1;min-height:80px;display:flex;align-items:center;justify-content:center;overflow:hidden;touch-action:none;user-select:none}
    #__allbat_region_modal .region-wrap{position:relative;display:inline-block;max-width:100%;max-height:calc(100vh - 200px);max-height:calc(100dvh - 200px);line-height:0;touch-action:none;user-select:none}
    #__allbat_region_modal .region-image{display:block;width:auto;height:auto;max-width:calc(100vw - 24px);max-height:calc(100vh - 200px);max-height:calc(100dvh - 200px);object-fit:contain;pointer-events:none;user-select:none}
    #__allbat_region_modal .region-box{position:absolute;display:none;border:2px solid #7c9dff;background:#587cff38;box-shadow:0 0 0 9999px #0005;pointer-events:none;box-sizing:border-box}
    @media(prefers-reduced-motion:reduce){#__allbat_toggle{transition:none}} 
  `;
  document.documentElement.appendChild(style);

  const widget = document.createElement('div');
  widget.id = '__allbat_widget';
  widget.innerHTML = `
    <div id="__allbat_menu" aria-label="ابزارهای دستیار اندروید">
      <button id="__allbat_camera" type="button">📷 روشن‌کردن دوربین زنده</button>
      <button id="__allbat_screen" type="button">🖥️ اشتراک‌گذاری صفحه</button>
      <button id="__allbat_overlay" type="button">🔵 فعال‌کردن حباب شناور Digi</button>
      <button id="__allbat_role" type="button">🤖 انتخاب به‌عنوان دستیار پیش‌فرض</button>
      <div id="__allbat_status" role="status">برای ارسال تصویر، گفت‌وگوی زنده را شروع کن.</div>
    </div>
    <button id="__allbat_toggle" type="button" aria-expanded="false">⚡ ابزارهای اندروید</button>
  `;
  document.body.appendChild(widget);

  const preview = document.createElement('div');
  preview.id = '__allbat_camera_preview';
  preview.innerHTML = '<video playsinline muted autoplay></video><div class="cap">پیش‌نمایش دوربین · ارسال فقط هنگام Live</div>';
  document.body.appendChild(preview);
  const previewVideo = preview.querySelector('video');

  const toggle = document.getElementById('__allbat_toggle');
  const menu = document.getElementById('__allbat_menu');
  const cameraButton = document.getElementById('__allbat_camera');
  const screenButton = document.getElementById('__allbat_screen');
  let assistantScreenshotDataUrl = '';
  let assistantPanelBanner = null;
  let regionModal = null;

  function setAssistantStatus(message) {
    setStatus(message);
    if (assistantPanelBanner) {
      const status = assistantPanelBanner.querySelector('.desc');
      if (status) status.textContent = message;
    }
  }

  function closeRegionModal() {
    if (regionModal) regionModal.remove();
    regionModal = null;
  }

  function openAssistantRegionSelector() {
    if (!assistantScreenshotDataUrl) {
      setAssistantStatus('تصویر صفحه در دسترس نیست؛ ممکن است برنامهٔ فعلی اشتراک اسکرین‌شات را مسدود کرده باشد.');
      return;
    }
    closeRegionModal();
    const modal = document.createElement('div');
    modal.id = '__allbat_region_modal';
    modal.innerHTML = `
      <div class="region-head"><strong>انتخاب بخشی از صفحه</strong><button type="button" data-region-cancel>بستن</button></div>
      <div class="region-help">روی تصویر بکش تا فقط همان قسمت انتخاب شود. کل صفحه ارسال نمی‌شود.</div>
      <div class="region-stage"><div class="region-wrap"><img class="region-image" alt="تصویر صفحه برای انتخاب ناحیه"><div class="region-box"></div></div></div>
      <div class="region-foot"><span class="region-help" data-region-status>محدودهٔ دلخواه را با انگشت مشخص کن.</span><button class="primary" type="button" data-region-send disabled>افزودن بخش انتخاب‌شده به پیش‌نویس</button></div>
    `;
    document.body.appendChild(modal);
    regionModal = modal;
    const image = modal.querySelector('.region-image');
    const wrap = modal.querySelector('.region-wrap');
    const box = modal.querySelector('.region-box');
    const sendButton = modal.querySelector('[data-region-send]');
    const status = modal.querySelector('[data-region-status]');
    image.src = assistantScreenshotDataUrl;
    let start = null;
    let selection = null;
    let activePointerId = null;
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    const pointFor = event => {
      const r = image.getBoundingClientRect();
      return { x: clamp(event.clientX - r.left, 0, r.width), y: clamp(event.clientY - r.top, 0, r.height) };
    };
    const drawBox = (a, b) => {
      const left = Math.min(a.x, b.x), top = Math.min(a.y, b.y);
      const width = Math.abs(b.x - a.x), height = Math.abs(b.y - a.y);
      box.style.display = 'block';
      box.style.left = left + 'px'; box.style.top = top + 'px';
      box.style.width = width + 'px'; box.style.height = height + 'px';
      return {left, top, width, height};
    };
    wrap.addEventListener('pointerdown', event => {
      if (!image.naturalWidth || !image.naturalHeight) return;
      event.preventDefault();
      activePointerId = event.pointerId;
      try { wrap.setPointerCapture(activePointerId); } catch (_) {}
      start = pointFor(event); selection = null; sendButton.disabled = true;
      drawBox(start, start);
      status.textContent = 'برای تعیین اندازه، انگشتت را حرکت بده.';
    });
    wrap.addEventListener('pointermove', event => {
      if (!start || event.pointerId !== activePointerId) return;
      event.preventDefault();
      const p = pointFor(event); selection = drawBox(start, p);
      sendButton.disabled = selection.width < 14 || selection.height < 14;
    });
    const finishPointer = event => {
      if (!start || event.pointerId !== activePointerId) return;
      const p = pointFor(event); selection = drawBox(start, p);
      start = null; activePointerId = null;
      const valid = selection.width >= 14 && selection.height >= 14;
      sendButton.disabled = !valid;
      status.textContent = valid ? 'محدوده آماده است؛ فقط همین کادر پیوست می‌شود.' : 'محدوده خیلی کوچک است؛ دوباره انتخاب کن.';
    };
    wrap.addEventListener('pointerup', finishPointer);
    wrap.addEventListener('pointercancel', finishPointer);
    modal.querySelector('[data-region-cancel]').addEventListener('click', () => {
      closeRegionModal(); setAssistantStatus('انتخاب بخش صفحه لغو شد؛ هیچ تصویری ارسال نشد.');
    });
    sendButton.addEventListener('click', async () => {
      if (!selection || !image.naturalWidth || !image.naturalHeight) return;
      sendButton.disabled = true;
      status.textContent = 'در حال آماده‌سازی بخش انتخاب‌شده…';
      try {
        const sx = image.naturalWidth / image.getBoundingClientRect().width;
        const sy = image.naturalHeight / image.getBoundingClientRect().height;
        let sx0 = Math.round(selection.left * sx), sy0 = Math.round(selection.top * sy);
        let sw = Math.round(selection.width * sx), sh = Math.round(selection.height * sy);
        sx0 = clamp(sx0, 0, image.naturalWidth - 1); sy0 = clamp(sy0, 0, image.naturalHeight - 1);
        sw = clamp(sw, 1, image.naturalWidth - sx0); sh = clamp(sh, 1, image.naturalHeight - sy0);
        const canvas = document.createElement('canvas');
        const scale = Math.min(1, 1600 / Math.max(sw, sh));
        canvas.width = Math.max(1, Math.round(sw * scale));
        canvas.height = Math.max(1, Math.round(sh * scale));
        const ctx = canvas.getContext('2d', { alpha: false });
        if (!ctx) throw new Error('canvas unavailable');
        ctx.drawImage(image, sx0, sy0, sw, sh, 0, 0, canvas.width, canvas.height);
        const blob = await new Promise((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error('crop failed')), 'image/jpeg', 0.88));
        const file = new File([blob], 'allbat-selected-screen-region.jpg', { type: 'image/jpeg', lastModified: Date.now() });
        let attached = false;
        try {
          if (typeof addFiles === 'function') { await Promise.resolve(addFiles([file])); attached = true; }
        } catch (error) { console.warn('Could not attach cropped assistant image', error); }
        if (!attached) {
          const input = document.getElementById('pickerPhoto') || document.querySelector('input[type="file"][accept*="image"]');
          if (input && typeof DataTransfer !== 'undefined') {
            const transfer = new DataTransfer(); transfer.items.add(file); input.files = transfer.files;
            input.dispatchEvent(new Event('change', { bubbles: true })); attached = true;
          }
        }
        if (!attached) throw new Error('composer attachment handler unavailable');
        closeRegionModal();
        abxAttached = true;
        setAssistantStatus('فقط بخش انتخاب‌شده به پیش‌نویس پیوست شد. متن سؤال را بنویس و ارسال کن.');
      } catch (error) {
        console.warn('Selected screen region could not be attached', error);
        status.textContent = 'افزودن تصویر ناموفق بود؛ دوباره امتحان کن.';
        sendButton.disabled = false;
      }
    });
  }

  // ---- Gemini-style compact assistant surface (system assistant sheet) -------------------
  let panelModeStyle = null;
  let panelModeBooting = false;
  let abxUi = null;
  let abxAttached = false;
  const ABX_FONT = '"Google Sans",Roboto,system-ui,sans-serif';
  const ABX_SVG = {
    plus: '<svg viewBox="0 0 24 24"><path d="M12 4v16M4 12h16"/></svg>',
    mic: '<svg viewBox="0 0 24 24"><rect x="8.5" y="3" width="7" height="12" rx="3.5"/><path d="M5 11.5a7 7 0 0 0 14 0M12 18.5V22"/></svg>',
    arrow: '<svg viewBox="0 0 24 24"><path d="M12 20V5M5.5 11.5 12 5l6.5 6.5"/></svg>',
    stop: '<svg viewBox="0 0 24 24"><rect class="fill" x="6" y="6" width="12" height="12" rx="2.6"/></svg>',
    min: '<svg viewBox="0 0 24 24"><path d="M4 15h4a1 1 0 0 1 1 1v4M20 9h-4a1 1 0 0 1-1-1V4"/></svg>'
  };

  function ensureAssistantPanelStyles() {
    if (panelModeStyle) return;
    const P = 'body.allbat-assistant-panel-mode';
    panelModeStyle = document.createElement('style');
    panelModeStyle.id = '__allbat_assistant_panel_styles';
    panelModeStyle.textContent = `
      html,body{height:100%!important;min-height:0!important;overflow:hidden!important;background:transparent!important}
      %P% .app,%P% .screen{transform:none!important;animation:none!important;filter:none!important;backdrop-filter:none!important;contain:none!important}
      %P% .app{height:100dvh!important;min-height:0!important;max-width:none!important;margin:0!important;padding:0!important;overflow:hidden!important;background:transparent!important}
      %P% .top,%P% .tabs,%P% #topMain,%P% #topChat,%P% .hero,%P% .sec,%P% .dock{display:none!important}
      %P% .screen:not(.on){display:none!important}
      %P% .screen.on{padding:0!important;background:transparent!important;overflow:visible!important}
      %P% #__allbat_widget,%P% #__allbat_camera_preview{display:none!important}
      %P% .shw{z-index:2147483647!important}

      /* answer card: only the latest answer, large rounded, lavender-white, drag handle on top */
      %P% #msgs{position:fixed!important;left:0!important;right:0!important;top:auto!important;bottom:130px;height:auto!important;max-height:60vh;min-height:0!important;overflow:auto!important;padding:0 16px!important;margin:0!important;display:flex!important;flex-direction:column;justify-content:flex-end;gap:0!important;background:transparent!important;pointer-events:none;scrollbar-width:none}
      %P% #msgs::-webkit-scrollbar{display:none}
      %P% #msgs .msg{display:none!important}
      %P% #msgs .msg.abx-last{display:flex!important;flex-direction:column;pointer-events:auto;position:relative;width:100%!important;max-width:none!important;box-sizing:border-box;padding:24px 17px 2px!important;margin:0!important;gap:0!important;border:0!important;border-radius:28px!important;background:linear-gradient(180deg,#fbfaff 0%,#f6f3fd 100%)!important;box-shadow:0 6px 22px rgba(60,50,120,.12)!important}
      %P% #msgs .msg.abx-last.abx-empty{display:none!important}
      %P% #msgs .msg.abx-last::before{content:"";position:absolute;top:8px;left:50%;width:33px;height:4px;margin-left:-16px;border-radius:2px;background:#8a8a92}
      %P% #msgs .msg.abx-last .mh{display:none!important}
      %P% #msgs .msg.abx-last .mb{max-width:100%!important;border:0!important;border-radius:0!important;background:transparent!important;padding:0!important;box-shadow:none!important;font-size:20px!important;line-height:1.55!important;color:#1b1b1f!important}
      %P% #msgs .msg.abx-last .mb::after{content:"Digi is AI and can make mistakes.";display:block;margin-top:12px;color:#5f5f66;font:400 14.5px/1.4 ${ABX_FONT};direction:ltr;text-align:left}
      %P% #msgs .msg.abx-last .ma{display:flex!important;flex-wrap:nowrap!important;align-items:center!important;direction:ltr!important;position:relative!important;min-height:52px!important;margin:4px -9px 0!important;padding:0 0 4px!important;gap:0!important;opacity:1!important}
      %P% #msgs .msg.abx-last .ma button{width:49px!important;height:48px!important;min-width:0!important;padding:0!important;border:0!important;border-radius:50%!important;background:transparent!important;color:#3f3f46!important;display:grid!important;place-items:center!important;position:static!important}
      %P% #msgs .msg.abx-last .ma button.speak{margin-left:auto!important}
      %P% #msgs .msg.abx-last .ma .i{width:22px!important;height:22px!important}

      /* Minimize capsule */
      #abx-minrow{position:fixed;left:0;right:0;bottom:200px;display:none;justify-content:center;padding:0 16px;box-sizing:border-box;pointer-events:none;z-index:50}
      #abx-minrow.right{justify-content:flex-end}
      %P% #abx-minrow{display:flex}
      #abx-min{pointer-events:auto;display:inline-flex;align-items:center;gap:13px;height:49px;padding:0 22px 0 19px;border:0;border-radius:999px;background:linear-gradient(180deg,#fff,#f1effb);color:#1c1b1f;font:400 17px/1 ${ABX_FONT};box-shadow:0 2px 10px rgba(60,50,120,.14)}
      #abx-min svg{width:20px;height:20px;display:block;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}

      /* "Ask" bar */
      #abx-ui{position:fixed;left:0;right:0;bottom:0;padding:0 41px 10px;box-sizing:border-box;z-index:60;pointer-events:none;display:none}
      %P% #abx-ui{display:block}
      #abx-composer{pointer-events:auto;display:flex;align-items:center;min-height:78px;border-radius:999px;padding:0 19px 0 17px;box-sizing:border-box;background:linear-gradient(180deg,#fdfcff 0%,#f8f6ff 60%,#ebe8fc 100%);box-shadow:0 4px 18px rgba(60,50,130,.14),inset 0 -9px 16px -9px rgba(140,128,236,.5);transition:box-shadow .3s}
      #abx-composer.busy{box-shadow:0 4px 18px rgba(60,50,130,.18),inset 0 -14px 22px -8px rgba(112,96,228,.8)}
      #abx-composer svg{width:26px;height:26px;display:block;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
      #abx-composer svg .fill{fill:currentColor;stroke:none}
      .abx-ib{flex:none;position:relative;width:48px;height:48px;border:0;background:transparent;display:grid;place-items:center;color:#1f1f23;padding:0;margin:0}
      .abx-ib.has::after{content:"";position:absolute;top:8px;right:8px;width:9px;height:9px;border-radius:50%;background:#405a94}
      #abx-input{flex:1;min-width:0;height:48px;max-height:120px;border:0;outline:0;background:transparent;resize:none;font:400 22px/26px ${ABX_FONT};color:#1f1f23;padding:11px 6px;margin:0 0 0 5px;overflow:auto}
      #abx-input::placeholder{color:#44444b;opacity:1}
      #abx-send{flex:none;width:41px;height:41px;margin:0 0 0 4px;border:0;border-radius:50%;background:#e4e3e9;color:#7b7b85;display:grid;place-items:center;padding:0;transition:background .2s}
      #abx-send.on{background:#405a94;color:#fff}
      #abx-send svg{width:22px;height:22px}
      @media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
    `.split('%P%').join(P);
    document.head.appendChild(panelModeStyle);
  }

  function abxState() { try { return typeof state !== 'undefined' ? state : null; } catch (_) { return null; } }

  function abxMarkLast() {
    const msgs = document.getElementById('msgs');
    if (!msgs) return null;
    const nodes = Array.from(msgs.querySelectorAll('.msg'));
    nodes.forEach(n => n.classList.remove('abx-last', 'abx-empty'));
    if (!nodes.length) return null;
    const tail = nodes[nodes.length - 1];
    if (tail.classList.contains('user')) return null; // question sent, answer not started yet
    tail.classList.add('abx-last');
    const body = tail.querySelector('.mb') || tail;
    const sending = !!(abxState() && abxState().sending);
    if (!String(body.textContent || '').trim() && (sending || !tail.querySelector('img,svg,canvas'))) {
      tail.classList.add('abx-empty');
    }
    return tail;
  }

  function abxLayout(last) {
    if (!abxUi) return;
    const msgs = document.getElementById('msgs');
    const cTop = abxUi.composer.getBoundingClientRect().top;
    const below = window.innerHeight - cTop;
    const gap = 12;
    const shown = !!(last && !last.classList.contains('abx-empty'));
    let cardH = 0;
    if (msgs) {
      msgs.style.bottom = (below + gap) + 'px';
      msgs.style.maxHeight = Math.max(120, cTop - gap - 49 - 9 - 56) + 'px';
      if (shown) cardH = msgs.getBoundingClientRect().height;
    }
    abxUi.minrow.style.bottom = (shown ? below + gap + cardH + 9 : below + 12) + 'px';
    abxUi.minrow.classList.toggle('right', shown);
  }

  function abxTick() {
    if (!abxUi || !document.body.classList.contains('allbat-assistant-panel-mode')) return;
    const last = abxMarkLast();
    const st = abxState();
    const sending = !!(st && st.sending);
    const hasText = !!abxUi.input.value.trim();
    const cardShown = !!(last && !last.classList.contains('abx-empty'));
    abxUi.composer.classList.toggle('busy', sending);
    const wanted = sending && !cardShown ? 'Just a sec…' : 'Ask Digi';
    if (abxUi.input.getAttribute('placeholder') !== wanted) abxUi.input.setAttribute('placeholder', wanted);
    const sendHtml = sending ? ABX_SVG.stop : ABX_SVG.arrow;
    if (abxUi.send.dataset.kind !== (sending ? 'stop' : 'arrow')) {
      abxUi.send.dataset.kind = sending ? 'stop' : 'arrow';
      abxUi.send.innerHTML = sendHtml;
    }
    abxUi.send.classList.toggle('on', sending || hasText || abxAttached);
    abxUi.plus.classList.toggle('has', abxAttached);
    abxLayout(last);
  }

  function abxSubmit() {
    const st = abxState();
    if (st && st.sending) { window.__allbatStopCurrentResponse && window.__allbatStopCurrentResponse(); return; }
    const text = abxUi.input.value.trim();
    if (!text && !abxAttached) return;
    const real = document.getElementById('inp');
    if (real) {
      real.value = text;
      real.dispatchEvent(new Event('input', { bubbles: true }));
    }
    const button = document.getElementById('sendBtn');
    if (button) button.click();
    else if (real) real.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
    abxUi.input.value = '';
    abxUi.input.style.height = '';
    abxAttached = false;
    setTimeout(abxTick, 60);
  }

  function buildAssistantUi() {
    if (abxUi) return abxUi;
    const minrow = document.createElement('div');
    minrow.id = 'abx-minrow';
    minrow.innerHTML = '<button id="abx-min" type="button" aria-label="Minimize"><span>' + ABX_SVG.min + '</span><span>Minimize</span></button>';
    const ui = document.createElement('div');
    ui.id = 'abx-ui';
    ui.innerHTML = '<div id="abx-composer" dir="ltr">' +
      '<button id="abx-plus" class="abx-ib" type="button" aria-label="Attach part of the screen">' + ABX_SVG.plus + '</button>' +
      '<textarea id="abx-input" dir="auto" rows="1" placeholder="Ask Digi" enterkeyhint="send" autocomplete="off" autocorrect="off"></textarea>' +
      '<button id="abx-mic" class="abx-ib" type="button" aria-label="Voice conversation">' + ABX_SVG.mic + '</button>' +
      '<button id="abx-send" type="button" aria-label="Send" data-kind="arrow">' + ABX_SVG.arrow + '</button></div>';
    document.body.appendChild(minrow);
    document.body.appendChild(ui);
    abxUi = {
      minrow, ui,
      composer: ui.querySelector('#abx-composer'),
      input: ui.querySelector('#abx-input'),
      plus: ui.querySelector('#abx-plus'),
      mic: ui.querySelector('#abx-mic'),
      send: ui.querySelector('#abx-send')
    };
    minrow.querySelector('#abx-min').addEventListener('click', () => {
      try { if (native && typeof native.minimizeAssistant === 'function') native.minimizeAssistant(); } catch (_) {}
    });
    abxUi.plus.addEventListener('click', () => {
      try {
        if (native && typeof native.selectScreenRegion === 'function') native.selectScreenRegion();
        else setAssistantStatus('انتخاب بخشی از صفحه در دسترس نیست.');
      } catch (_) {}
    });
    abxUi.mic.addEventListener('click', () => {
      try { window.__assistantNativeStartVoiceConversation && window.__assistantNativeStartVoiceConversation(); } catch (_) {}
    });
    abxUi.send.addEventListener('click', abxSubmit);
    abxUi.input.addEventListener('keydown', event => {
      if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); abxSubmit(); }
    });
    abxUi.input.addEventListener('input', () => {
      abxUi.input.style.height = 'auto';
      abxUi.input.style.height = Math.min(120, abxUi.input.scrollHeight) + 'px';
      abxTick();
    });
    let queued = false;
    const schedule = () => {
      if (queued) return;
      queued = true;
      requestAnimationFrame(() => { queued = false; abxTick(); });
    };
    new MutationObserver(records => {
      if (records.some(r => !(r.target && r.target.closest && r.target.closest('#abx-ui,#abx-minrow')))) schedule();
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
    window.addEventListener('resize', schedule);
    try { new ResizeObserver(schedule).observe(abxUi.composer); } catch (_) {}
    setInterval(abxTick, 300);
    return abxUi;
  }

  // Match the reference answer card: compact feedback row plus a visible speaker button.
  try {
    if (typeof gemActs === 'function' && !gemActs.__allbatSpeechAction) {
      const originalGemActs = gemActs;
      const wrappedGemActs = function(message, isAssistant, meta) {
        const markup = originalGemActs.apply(this, arguments);
        if (!isAssistant || (meta && meta.pending) || !markup || !message) return markup;
        const id = typeof esc === 'function' ? esc(message.id) : String(message.id || '').replace(/[&<>"']/g, '');
        const button = `<button class="speak" type="button" data-allbat-readaloud="${id}" title="Read aloud" aria-label="Read aloud">${typeof ic === 'function' ? ic('speaker') : '◖))'}</button>`;
        const end = markup.lastIndexOf('</div>');
        return end < 0 ? markup : markup.slice(0, end) + button + markup.slice(end);
      };
      wrappedGemActs.__allbatSpeechAction = true;
      gemActs = wrappedGemActs;
      try { window.gemActs = wrappedGemActs; } catch (_) {}
    }
  } catch (error) { console.warn('Could not install answer read-aloud control', error); }
  const readAnswerAloud = messageId => {
    try {
      const session = typeof cur === 'function' ? cur() : null;
      const message = session && Array.isArray(session.messages) ? session.messages.find(m => String(m.id) === String(messageId)) : null;
      const text = String((message && (message.text || message.content)) || '').trim();
      if (!text) { if (typeof toast === 'function') toast('پاسخی برای خواندن پیدا نشد'); return; }
      if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') {
        if (typeof toast === 'function') toast('خواندن صوتی در این دستگاه در دسترس نیست'); return;
      }
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text.slice(0, 3500));
      utterance.lang = 'fa-IR'; utterance.rate = 1; utterance.pitch = 1;
      window.speechSynthesis.speak(utterance);
    } catch (error) { console.warn('Read aloud failed', error); if (typeof toast === 'function') toast('خواندن پاسخ انجام نشد'); }
  };
  document.addEventListener('click', event => {
    const button = event.target && event.target.closest ? event.target.closest('[data-allbat-readaloud]') : null;
    if (!button) return;
    event.preventDefault(); event.stopPropagation();
    readAnswerAloud(button.getAttribute('data-allbat-readaloud'));
  }, true);

  window.__allbatAssistantPanelMode = enabled => {
    if (!enabled) {
      document.body.classList.remove('allbat-assistant-panel-mode');
      if (assistantPanelBanner) assistantPanelBanner.remove();
      assistantPanelBanner = null;
      return;
    }
    ensureAssistantPanelStyles();
    document.body.classList.add('allbat-assistant-panel-mode');
    buildAssistantUi();
    abxTick();
    // No permanent banner here: the reference layout keeps the wallpaper visible and places only
    // the answer card, its actions, and the composer above the bottom edge.
    // The system assistant is a compact conversation surface, not the full app dashboard.
    // Reuse the existing chat/API implementation instead of introducing a parallel chat stack.
    if (!panelModeBooting) {
      panelModeBooting = true;
      setTimeout(async () => {
        try {
          if (typeof cur === 'function' && typeof newSession === 'function') {
            const current = cur();
            if (!current || current.type !== 'text') await newSession('text');
            else if (typeof go === 'function') go('chat');
          }
          document.body.classList.add('allbat-assistant-panel-mode');
          if (typeof render === 'function') render();
          const input = document.getElementById('inp');
          if (input) input.setAttribute('placeholder', 'Ask Digi');
        } catch (error) {
          console.warn('Could not prepare the compact assistant chat', error);
        } finally {
          panelModeBooting = false;
        }
      }, 220);
    }
  };

  window.__allbatAssistantSetScreenshot = dataUrl => {
    if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/jpeg;base64,')) return;
    assistantScreenshotDataUrl = dataUrl;
    setAssistantStatus('تصویر صفحه آماده است؛ انتخاب کن کدام بخش به پیش‌نویس پیوست شود.');
  };
  window.__allbatAssistantScreenshotUnavailable = () => {
    assistantScreenshotDataUrl = '';
    setAssistantStatus('اسکرین‌شات از برنامهٔ فعلی دریافت نشد؛ ممکن است تنظیمات حریم خصوصی یا سیستم آن را محدود کرده باشد.');
  };
  window.__allbatAssistantStartRegionSelection = openAssistantRegionSelector;

  toggle.addEventListener('click', () => {
    menuOpen = !menuOpen;
    menu.classList.toggle('open', menuOpen);
    toggle.setAttribute('aria-expanded', String(menuOpen));
  });

  function stopCamera() {
    if (cameraTimer) clearInterval(cameraTimer);
    cameraTimer = 0;
    if (cameraStream) {
      try { cameraStream.getTracks().forEach(track => track.stop()); } catch (_) {}
    }
    cameraStream = null;
    cameraActive = false;
    try { previewVideo.pause(); previewVideo.srcObject = null; } catch (_) {}
    preview.style.display = 'none';
    cameraButton.textContent = '📷 روشن‌کردن دوربین زنده';
    try { native && native.stopCameraSession(); } catch (_) {}
    setStatus('دوربین خاموش شد');
  }

  async function startCamera() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setStatus('دسترسی دوربین در این نسخهٔ WebView در دسترس نیست');
      return;
    }
    try {
      setStatus('در انتظار مجوز دوربین…');
      cameraStream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 640 }, height: { ideal: 480 },
          frameRate: { ideal: 12, max: 15 }
        }
      });
      previewVideo.srcObject = cameraStream;
      await previewVideo.play();
      preview.style.display = 'block';
      cameraActive = true;
      cameraButton.textContent = '⏹ خاموش‌کردن دوربین';
      try { native && native.startCameraSession(); } catch (_) {}
      if (!cameraCanvas) cameraCanvas = document.createElement('canvas');
      const context = cameraCanvas.getContext('2d', { alpha: false });
      cameraTimer = setInterval(() => {
        if (!cameraActive || !previewVideo.videoWidth || !context) return;
        if (!canSendLiveFrame()) return;
        const scale = Math.min(1, 640 / previewVideo.videoWidth);
        cameraCanvas.width = Math.max(1, Math.round(previewVideo.videoWidth * scale));
        cameraCanvas.height = Math.max(1, Math.round(previewVideo.videoHeight * scale));
        try {
          context.drawImage(previewVideo, 0, 0, cameraCanvas.width, cameraCanvas.height);
          const dataUrl = cameraCanvas.toDataURL('image/jpeg', 0.5);
          pushFrame(dataUrl.slice(dataUrl.indexOf(',') + 1));
        } catch (_) {}
      }, 1_150);
      setStatus(canSendLiveFrame() ? 'دوربین آمادهٔ ارسال تصویر است' : 'پیش‌نمایش روشن است؛ برای ارسال تصویر، گفت‌وگوی زنده را شروع کن.');
    } catch (error) {
      stopCamera();
      setStatus('مجوز یا دسترسی دوربین فراهم نشد');
      console.warn('All Bat camera start failed', error);
    }
  }

  cameraButton.addEventListener('click', () => {
    if (cameraActive) stopCamera(); else startCamera();
  });

  screenButton.addEventListener('click', () => {
    if (screenPermissionPending) return;
    if (!native) {
      setStatus('پل اندروید در دسترس نیست');
      return;
    }
    if (screenShareActive) {
      try { native.stopScreenShare(); } catch (_) { setStatus('توقف اشتراک صفحه ممکن نشد'); }
      return;
    }
    if (!canSendLiveFrame()) {
      if (native && typeof native.selectScreenRegion === 'function') {
        try { native.selectScreenRegion(); setAssistantStatus('انتخاب محدودهٔ صفحه را انجام بده.'); }
        catch (_) { setAssistantStatus('انتخاب محدوده ممکن نشد.'); }
        return;
      }
      setStatus('ابتدا گفت‌وگوی زنده را شروع کن؛ سپس اشتراک صفحه را روشن کن.');
      return;
    }
    screenPermissionPending = true;
    setStatus('در انتظار مجوز اعلان و تأیید سیستم برای اشتراک صفحه…');
    try { native.startScreenShare(); }
    catch (_) {
      screenPermissionPending = false;
      setStatus('شروع اشتراک صفحه ممکن نشد');
    }
  });

  document.getElementById('__allbat_role').addEventListener('click', () => {
    try { native && native.requestDefaultAssistant(); }
    catch (_) { setStatus('تنظیم دستیار پیش‌فرض در دسترس نیست'); }
  });
  document.getElementById('__allbat_overlay').addEventListener('click', () => {
    try {
      if (native && typeof native.requestFloatingAssistantOverlay === 'function') {
        native.requestFloatingAssistantOverlay();
        setAssistantStatus('تنظیمات نمایش روی برنامه‌های دیگر باز می‌شود؛ اجازهٔ حباب شناور را فعال کن.');
      } else {
        setAssistantStatus('حباب شناور فقط در نسخهٔ اندروید قابل فعال‌سازی است.');
      }
    } catch (_) { setAssistantStatus('بازکردن تنظیمات حباب شناور ممکن نشد.'); }
  });

  window.__allbatToggleMicrophone = () => {
    try {
      if (typeof toggleLiveMute === 'function') { toggleLiveMute(); return true; }
    } catch (error) { console.warn('Could not toggle Live microphone', error); }
    setAssistantStatus('کنترل میکروفون فقط هنگام فعال بودن گفت‌وگوی زنده در دسترس است.');
    return false;
  };
  window.__allbatToggleCamera = () => {
    try { cameraButton.click(); return true; }
    catch (error) { console.warn('Could not toggle Live camera', error); return false; }
  };
  window.__allbatToggleScreen = () => {
    try { screenButton.click(); return true; }
    catch (error) { console.warn('Could not toggle screen sharing', error); return false; }
  };
  window.__allbatOverlayOpenApp = () => {
    try { if (typeof go === 'function') go('chat'); } catch (_) {}
    try { document.getElementById('inp')?.focus({ preventScroll: true }); } catch (_) {}
    return true;
  };

  window.__assistantNativeFrame = pushFrame;
  window.__assistantNativeScreenStarted = () => {
    screenPermissionPending = false;
    screenShareActive = true;
    screenButton.textContent = '⏹ توقف اشتراک صفحه';
    setStatus('اشتراک صفحه فعال است؛ فریم‌ها فقط به Live فعال فرستاده می‌شوند');
  };
  window.__assistantNativeScreenStopped = () => {
    screenPermissionPending = false;
    screenShareActive = false;
    screenButton.textContent = '🖥️ اشتراک‌گذاری صفحه';
    setStatus('اشتراک صفحه متوقف شد');
  };
  window.__assistantNativeScreenDenied = () => {
    screenPermissionPending = false;
    setStatus('اشتراک صفحه لغو شد');
  };
  window.__allbatStopCurrentResponse = () => {
    try {
      if (typeof state !== 'undefined' && state.voiceConversation && typeof liveStopResponse === 'function') {
        liveStopResponse();
        return true;
      }
      if (typeof state !== 'undefined' && state.sending) {
        const sendButton = document.getElementById('sendBtn');
        if (sendButton && !sendButton.disabled) { sendButton.click(); return true; }
      }
    } catch (error) { console.warn('Could not stop the current response', error); }
    // Do not end the user's Live conversation just because a text response is still generating.
    setAssistantStatus('برای توقف این پاسخ، کنترل توقف را در صفحهٔ گفتگو بررسی کن.');
    return false;
  };

  window.__assistantNativeStopAll = () => {
    try { if (typeof stopVoiceConversation === 'function') stopVoiceConversation(false); } catch (_) {}
    stopCamera();
    try { native && native.stopVoiceSession(); } catch (_) {}
    try { native && native.stopScreenShare(); } catch (_) {}
    setStatus('نشست دستیار متوقف شد');
  };
  window.__assistantNativeStartVoiceConversation = () => {
    try {
      if (typeof state !== 'undefined' && state.voiceConversation) return true;
      if (typeof toggleVoiceConversation === 'function') {
        toggleVoiceConversation();
        setStatus('در حال شروع گفت‌وگوی زنده…');
        return true;
      }
    } catch (error) { console.warn('All Bat assistant launch failed', error); }
    setStatus('برای شروع گفت‌وگوی صوتی، صفحهٔ چت را باز کن');
    return false;
  };

  // Keep Android's foreground service alive only while the user-started Live mic is active.
  // The native layer receives a compact transcript/status snapshot for the floating orb.
  let lastOverlaySignature = '';
  let lastOverlayUser = '';
  let lastOverlayAnswer = '';
  let lastUserChangeAt = 0;
  let lastAnswerChangeAt = 0;
  const readLiveUserText = () => {
    try { return typeof liveTurnUserText === 'string' ? liveTurnUserText.trim() : ''; } catch (_) { return ''; }
  };
  const readLiveAnswerText = () => {
    try { return typeof liveTurnAssistantText === 'string' ? liveTurnAssistantText.trim() : ''; } catch (_) { return ''; }
  };
  function publishOverlayState(active, inputReady = true) {
    if (!native || typeof native.updateAssistantOverlay !== 'function') return;
    const now = Date.now();
    const userText = readLiveUserText();
    const answerText = readLiveAnswerText();
    if (userText !== lastOverlayUser) { lastOverlayUser = userText; lastUserChangeAt = now; }
    if (answerText !== lastOverlayAnswer) { lastOverlayAnswer = answerText; lastAnswerChangeAt = now; }
    const appGenerating = (() => { try { return !!(typeof state !== 'undefined' && state.sending); } catch (_) { return false; } })();
    const micMuted = (() => { try { return !!(typeof state !== 'undefined' && state.voiceMuted); } catch (_) { return false; } })();
    let generating = appGenerating;
    let status = active ? (inputReady ? 'گوش می‌دهم…' : 'در حال بازیابی اتصال صوتی…') : 'دستیار آماده است';
    if (active && inputReady) {
      if (answerText && now - lastAnswerChangeAt < 2100) {
        status = 'در حال پاسخ‌گویی…';
        generating = true;
      } else if (userText && !answerText && now - lastUserChangeAt > 900) {
        status = 'در حال پردازش پاسخ…';
        generating = true;
      } else if (userText && now - lastUserChangeAt < 1200) {
        status = 'در حال شنیدن…';
      }
    } else if (appGenerating) {
      status = 'Just a sec…';
    }
    const signature = JSON.stringify([userText, answerText, status, generating, micMuted, cameraActive, screenShareActive, active]);
    if (signature === lastOverlaySignature) return;
    lastOverlaySignature = signature;
    try {
      native.updateAssistantOverlay(userText, answerText, status, generating, micMuted, cameraActive, screenShareActive);
    } catch (error) { console.warn('Could not update native assistant overlay', error); }
  }
  // The foreground service follows the user's Live-session intent, NOT the current MediaStream.active
  // bit. Android/Chromium can temporarily end or recreate a track while the activity is backgrounded.
  // Previously one transient inactive sample stopped the native foreground service within 650 ms.
  let lastMicRecoveryAt = 0;
  let micRecoveryAttempts = 0;
  setInterval(() => {
    let requested = false;
    let streamReady = false;
    try {
      requested = typeof state !== 'undefined' && !!state.voiceConversation;
      if (typeof liveMicStream !== 'undefined' && liveMicStream) {
        const tracks = typeof liveMicStream.getAudioTracks === 'function' ? liveMicStream.getAudioTracks() : [];
        streamReady = !!liveMicStream.active && tracks.some(track => track && track.readyState === 'live');
      }
    } catch (_) {}

    if (requested && !voiceServiceActive) {
      voiceServiceActive = true;
      lastOverlaySignature = '';
      micRecoveryAttempts = 0;
      try { native && native.startVoiceSession(); } catch (_) {}
    } else if (!requested && voiceServiceActive) {
      // This is the one authoritative hang-up signal: the user or Live engine ended the session.
      voiceServiceActive = false;
      micRecoveryAttempts = 0;
      try { native && native.stopVoiceSession(); } catch (_) {}
    }

    if (requested && !streamReady) {
      const now = Date.now();
      const recoveryDelay = Math.min(15000, 2800 + micRecoveryAttempts * 600);
      if (now - lastMicRecoveryAt > recoveryDelay) {
        lastMicRecoveryAt = now;
        micRecoveryAttempts++;
        // Recovery reuses the existing Live audio graph; it does not create a second conversation.
        try {
          if (typeof liveAudioContext !== 'undefined' && liveAudioContext && liveAudioContext.state === 'suspended') {
            liveAudioContext.resume().catch(() => {});
          }
          if (typeof lvRestartMic === 'function') Promise.resolve(lvRestartMic()).catch(() => {});
        } catch (error) { console.warn('Live microphone recovery attempt failed', error); }
      }
    } else if (streamReady) {
      micRecoveryAttempts = 0;
    }
    publishOverlayState(requested, streamReady);
  }, 650);

  window.addEventListener('beforeunload', () => {
    // Normal backgrounding does not unload the document; actual page teardown releases camera.
    stopCamera();
  });
})();
