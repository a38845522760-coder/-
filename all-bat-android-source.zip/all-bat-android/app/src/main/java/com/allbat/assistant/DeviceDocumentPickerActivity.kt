package com.allbat.assistant

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import org.json.JSONObject
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** SAF bridge shared by the main app and Android's system-assistant surface. */
class DeviceDocumentPickerActivity : Activity() {
    companion object {
        private const val EXTRA_TOOL_NAME = "document_tool_name"
        private const val EXTRA_AWAITER_ID = "document_tool_awaiter_id"
        private const val EXTRA_MIME_TYPES = "document_tool_mime_types"
        private const val REQUEST_PICK_DOCUMENT = 8411

        fun createIntent(context: Context, toolName: String, awaiterId: String, mimeTypes: Array<String>): Intent =
            Intent(context, DeviceDocumentPickerActivity::class.java).apply {
                putExtra(EXTRA_TOOL_NAME, toolName)
                putExtra(EXTRA_AWAITER_ID, awaiterId)
                putExtra(EXTRA_MIME_TYPES, mimeTypes)
            }
    }

    private var toolName = ""
    private var awaiterId: String? = null
    private var completed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        toolName = intent.getStringExtra(EXTRA_TOOL_NAME).orEmpty()
        awaiterId = intent.getStringExtra(EXTRA_AWAITER_ID)
        if (toolName !in setOf("open_document", "share_document", "ocr_image") || !DeviceToolAwaiter.isPending(awaiterId)) {
            complete(false, "درخواست انتخاب فایل معتبر یا فعال نیست.")
            finish()
            return
        }
        try {
            val mimeTypes = intent.getStringArrayExtra(EXTRA_MIME_TYPES) ?: arrayOf("*/*")
            val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                if (mimeTypes.isNotEmpty() && mimeTypes.none { it == "*/*" }) {
                    putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
                }
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivityForResult(picker, REQUEST_PICK_DOCUMENT)
        } catch (_: Exception) {
            complete(false, "انتخاب‌گر امن فایل اندروید باز نشد.")
            finish()
        }
    }

    @Deprecated("Activity result retained for Android 8.1 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK_DOCUMENT) return
        val uri = if (resultCode == RESULT_OK) data?.data else null
        if (uri == null) {
            complete(false, "انتخاب فایل لغو شد؛ هیچ فایلی باز یا ارسال نشد.", cancelled = true)
            finish()
            return
        }
        if (toolName == "ocr_image") recognizeImage(uri) else openOrShare(uri)
        if (toolName != "ocr_image") finish()
    }

    private fun recognizeImage(uri: Uri) {
        var displayName = "تصویر انتخاب‌شده"
        var size: Long? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex >= 0) displayName = cursor.getString(nameIndex)?.take(180) ?: displayName
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
                }
            }
        } catch (_: Exception) { }
        if (size != null && size!! > 15L * 1024L * 1024L) {
            complete(false, "تصویر بیش از ۱۵ مگابایت است؛ یک نسخهٔ کوچک‌تر انتخاب کن.")
            finish()
            return
        }
        val mime = try { contentResolver.getType(uri).orEmpty() } catch (_: Exception) { "" }
        if (mime.isNotBlank() && !mime.startsWith("image/")) {
            complete(false, "فقط فایل تصویری برای OCR پذیرفته می‌شود.")
            finish()
            return
        }
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            val input = InputImage.fromFilePath(this, uri)
            recognizer.process(input)
                .addOnSuccessListener { result ->
                    val recognized = result.text.orEmpty().trim().take(12_000)
                    val data = JSONObject().put("name", displayName).put("text", recognized)
                        .put("character_count", recognized.length).put("recognition_script", "latin")
                        .put("processing", "on_device")
                    val message = if (recognized.isBlank())
                        "در این تصویر متن لاتینِ قابل‌تشخیصی پیدا نشد. این موتور برای خط لاتین است و متن فارسی داخل تصویر را OCR نمی‌کند."
                    else "متن تصویر به‌صورت محلی استخراج شد. می‌توانم محتوای متن استخراج‌شده را توضیح یا خلاصه کنم."
                    complete(recognized.isNotBlank(), message, data)
                    recognizer.close()
                    finish()
                }
                .addOnFailureListener { error ->
                    complete(false, "استخراج متن از تصویر ناموفق بود: ${error.javaClass.simpleName}")
                    recognizer.close()
                    finish()
                }
        } catch (_: Exception) {
            recognizer.close()
            complete(false, "بازکردن تصویر برای OCR ممکن نشد.")
            finish()
        }
    }

    private fun openOrShare(uri: Uri) {
        val metadata = JSONObject()
        var displayName = "فایل انتخاب‌شده"
        var size: Long? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex >= 0) displayName = cursor.getString(nameIndex)?.take(180) ?: displayName
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex).coerceAtLeast(0L)
                }
            }
        } catch (_: Exception) { }
        val mime = try { contentResolver.getType(uri)?.take(120) } catch (_: Exception) { null }
        metadata.put("name", displayName)
        if (!mime.isNullOrBlank()) metadata.put("mime_type", mime)
        if (size != null) metadata.put("size_bytes", size)

        val launched = try {
            when (toolName) {
                "open_document" -> {
                    val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime ?: "*/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(view, "باز کردن $displayName"))
                }
                "share_document" -> {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = mime ?: "application/octet-stream"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        clipData = ClipData.newUri(contentResolver, displayName, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(send, "اشتراک‌گذاری $displayName"))
                }
                else -> throw IllegalArgumentException("Unknown document tool")
            }
            true
        } catch (_: Exception) { false }

        val message = when {
            !launched -> "برنامهٔ سازگار برای بازکردن یا اشتراک‌گذاری فایل پیدا نشد."
            toolName == "open_document" -> "فایل «$displayName» به برنامهٔ سازگار سپرده شد."
            else -> "برگهٔ اشتراک‌گذاری فایل «$displayName» باز شد؛ مقصد را خودت انتخاب و تأیید کن."
        }
        complete(launched, message, metadata)
    }

    private fun complete(ok: Boolean, message: String, data: JSONObject = JSONObject(), cancelled: Boolean = false) {
        if (completed) return
        completed = true
        val result = JSONObject().put("ok", ok).put("message", message).put("data", data)
        if (cancelled) result.put("cancelled", true)
        DeviceToolAwaiter.complete(awaiterId, result.toString())
    }

    override fun onDestroy() {
        if (!completed && isFinishing && DeviceToolAwaiter.isPending(awaiterId)) {
            complete(false, "صفحهٔ انتخاب فایل بسته شد؛ هیچ فایلی باز یا ارسال نشد.", cancelled = true)
        }
        super.onDestroy()
    }
}
