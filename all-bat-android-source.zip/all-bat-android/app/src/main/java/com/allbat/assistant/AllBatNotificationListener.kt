package com.allbat.assistant

import android.service.notification.NotificationListenerService

/** Lets the read_notifications tool see the currently active notifications. Does nothing until the user enables it. */
class AllBatNotificationListener : NotificationListenerService() {
    companion object {
        @Volatile var instance: AllBatNotificationListener? = null
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
