package com.allbat.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

/** Native settings screen for the wake-phrase preference and the user's speech examples. */
class VoiceAssistantSettingsActivity : Activity() {
    companion object {
        private const val REQUEST_MICROPHONE = 7301
        private const val REQUEST_ASSISTANT_ROLE = 7302
        private const val REQUEST_SPEECH_SAMPLE = 7303
    }

    private lateinit var wakeSwitch: Switch
    private lateinit var statusView: TextView
    private lateinit var profileView: TextView
    private var pendingEnable = false
    private var trainingOnly = false
    private val preferenceListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == VoiceAssistantConfig.KEY_STATUS || key == VoiceAssistantConfig.KEY_ENABLED ||
            key == VoiceAssistantConfig.KEY_SPEECH_SAMPLES) {
            runOnUiThread { if (::wakeSwitch.isInitialized) refreshUi() }
        }
    }
    private val trainingPrompts = listOf(
        "سلام، من می‌خواهم با دستیارم طبیعی و راحت صحبت کنم.",
        "امروز می‌خواهم بدون تایپ کردن، کارهایم را با صدا انجام بدهم.",
        "وقتی چیزی را متوجه نشدی، لطفاً از من سؤال روشن‌کننده بپرس.",
        "پاسخ‌ها را با زبان ساده و متناسب با شیوهٔ صحبت من توضیح بده.",
        "برای باز کردن یک بخش، نام آن را می‌گویم و انتظار دارم درست متوجه شوی."
    )
    private val capturedSamples = arrayListOf<String>()
    private var sampleIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildSettingsUi()
        refreshUi()
    }

    override fun onStart() {
        super.onStart()
        getSharedPreferences(VoiceAssistantConfig.PREFS, MODE_PRIVATE)
            .registerOnSharedPreferenceChangeListener(preferenceListener)
    }

    override fun onResume() {
        super.onResume()
        if (::wakeSwitch.isInitialized) refreshUi()
    }

    override fun onStop() {
        getSharedPreferences(VoiceAssistantConfig.PREFS, MODE_PRIVATE)
            .unregisterOnSharedPreferenceChangeListener(preferenceListener)
        super.onStop()
    }

    private fun buildSettingsUi() {
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFFF5F7FB.toInt())
            isFillViewport = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(28))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "دستیار صوتی All Bat"
            textSize = 23f
            setTextColor(0xFF172033.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(title, marginParams(0, 0, 0, dp(8)))

        val intro = TextView(this).apply {
            text = "می‌توانی ترجیح خودت برای عبارت «Hi, Gemini» را روشن کنی؛ اما اندروید در API عمومیِ اپ‌های معمولی امکان شنود کم‌مصرفِ عبارت دلخواه را ارائه نمی‌کند. در نتیجه روشن‌کردن این گزینه به‌تنهایی بیدارباش واقعی را فعال نمی‌کند."
            textSize = 14f
            setTextColor(0xFF566176.toInt())
            setLineSpacing(dp(3).toFloat(), 1f)
        }
        content.addView(intro, marginParams(0, 0, 0, dp(18)))

        val toggleCard = cardContainer(dp(16))
        wakeSwitch = Switch(this).apply {
            text = "فعال‌سازی ترجیح عبارت «Hi, Gemini»"
            textSize = 16f
            setTextColor(0xFF172033.toInt())
            setPadding(0, dp(5), 0, dp(5))
            setOnCheckedChangeListener { _, checked ->
                if (checked) {
                    // Keep the switch off until permissions, assistant role and first-run setup finish.
                    isChecked = false
                    beginEnableFlow()
                } else if (getSharedPreferences(VoiceAssistantConfig.PREFS, MODE_PRIVATE)
                        .getBoolean(VoiceAssistantConfig.KEY_ENABLED, false)) {
                    disableWakeWord()
                }
            }
        }
        toggleCard.addView(wakeSwitch)
        statusView = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFF566176.toInt())
            setPadding(0, dp(8), 0, 0)
        }
        toggleCard.addView(statusView)
        content.addView(toggleCard, marginParams(0, 0, 0, dp(14)))

        val profileCard = cardContainer(dp(16))
        val profileTitle = TextView(this).apply {
            text = "آشنایی با شیوهٔ صحبت"
            textSize = 17f
            setTextColor(0xFF172033.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        profileCard.addView(profileTitle)
        val profileDescription = TextView(this).apply {
            text = "در راه‌اندازی اولیه، چند جمله را با لحن طبیعی خودت می‌گویی. برنامه فقط متنِ تشخیص‌داده‌شده را در حافظهٔ داخلی ذخیره می‌کند و فایل صدای خام را نگه نمی‌دارد. در مسیر تشخیص گفتار اندروید که از سرویس All Bat استفاده کند و در Android 13+، این متن‌ها در صورت پشتیبانی به‌عنوان راهنمای واژگان برای سرویس تشخیص انتخاب‌شده فرستاده می‌شوند؛ این کار صدای تو را آموزش نمی‌دهد یا هویت صوتی نمی‌سازد."
            textSize = 13f
            setTextColor(0xFF566176.toInt())
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(0, dp(8), 0, dp(10))
        }
        profileCard.addView(profileDescription)
        profileView = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFF65718A.toInt())
            setPadding(0, 0, 0, dp(10))
        }
        profileCard.addView(profileView)
        val trainButton = Button(this).apply {
            text = "ثبت چند جملهٔ نمونه"
            setOnClickListener {
                trainingOnly = true
                beginSpeechTraining()
            }
        }
        profileCard.addView(trainButton)
        val clearSamplesButton = Button(this).apply {
            text = "پاک‌کردن جمله‌های ذخیره‌شده"
            setOnClickListener {
                AlertDialog.Builder(this@VoiceAssistantSettingsActivity)
                    .setTitle("پاک‌کردن نمونه‌های گفتار")
                    .setMessage("همهٔ متن‌های نمونه از حافظهٔ داخلی برنامه پاک شوند؟")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("پاک‌کردن") { _, _ ->
                        getSharedPreferences(VoiceAssistantConfig.PREFS, MODE_PRIVATE).edit()
                            .remove(VoiceAssistantConfig.KEY_SPEECH_SAMPLES)
                            .putBoolean(VoiceAssistantConfig.KEY_PROFILE_READY, false)
                            .apply()
                        refreshUi()
                    }
                    .show()
            }
        }
        profileCard.addView(clearSamplesButton)
        content.addView(profileCard, marginParams(0, 0, 0, dp(14)))

        TextView(this).apply {
            text = "محدودیت فنی و حریم خصوصی: برنامه صدای تو را در پس‌زمینه ضبط یا به سرور ارسال نمی‌کند. تشخیص دائمیِ عبارت دلخواه نیازمند دسترسی سیستمی/سازندهٔ گوشی و مدل صوتی ثبت‌شده است؛ چنین API عمومی‌ای برای اپ عادی وجود ندارد. برای فراخوانی فعلی از روش سیستم اندروید (ژست دستیار یا کلید پاور، بسته به گوشی) استفاده کن."
            textSize = 12f
            setTextColor(0xFF6A7487.toInt())
            setLineSpacing(dp(3).toFloat(), 1f)
            content.addView(this, marginParams(0, dp(4), 0, 0))
        }

        val close = Button(this).apply {
            text = "بستن"
            setOnClickListener { finish() }
        }
        content.addView(close, marginParams(0, dp(16), 0, 0))
        setContentView(scroll)
    }

    private fun cardContainer(padding: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(padding, padding, padding, padding)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(0xFFFFFFFF.toInt())
            cornerRadius = 22f * resources.displayMetrics.density
            setStroke((resources.displayMetrics.density).toInt().coerceAtLeast(1), 0xFFE5EAF2.toInt())
        }
        elevation = 2f * resources.displayMetrics.density
    }

    private fun marginParams(width: Int, top: Int, right: Int, bottom: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(if (width == 0) LinearLayout.LayoutParams.MATCH_PARENT else width,
            LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = top
            rightMargin = right
            bottomMargin = bottom
        }

    private fun refreshUi() {
        val prefs = getSharedPreferences(VoiceAssistantConfig.PREFS, MODE_PRIVATE)
        val enabled = prefs.getBoolean(VoiceAssistantConfig.KEY_ENABLED, false)
        wakeSwitch.setOnCheckedChangeListener(null)
        wakeSwitch.isChecked = enabled
        wakeSwitch.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                wakeSwitch.isChecked = false
                beginEnableFlow()
            } else if (prefs.getBoolean(VoiceAssistantConfig.KEY_ENABLED, false)) {
                disableWakeWord()
            }
        }

        val status = prefs.getString(VoiceAssistantConfig.KEY_STATUS, VoiceAssistantConfig.STATUS_DISABLED)
            ?: VoiceAssistantConfig.STATUS_DISABLED
        statusView.text = when {
            !enabled -> "وضعیت: خاموش"
            status == VoiceAssistantConfig.STATUS_API_UNSUPPORTED -> "وضعیت: بیدارباش سفارشی «Hi, Gemini» از API عمومی اندروید در دسترس این برنامه نیست؛ این کلید فقط ترجیح تو را ذخیره می‌کند و می‌توانی دستیار را با روش سیستمی گوشی فراخوانی کنی."
            !isDefaultAssistant() -> "وضعیت: برای فراخوانی با ژست سیستم، All Bat را دستیار پیش‌فرض اندروید انتخاب کن."
            else -> "وضعیت: ترجیح ذخیره شده است؛ تشخیص عبارت سفارشی در API عمومی این نسخهٔ اندروید پشتیبانی نمی‌شود."
        }
        val samples = VoiceAssistantConfig.speechSamples(this)
        profileView.text = if (samples.isEmpty()) "هنوز جمله‌ای ثبت نشده است."
        else "${samples.size} جمله ثبت شده است. متن نمونه‌ها در حافظهٔ داخلی برنامه نگهداری می‌شود."
    }

    private fun beginEnableFlow() {
        pendingEnable = true
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MICROPHONE)
            return
        }
        ensureAssistantRole()
    }

    private fun ensureAssistantRole() {
        if (isDefaultAssistant()) {
            continueEnableSetup()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val manager = getSystemService(RoleManager::class.java)
                if (manager?.isRoleAvailable(RoleManager.ROLE_ASSISTANT) == true) {
                    startActivityForResult(manager.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT), REQUEST_ASSISTANT_ROLE)
                } else {
                    showRoleSettingsFallback()
                }
            } catch (_: Exception) {
                showRoleSettingsFallback()
            }
        } else showRoleSettingsFallback()
    }

    private fun showRoleSettingsFallback() {
        Toast.makeText(this, "ابتدا All Bat را به‌عنوان دستیار پیش‌فرض انتخاب کن.", Toast.LENGTH_LONG).show()
        try { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) } catch (_: Exception) { }
    }

    private fun continueEnableSetup() {
        val prefs = getSharedPreferences(VoiceAssistantConfig.PREFS, MODE_PRIVATE)
        val hasProfile = prefs.getBoolean(VoiceAssistantConfig.KEY_PROFILE_READY, false) &&
            VoiceAssistantConfig.speechSamples(this).isNotEmpty()
        if (hasProfile) {
            enableWakeWord()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("آشنایی با گفتار")
            .setMessage("برای ساخت پروفایل متنی، پنج جمله را با گفتار طبیعی خودت می‌گویی. سرویس تشخیص گفتارِ انتخاب‌شده در گوشی صدا را به متن تبدیل می‌کند؛ پردازش ممکن است محلی یا توسط همان سرویس انجام شود. برنامه فقط متن نهایی را نگه می‌دارد و فایل صدای خام را ذخیره نمی‌کند. در Android 13+ متن‌های نمونه ممکن است هنگام تشخیص گفتار به‌عنوان راهنمای واژگان برای سرویس انتخاب‌شده فرستاده شوند.")
            .setPositiveButton("شروع") { _, _ ->
                trainingOnly = false
                beginSpeechTraining()
            }
            .setNegativeButton("فعلاً رد می‌کنم") { _, _ -> enableWakeWord() }
            .show()
    }

    private fun beginSpeechTraining() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MICROPHONE)
            return
        }
        capturedSamples.clear()
        // Keep previous examples when the user adds a new set.
        capturedSamples.addAll(VoiceAssistantConfig.speechSamples(this))
        sampleIndex = 0
        launchNextSample()
    }

    private fun launchNextSample() {
        if (sampleIndex >= trainingPrompts.size) {
            VoiceAssistantConfig.saveSpeechSamples(this, capturedSamples)
            Toast.makeText(this, "نمونه‌های گفتار ذخیره شد.", Toast.LENGTH_SHORT).show()
            if (!trainingOnly) enableWakeWord() else refreshUi()
            return
        }
        val prompt = trainingPrompts[sampleIndex]
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "جملهٔ ${sampleIndex + 1} از ${trainingPrompts.size} را با لحن طبیعی خودت بگو:\n$prompt")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        try {
            startActivityForResult(intent, REQUEST_SPEECH_SAMPLE)
        } catch (_: Exception) {
            Toast.makeText(this, "سرویس تشخیص گفتار روی گوشی در دسترس نیست.", Toast.LENGTH_LONG).show()
            if (!trainingOnly) enableWakeWord() else refreshUi()
        }
    }

    private fun enableWakeWord() {
        getSharedPreferences(VoiceAssistantConfig.PREFS, MODE_PRIVATE).edit()
            .putBoolean(VoiceAssistantConfig.KEY_ENABLED, true)
            .putString(VoiceAssistantConfig.KEY_STATUS, VoiceAssistantConfig.STATUS_API_UNSUPPORTED)
            .apply()
        pendingEnable = false
        Toast.makeText(this, "ترجیح ذخیره شد؛ بیدارباش سفارشی در API عمومی این نسخهٔ اندروید در دسترس برنامه نیست.", Toast.LENGTH_LONG).show()
        refreshUi()
    }

    private fun disableWakeWord() {
        getSharedPreferences(VoiceAssistantConfig.PREFS, MODE_PRIVATE).edit()
            .putBoolean(VoiceAssistantConfig.KEY_ENABLED, false)
            .putString(VoiceAssistantConfig.KEY_STATUS, VoiceAssistantConfig.STATUS_DISABLED)
            .apply()
        pendingEnable = false
        refreshUi()
    }

    private fun isDefaultAssistant(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return try { getSystemService(RoleManager::class.java)?.isRoleHeld(RoleManager.ROLE_ASSISTANT) == true }
            catch (_: Exception) { false }
        }
        return Settings.Secure.getString(contentResolver, "voice_interaction_service")?.contains(packageName) == true
    }

    @Deprecated("Uses the activity-result contract required by the platform recognizer UI")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_ASSISTANT_ROLE -> {
                if (resultCode == RESULT_OK && isDefaultAssistant()) continueEnableSetup()
                else {
                    pendingEnable = false
                    refreshUi()
                    Toast.makeText(this, "برای استفاده از فراخوانی صوتی، انتخاب دستیار پیش‌فرض لازم است.", Toast.LENGTH_LONG).show()
                }
            }
            REQUEST_SPEECH_SAMPLE -> {
                if (resultCode == RESULT_OK) {
                    val transcript = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                        ?.firstOrNull()?.trim().orEmpty()
                    if (transcript.isNotEmpty()) capturedSamples.add(transcript.take(240))
                }
                sampleIndex++
                launchNextSample()
            }
        }
    }

    @Deprecated("Uses the platform permission callback for compatibility with the project's minSdk")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_MICROPHONE) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                if (pendingEnable) ensureAssistantRole() else if (trainingOnly) beginSpeechTraining()
            } else {
                pendingEnable = false
                refreshUi()
                Toast.makeText(this, "بدون مجوز میکروفون امکان تنظیم دستیار صوتی نیست.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
