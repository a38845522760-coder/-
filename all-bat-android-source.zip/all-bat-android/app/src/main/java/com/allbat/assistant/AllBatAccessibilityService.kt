package com.allbat.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Optional screen-control service. It does nothing until the user turns it on in Android settings,
 * only runs when a named tool asks for it, never reads events in the background, and refuses to
 * type into password fields.
 */
class AllBatAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: AllBatAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* intentionally unused */ }

    override fun onInterrupt() { /* intentionally unused */ }

    fun perform(action: String, text: String): Pair<Boolean, String> {
        return when (action) {
            "back" -> global(GLOBAL_ACTION_BACK, "برگشتم.")
            "home" -> global(GLOBAL_ACTION_HOME, "به صفحهٔ اصلی رفتم.")
            "recents" -> global(GLOBAL_ACTION_RECENTS, "برنامه‌های اخیر را باز کردم.")
            "notifications" -> global(GLOBAL_ACTION_NOTIFICATIONS, "پردهٔ اعلان‌ها را باز کردم.")
            "quick_settings" -> global(GLOBAL_ACTION_QUICK_SETTINGS, "تنظیمات سریع را باز کردم.")
            "lock" -> if (Build.VERSION.SDK_INT >= 28) global(GLOBAL_ACTION_LOCK_SCREEN, "صفحه قفل شد.")
                else false to "قفل‌کردن صفحه از اندروید ۹ به بعد پشتیبانی می‌شود."
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) global(GLOBAL_ACTION_TAKE_SCREENSHOT, "اسکرین‌شات گرفته شد.")
                else false to "اسکرین‌شات از اندروید ۹ به بعد پشتیبانی می‌شود."
            "tap" -> tapText(text)
            "type" -> typeText(text)
            "scroll_down" -> scroll(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
            "scroll_up" -> scroll(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
            else -> false to "action باید back، home، recents، notifications، quick_settings، lock، screenshot، tap، type، scroll_down یا scroll_up باشد."
        }
    }

    private fun global(code: Int, success: String): Pair<Boolean, String> =
        if (performGlobalAction(code)) true to success else false to "اندروید این عملیات را اجرا نکرد."

    private fun tapText(text: String): Pair<Boolean, String> {
        if (text.isBlank()) return false to "متنِ دکمه‌ای که باید لمس شود مشخص نیست."
        val root = rootInActiveWindow ?: return false to "محتوای صفحه در دسترس نیست."
        val matches = root.findAccessibilityNodeInfosByText(text)
        if (matches.isNullOrEmpty()) return false to "روی صفحه چیزی با عنوان «$text» پیدا نشد."
        val node = matches.first()
        var clickable: AccessibilityNodeInfo? = node
        while (clickable != null && !clickable.isClickable) clickable = clickable.parent
        if (clickable != null && clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true to "«$text» را لمس کردم."
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        if (bounds.isEmpty) return false to "«$text» قابل لمس نبود."
        val path = Path().apply { moveTo(bounds.exactCenterX(), bounds.exactCenterY()) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        return if (dispatchGesture(gesture, null, null)) true to "«$text» را لمس کردم." else false to "لمس انجام نشد."
    }

    private fun typeText(text: String): Pair<Boolean, String> {
        if (text.isBlank()) return false to "متنی برای نوشتن گفته نشد."
        val root = rootInActiveWindow ?: return false to "محتوای صفحه در دسترس نیست."
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false to "هیچ کادر متنی انتخاب نشده است؛ اول روی کادر بزن."
        if (field.isPassword) return false to "برای امنیت، در کادر رمز عبور چیزی تایپ نمی‌کنم."
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return if (field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) true to "متن نوشته شد." else false to "نوشتن در این کادر ممکن نشد."
    }

    private fun scroll(direction: Int): Pair<Boolean, String> {
        val root = rootInActiveWindow ?: return false to "محتوای صفحه در دسترس نیست."
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < 400) {
            val node = queue.removeFirst()
            visited++
            if (node.isScrollable && node.performAction(direction)) return true to "صفحه اسکرول شد."
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
        }
        return false to "بخش قابل اسکرول پیدا نشد."
    }
}
