package com.allbat.assistant

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Messenger
import android.os.RemoteException

/**
 * Asks the companion app "All Bat آفلاین" (com.allbat.offline) a question when there is no internet.
 * Events delivered to [onEvent]: kind = status | partial | done | error. For "partial" and "done" the text is the
 * whole answer so far; for "error" the code is no_model | forbidden | empty | failed | not_installed | bind_failed | lost.
 */
class OfflineBotClient(
    private val context: Context,
    private val onEvent: (id: String, kind: String, text: String, code: String) -> Unit
) {
    companion object {
        const val PACKAGE = "com.allbat.offline"
        private const val SERVICE = "com.allbat.offline.AskService"
        private const val MSG_ASK = 1
        private const val MSG_PARTIAL = 2
        private const val MSG_DONE = 3
        private const val MSG_ERROR = 4
        private const val MSG_CANCEL = 5
        private const val MSG_STATUS = 6
        private const val RELEASE_DELAY_MS = 45_000L
    }

    private val handler = Handler(Looper.getMainLooper())
    private var service: Messenger? = null
    private var bound = false
    private val pending = mutableListOf<Pair<String, String>>()
    private val active = mutableSetOf<String>()
    private val reply = Messenger(Handler(Looper.getMainLooper()) { msg -> onReply(msg); true })
    private val releaseRunnable = Runnable { if (active.isEmpty()) release() }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = Messenger(binder)
            val queued = pending.toList()
            pending.clear()
            queued.forEach { (id, text) -> sendAsk(id, text) }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            failAll("lost", "ارتباط با برنامهٔ آفلاین قطع شد")
        }

        override fun onBindingDied(name: ComponentName?) {
            service = null
            bound = false
            failAll("lost", "برنامهٔ آفلاین متوقف شد")
        }
    }

    private fun isPresent(): Boolean = try {
        context.packageManager.getPackageInfo(PACKAGE, 0)
        true
    } catch (_: Exception) {
        false
    }

    /** Installed AND signed with our own key; a look-alike app with the same package name is treated as missing. */
    fun isInstalled(): Boolean = isPresent() && PeerVerifier.matches(context, PACKAGE, BuildConfig.OFFLINE_CERT_SHA256)

    fun launchApp() {
        if (!isInstalled()) return
        try {
            context.packageManager.getLaunchIntentForPackage(PACKAGE)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(it)
            }
        } catch (_: Exception) { }
    }

    fun ask(id: String, text: String) {
        if (!isInstalled()) {
            if (isPresent()) {
                onEvent(id, "error", "برنامهٔ آفلاینِ نصب‌شده با امضای All Bat نمی‌خواند؛ برای امنیت به آن سؤال نمی‌فرستم.", "untrusted")
            } else {
                onEvent(id, "error", "برنامهٔ «All Bat آفلاین» روی این گوشی نصب نیست.", "not_installed")
            }
            return
        }
        handler.removeCallbacks(releaseRunnable)
        active.add(id)
        if (service != null) {
            sendAsk(id, text)
            return
        }
        pending.add(id to text)
        if (!bound) {
            bound = try {
                context.bindService(Intent().setClassName(PACKAGE, SERVICE), connection, Context.BIND_AUTO_CREATE)
            } catch (_: Exception) {
                false
            }
            if (!bound) failAll("bind_failed", "اتصال به برنامهٔ آفلاین ممکن نشد.")
        }
    }

    fun cancel(id: String) {
        pending.removeAll { it.first == id }
        if (active.remove(id)) {
            val m = android.os.Message.obtain(null, MSG_CANCEL)
            m.data = Bundle().apply { putString("id", id) }
            try { service?.send(m) } catch (_: RemoteException) { }
        }
        scheduleRelease()
    }

    fun release() {
        handler.removeCallbacks(releaseRunnable)
        if (bound) {
            try { context.unbindService(connection) } catch (_: Exception) { }
        }
        bound = false
        service = null
        pending.clear()
        active.clear()
    }

    private fun scheduleRelease() {
        handler.removeCallbacks(releaseRunnable)
        if (active.isEmpty() && bound) handler.postDelayed(releaseRunnable, RELEASE_DELAY_MS)
    }

    private fun sendAsk(id: String, text: String) {
        val m = android.os.Message.obtain(null, MSG_ASK)
        m.replyTo = reply
        m.data = Bundle().apply {
            putString("id", id)
            putString("text", text)
        }
        try {
            service?.send(m)
        } catch (_: RemoteException) {
            active.remove(id)
            onEvent(id, "error", "ارسال سؤال به برنامهٔ آفلاین ناموفق بود.", "lost")
        }
    }

    private fun failAll(code: String, message: String) {
        val ids = (active + pending.map { it.first }).toList()
        pending.clear()
        active.clear()
        ids.forEach { onEvent(it, "error", message, code) }
    }

    private fun onReply(msg: android.os.Message) {
        val data = msg.data
        val id = data.getString("id") ?: return
        when (msg.what) {
            MSG_STATUS -> onEvent(id, "status", data.getString("status") ?: "", "")
            MSG_PARTIAL -> onEvent(id, "partial", data.getString("text") ?: "", "")
            MSG_DONE -> {
                active.remove(id)
                onEvent(id, "done", data.getString("text") ?: "", "")
                scheduleRelease()
            }
            MSG_ERROR -> {
                active.remove(id)
                onEvent(id, "error", data.getString("error") ?: "خطا", data.getString("code") ?: "failed")
                scheduleRelease()
            }
        }
    }
}
