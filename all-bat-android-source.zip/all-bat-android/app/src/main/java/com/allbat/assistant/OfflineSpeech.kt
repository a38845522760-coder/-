package com.allbat.assistant

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Offline Persian speech recognition (Vosk, Apache-2.0, small model ~53 MB).
 * The model is downloaded once, only when the user asks for it, then everything runs on-device.
 */
object OfflineSpeechModel {
    const val MODEL_NAME = "vosk-model-small-fa-0.42"
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-fa-0.42.zip"
    private const val MIN_FREE_BYTES = 300L * 1024L * 1024L
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile private var installing = false

    fun modelDir(context: Context): File = File(File(context.applicationContext.filesDir, "offline-speech"), MODEL_NAME)

    fun isInstalled(context: Context): Boolean = File(modelDir(context), ".ready").isFile

    fun isInstalling(): Boolean = installing

    /** Starts the background download and returns the message to show/say right now. */
    fun startInstall(context: Context): String {
        val app = context.applicationContext
        if (isInstalled(app)) return "موتور صوتی آفلاین از قبل نصب است."
        if (installing) return "نصب موتور صوتی آفلاین در حال انجام است."
        if (!NetworkState.isOnline(app)) return "برای دانلود موتور صوتی آفلاین (حدود ۵۳ مگابایت) یک بار باید اینترنت وصل باشد."
        if (app.filesDir.usableSpace < MIN_FREE_BYTES) return "فضای خالی کافی نیست؛ حدود ۳۰۰ مگابایت لازم است."
        installing = true
        Thread({
            var result = ""
            val root = File(app.filesDir, "offline-speech")
            val staging = File(root, "staging")
            val zip = File(app.cacheDir, "$MODEL_NAME.zip")
            try {
                root.mkdirs()
                staging.deleteRecursively()
                staging.mkdirs()
                download(zip)
                unzip(zip, staging)
                val extracted = staging.listFiles()?.firstOrNull { it.isDirectory }
                    ?: throw IllegalStateException("empty archive")
                if (!(File(extracted, "am").isDirectory || File(extracted, "conf").isDirectory)) {
                    throw IllegalStateException("unexpected model layout")
                }
                val target = modelDir(app)
                target.deleteRecursively()
                if (!extracted.renameTo(target)) throw IllegalStateException("could not move model")
                File(target, ".ready").writeText("ok")
                result = "موتور صوتی آفلاین فارسی نصب شد؛ حالا فرمان‌های صوتی بدون اینترنت هم کار می‌کنند."
            } catch (e: Exception) {
                result = "نصب موتور صوتی آفلاین ناموفق بود (${e.javaClass.simpleName}). دوباره امتحان کن."
            } finally {
                staging.deleteRecursively()
                zip.delete()
                installing = false
            }
            mainHandler.post { Toast.makeText(app, result, Toast.LENGTH_LONG).show() }
        }, "allbat-offline-speech-install").start()
        return "دانلود موتور صوتی آفلاین فارسی (حدود ۵۳ مگابایت) شروع شد؛ ترجیحاً با Wi‑Fi. پایان نصب را با پیام اعلام می‌کنم."
    }

    private fun download(target: File) {
        val connection = URL(MODEL_URL).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 30000
        connection.instanceFollowRedirects = true
        try {
            connection.connect()
            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                throw IllegalStateException("HTTP " + connection.responseCode)
            }
            connection.inputStream.use { input ->
                FileOutputStream(target).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                    }
                }
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun unzip(zip: File, destination: File) {
        val rootPath = destination.canonicalPath + File.separator
        ZipInputStream(zip.inputStream().buffered()).use { stream ->
            var entry = stream.nextEntry
            while (entry != null) {
                val out = File(destination, entry.name)
                if (!out.canonicalPath.startsWith(rootPath)) throw SecurityException("unsafe archive entry")
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { stream.copyTo(it) }
                }
                stream.closeEntry()
                entry = stream.nextEntry
            }
        }
    }
}

/** One-shot microphone recognition with the installed offline model. Listener callbacks run on the main thread. */
class OfflineVoiceRecognizer(private val context: Context) {
    interface Listener {
        fun onPartial(text: String)
        fun onFinal(text: String)
        fun onError(message: String)
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var worker: Thread? = null

    fun start(listener: Listener, maxMillis: Long = 12000L) {
        if (running) return
        if (!OfflineSpeechModel.isInstalled(context)) {
            listener.onError("موتور صوتی آفلاین نصب نیست. وقتی اینترنت داری بگو «موتور صوتی آفلاین را نصب کن».")
            return
        }
        running = true
        worker = Thread({ runRecognition(listener, maxMillis) }, "allbat-offline-recognizer").also { it.start() }
    }

    fun stop() {
        running = false
    }

    private fun post(block: () -> Unit) { mainHandler.post { block() } }

    private fun textOf(json: String, key: String): String = try {
        JSONObject(json).optString(key).trim()
    } catch (_: Exception) { "" }

    private fun runRecognition(listener: Listener, maxMillis: Long) {
        var model: Model? = null
        var recognizer: Recognizer? = null
        var record: AudioRecord? = null
        var delivered = false
        try {
            model = Model(OfflineSpeechModel.modelDir(context).absolutePath)
            recognizer = Recognizer(model, 16000.0f)
            val minBuffer = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val bufferSize = maxOf(minBuffer, 16000)
            record = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
            if (record.state != AudioRecord.STATE_INITIALIZED) {
                post { listener.onError("میکروفون برای تشخیص آفلاین در دسترس نیست.") }
                delivered = true
                return
            }
            record.startRecording()
            val buffer = ByteArray(4096)
            val startedAt = SystemClock.uptimeMillis()
            var lastPartial = ""
            while (running && SystemClock.uptimeMillis() - startedAt < maxMillis) {
                val count = record.read(buffer, 0, buffer.size)
                if (count <= 0) continue
                if (recognizer.acceptWaveForm(buffer, count)) {
                    val text = textOf(recognizer.result, "text")
                    if (text.isNotBlank()) {
                        delivered = true
                        post { listener.onFinal(text) }
                        return
                    }
                } else {
                    val partial = textOf(recognizer.partialResult, "partial")
                    if (partial.isNotBlank() && partial != lastPartial) {
                        lastPartial = partial
                        post { listener.onPartial(partial) }
                    }
                }
            }
            if (running) {
                val text = textOf(recognizer.finalResult, "text")
                delivered = true
                if (text.isNotBlank()) post { listener.onFinal(text) }
                else post { listener.onError("گفتاری تشخیص داده نشد؛ دوباره امتحان کن یا فرمان را بنویس.") }
            }
        } catch (e: SecurityException) {
            delivered = true
            post { listener.onError("مجوز میکروفون در دسترس نیست.") }
        } catch (t: Throwable) {
            delivered = true
            android.util.Log.w("AllBatSpeech", "Offline recognizer failed", t)
            post { listener.onError("موتور صوتی آفلاین روی این دستگاه اجرا نشد؛ فرمان را بنویس.") }
        } finally {
            running = false
            try { record?.stop() } catch (_: Exception) { }
            try { record?.release() } catch (_: Exception) { }
            try { recognizer?.close() } catch (_: Throwable) { }
            try { model?.close() } catch (_: Throwable) { }
            if (!delivered) { /* cancelled by the caller: nothing to report */ }
        }
    }
}
