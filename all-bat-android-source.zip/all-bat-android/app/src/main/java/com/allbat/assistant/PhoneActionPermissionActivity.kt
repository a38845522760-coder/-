package com.allbat.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat

/** Small permission gateway used from the system assistant session. */
class PhoneActionPermissionActivity : Activity() {
    companion object {
        const val EXTRA_COMMAND = "phone_action_command"
        const val EXTRA_PERMISSION = "phone_action_permission"
        const val ACTION_AUDIO_PERMISSION_GRANTED = "com.allbat.assistant.ACTION_AUDIO_PERMISSION_GRANTED"
        private const val REQUEST_PERMISSION = 7812
    }

    private var command: String? = null
    private var permission: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        command = intent.getStringExtra(EXTRA_COMMAND)?.take(500)
        permission = intent.getStringExtra(EXTRA_PERMISSION)
            ?: command?.let { PhoneActionEngine.parse(it)?.let(PhoneActionEngine::requiredPermission) }
            ?: Manifest.permission.RECORD_AUDIO
        continueWithPermission()
    }

    private fun continueWithPermission() {
        val needed = permission ?: run { finish(); return }
        if (ContextCompat.checkSelfPermission(this, needed) == PackageManager.PERMISSION_GRANTED) {
            completeGranted()
        } else {
            requestPermissions(arrayOf(needed), REQUEST_PERMISSION)
        }
    }

    private fun completeGranted() {
        val rawCommand = command
        if (rawCommand.isNullOrBlank()) {
            if (permission == Manifest.permission.RECORD_AUDIO) {
                sendBroadcast(Intent(ACTION_AUDIO_PERMISSION_GRANTED).setPackage(packageName))
            }
            finish()
            return
        }
        val request = PhoneActionEngine.parse(rawCommand)
        if (request == null) {
            Toast.makeText(this, "فرمان شناخته نشد؛ دوباره امتحان کن.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val outcome = PhoneActionEngine.execute(this, request)
        if (outcome.permission != null) {
            Toast.makeText(this, "مجوز لازم فعال نشد. از تنظیمات برنامه بررسی کن.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, outcome.message, Toast.LENGTH_LONG).show()
            outcome.intent?.let { target ->
                try { startActivity(target) } catch (_: Exception) {
                    Toast.makeText(this, "برنامهٔ لازم برای این فرمان پیدا نشد.", Toast.LENGTH_LONG).show()
                }
            }
        }
        finish()
    }

    @Deprecated("Permission callback retained for compatibility with the app's minSdk")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_PERMISSION) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            completeGranted()
        } else {
            Toast.makeText(this, "مجوز داده نشد؛ این فرمان اجرا نشد.", Toast.LENGTH_LONG).show()
            finish()
        }
    }
}
