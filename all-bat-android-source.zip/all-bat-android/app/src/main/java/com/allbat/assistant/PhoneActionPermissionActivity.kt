package com.allbat.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat
import org.json.JSONObject

/** Permission gateway for a model-requested, allow-listed Android device tool. */
class PhoneActionPermissionActivity : Activity() {
    companion object {
        const val EXTRA_COMMAND = "phone_action_command"
        const val EXTRA_PERMISSION = "phone_action_permission"
        const val EXTRA_TOOL_NAME = "device_tool_name"
        const val EXTRA_TOOL_ARGS = "device_tool_args"
        const val EXTRA_AWAITER_ID = "device_tool_awaiter_id"
        const val ACTION_AUDIO_PERMISSION_GRANTED = "com.allbat.assistant.ACTION_AUDIO_PERMISSION_GRANTED"
        private const val REQUEST_PERMISSION = 7812
    }

    private var command: String? = null
    private var permission: String? = null
    private var toolName: String? = null
    private var toolArgs: String = "{}"
    private var awaiterId: String? = null
    private var pendingPermissions: Array<String> = emptyArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        command = intent.getStringExtra(EXTRA_COMMAND)?.take(500)
        toolName = intent.getStringExtra(EXTRA_TOOL_NAME)?.take(80)
        toolArgs = intent.getStringExtra(EXTRA_TOOL_ARGS)?.take(4000) ?: "{}"
        awaiterId = intent.getStringExtra(EXTRA_AWAITER_ID)
        permission = intent.getStringExtra(EXTRA_PERMISSION)
            ?: command?.let { PhoneActionEngine.parse(it)?.let(PhoneActionEngine::requiredPermission) }
            ?: if (toolName.isNullOrBlank()) Manifest.permission.RECORD_AUDIO else null
        continueWithPermission()
    }

    private fun continueWithPermission() {
        if (!toolName.isNullOrBlank()) {
            val outcome = PhoneActionEngine.executeTool(this, toolName!!, toolArgs)
            pendingPermissions = outcome.permissions.distinct().filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }.toTypedArray()
            if (pendingPermissions.isNotEmpty()) {
                requestPermissions(pendingPermissions, REQUEST_PERMISSION)
                return
            }
            completeDeviceTool(outcome)
            return
        }

        val needed = permission ?: run { finish(); return }
        if (ContextCompat.checkSelfPermission(this, needed) == PackageManager.PERMISSION_GRANTED) {
            completeGranted()
        } else {
            requestPermissions(arrayOf(needed), REQUEST_PERMISSION)
        }
    }

    private fun completeGranted() {
        val rawCommand = command
        if (rawCommand.isNullOrBlank()) {
            if (permission == Manifest.permission.RECORD_AUDIO) {
                sendBroadcast(Intent(ACTION_AUDIO_PERMISSION_GRANTED).setPackage(packageName))
            }
            finish()
            return
        }
        val request = PhoneActionEngine.parse(rawCommand)
        if (request == null) {
            Toast.makeText(this, "فرمان شناخته نشد؛ دوباره امتحان کن.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val outcome = PhoneActionEngine.execute(this, request)
        if (outcome.permission != null) {
            Toast.makeText(this, "مجوز لازم فعال نشد. از تنظیمات برنامه بررسی کن.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, outcome.message, Toast.LENGTH_LONG).show()
            outcome.intent?.let { launchSafely(it) }
        }
        finish()
    }

    private fun completeDeviceTool(outcome: PhoneActionEngine.ToolOutcome) {
        // A timed-out or cancelled WebView tool call must not execute later after a delayed grant.
        if (!DeviceToolAwaiter.isPending(awaiterId)) {
            finish()
            return
        }
        if (outcome.permissions.isNotEmpty()) {
            val result = JSONObject().put("ok", false).put("message", "مجوز لازم تأیید نشد.").toString()
            DeviceToolAwaiter.complete(awaiterId, result)
            finish()
            return
        }
        var launched = true
        outcome.intent?.let { launched = launchSafely(it) }
        val finalResult = if (launched) outcome.toJson() else
            JSONObject().put("ok", false).put("message", "اندروید اجازهٔ بازکردن بخش درخواستی را نداد.").toString()
        DeviceToolAwaiter.complete(awaiterId, finalResult)
        Toast.makeText(this, outcome.message, Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun launchSafely(target: Intent): Boolean = try {
        startActivity(target.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (_: Exception) { false }

    @Deprecated("Permission callback retained for compatibility with minSdk")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_PERMISSION) return
        val granted = permissions.isNotEmpty() && grantResults.size == permissions.size &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        if (!granted) {
            if (!toolName.isNullOrBlank()) {
                DeviceToolAwaiter.complete(awaiterId, JSONObject().put("ok", false)
                    .put("message", "مجوز لازم تأیید نشد؛ عملیات اجرا نشد.").toString())
            } else {
                Toast.makeText(this, "مجوز داده نشد؛ این فرمان اجرا نشد.", Toast.LENGTH_LONG).show()
            }
            finish()
            return
        }
        if (!toolName.isNullOrBlank()) {
            val updated = PhoneActionEngine.executeTool(this, toolName!!, toolArgs)
            completeDeviceTool(updated)
        } else {
            completeGranted()
        }
    }
}
