package com.allbat.assistant

import android.content.Context
import android.content.Intent

/**
 * Sends control actions to [SessionForegroundService].
 *
 * Android 8.0+ forbids startService() while the app is in the background and throws
 * IllegalStateException. A swallowed failure on a STOP action used to leave the microphone
 * foreground service (and its notification/orb) running after the voice chat had ended.
 * stopService() is always allowed, so it is used as the fallback for STOP_VOICE / STOP_ALL.
 */
internal object SessionServiceControl {
    fun send(context: Context, action: String) {
        val intent = Intent(context, SessionForegroundService::class.java).setAction(action)
        try {
            context.startService(intent)
        } catch (_: Exception) {
            if (action == SessionForegroundService.ACTION_STOP_VOICE || action == SessionForegroundService.ACTION_STOP_ALL) {
                try { context.stopService(Intent(context, SessionForegroundService::class.java)) } catch (_: Exception) { }
            }
        }
    }
}
