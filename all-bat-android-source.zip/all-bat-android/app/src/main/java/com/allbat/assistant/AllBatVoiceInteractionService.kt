package com.allbat.assistant

import android.content.Context
import android.service.voice.VoiceInteractionService

/**
 * System entry point for the selected assistant. Android's public SDK no longer exposes
 * custom always-on hotword enrollment/detection to ordinary applications, so this service
 * deliberately does not open the microphone or pretend to monitor a wake phrase.
 */
class AllBatVoiceInteractionService : VoiceInteractionService() {
    private val preferences by lazy {
        getSharedPreferences(VoiceAssistantConfig.PREFS, Context.MODE_PRIVATE)
    }

    private val preferenceListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == VoiceAssistantConfig.KEY_ENABLED) updateHotwordStatus()
    }

    override fun onCreate() {
        super.onCreate()
        preferences.registerOnSharedPreferenceChangeListener(preferenceListener)
    }

    override fun onReady() {
        super.onReady()
        updateHotwordStatus()
    }

    private fun updateHotwordStatus() {
        val status = if (preferences.getBoolean(VoiceAssistantConfig.KEY_ENABLED, false)) {
            VoiceAssistantConfig.STATUS_API_UNSUPPORTED
        } else {
            VoiceAssistantConfig.STATUS_DISABLED
        }
        VoiceAssistantConfig.setStatus(this, status)
    }

    override fun onDestroy() {
        preferences.unregisterOnSharedPreferenceChangeListener(preferenceListener)
        super.onDestroy()
    }
}
