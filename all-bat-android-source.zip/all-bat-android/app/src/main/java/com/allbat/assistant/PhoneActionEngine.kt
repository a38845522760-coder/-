package com.allbat.assistant

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import android.hardware.camera2.CameraManager
import java.text.Normalizer
import java.util.Locale

/** Local Android actions. No Google Play Services or Google APIs are used here. */
internal object PhoneActionEngine {
    data class Request(val kind: Kind, val target: String = "", val body: String = "", val hour: Int = -1, val minute: Int = 0)
    enum class Kind { CALL_CONTACT, SMS_CONTACT, OPEN_CAMERA, OPEN_SETTINGS, OPEN_BROWSER, OPEN_GALLERY, OPEN_CLOCK, OPEN_CALCULATOR, VOLUME_UP, VOLUME_DOWN, VOLUME_MUTE, VOLUME_UNMUTE, FLASH_ON, FLASH_OFF, WIFI_PANEL, BLUETOOTH_SETTINGS, ALARM, TIMER }
    data class Outcome(val handled: Boolean, val message: String, val intent: Intent? = null, val permission: String? = null)

    fun normalize(input: String): String {
        val digits = input
            .replace('۰', '0').replace('۱', '1').replace('۲', '2').replace('۳', '3').replace('۴', '4')
            .replace('۵', '5').replace('۶', '6').replace('۷', '7').replace('۸', '8').replace('۹', '9')
            .replace('٠', '0').replace('١', '1').replace('٢', '2').replace('٣', '3').replace('٤', '4')
            .replace('٥', '5').replace('٦', '6').replace('٧', '7').replace('٨', '8').replace('٩', '9')
        return Normalizer.normalize(digits, Normalizer.Form.NFKC)
            .replace('ي', 'ی').replace('ك', 'ک')
            .replace("\u200c", " ").replace("\u200f", " ").replace("\u200e", " ")
            .lowercase(Locale.ROOT)
            .replace(Regex("[،؛,:!?؟.!]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun parse(raw: String): Request? {
        val text = normalize(raw)
        if (text.isBlank()) return null

        val callWith = Regex("^(?:لطفا\\s+)?با\\s+(.+?)\\s+تماس\\s+بگیر$").matchEntire(text)
        if (callWith != null) return Request(Kind.CALL_CONTACT, target = cleanTarget(callWith.groupValues[1]))
        val phoneCall = Regex("^(?:لطفا\\s+)?(?:به\\s+)?(.+?)\\s+(?:زنگ\\s+بزن|تماس\\s+بگیر|زنگ\\s+بزنید)$").matchEntire(text)
        if (phoneCall != null) return Request(Kind.CALL_CONTACT, target = cleanTarget(phoneCall.groupValues[1]))

        val sms = Regex("^(?:لطفا\\s+)?به\\s+(.+?)\\s+پیام(?:ک)?\\s+بده(?:\\s+(?:که\\s+)?(.+))?$").matchEntire(text)
        if (sms != null) return Request(Kind.SMS_CONTACT, target = cleanTarget(sms.groupValues[1]), body = sms.groupValues.getOrElse(2) { "" }.trim())

        if (containsAny(text, "چراغ قوه را روشن", "چراغ قوه رو روشن", "فلش را روشن", "فلش رو روشن")) return Request(Kind.FLASH_ON)
        if (containsAny(text, "چراغ قوه را خاموش", "چراغ قوه رو خاموش", "فلش را خاموش", "فلش رو خاموش")) return Request(Kind.FLASH_OFF)
        if (containsAny(text, "صدای گوشی را زیاد", "صدا رو زیاد", "صدا را زیاد", "ولوم را زیاد", "ولوم رو زیاد")) return Request(Kind.VOLUME_UP)
        if (containsAny(text, "صدای گوشی را کم", "صدا رو کم", "صدا را کم", "ولوم را کم", "ولوم رو کم")) return Request(Kind.VOLUME_DOWN)
        if (containsAny(text, "صدا را قطع", "صدا رو قطع", "بی صدا کن", "سایلنت کن")) return Request(Kind.VOLUME_MUTE)
        if (containsAny(text, "صدا را وصل", "صدا رو وصل", "از بی صدا خارج", "صدا را برگردان")) return Request(Kind.VOLUME_UNMUTE)
        if (containsAny(text, "وای فای را باز", "وای فای رو باز", "تنظیمات وای فای", "تنظیمات اینترنت", "وای فای را روشن", "وای فای رو روشن", "وای فای را خاموش", "وای فای رو خاموش")) return Request(Kind.WIFI_PANEL)
        if (containsAny(text, "بلوتوث را باز", "بلوتوث رو باز", "تنظیمات بلوتوث", "بلوتوث را روشن", "بلوتوث رو روشن", "بلوتوث را خاموش", "بلوتوث رو خاموش")) return Request(Kind.BLUETOOTH_SETTINGS)
        if (containsAny(text, "دوربین را باز", "دوربین رو باز", "دوربین را اجرا", "دوربین رو اجرا")) return Request(Kind.OPEN_CAMERA)
        if (containsAny(text, "تنظیمات را باز", "تنظیمات رو باز", "تنظیمات گوشی")) return Request(Kind.OPEN_SETTINGS)
        if (containsAny(text, "مرورگر را باز", "مرورگر رو باز", "اینترنت را باز", "اینترنت رو باز")) return Request(Kind.OPEN_BROWSER)
        if (containsAny(text, "گالری را باز", "گالری رو باز", "عکس ها را باز", "تصاویر را باز")) return Request(Kind.OPEN_GALLERY)
        if (containsAny(text, "ساعت را باز", "ساعت رو باز", "برنامه ساعت")) return Request(Kind.OPEN_CLOCK)
        if (containsAny(text, "ماشین حساب را باز", "ماشین حساب رو باز", "حسابگر را باز")) return Request(Kind.OPEN_CALCULATOR)

        val timer = Regex("^(?:برای\\s+)?(\\d{1,3})\\s*(?:دقیقه|دقیقه ای)\\s*(?:تایمر|زمان سنج)\\s*(?:بگذار|تنظیم کن)?$").matchEntire(text)
            ?: Regex("^(?:تایمر|زمان سنج)\\s+(?:برای\\s+)?(\\d{1,3})\\s*دقیقه\\s*(?:بگذار|تنظیم کن)?$").matchEntire(text)
        if (timer != null) return Request(Kind.TIMER, minute = timer.groupValues[1].toIntOrNull() ?: 0)

        val alarm = Regex("^(?:برای\\s+)?(?:ساعت\\s+)?(\\d{1,2})(?::(\\d{1,2}))?\\s*(?:زنگ\\s+هشدار|آلارم)\\s*(?:بگذار|تنظیم کن)?$").matchEntire(text)
            ?: Regex("^(?:زنگ\\s+هشدار|آلارم)\\s+(?:برای\\s+)?(?:ساعت\\s+)?(\\d{1,2})(?::(\\d{1,2}))?$").matchEntire(text)
        if (alarm != null) {
            val hour = alarm.groupValues[1].toIntOrNull() ?: -1
            val minute = alarm.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
            if (hour in 0..23 && minute in 0..59) return Request(Kind.ALARM, hour = hour, minute = minute)
        }
        return null
    }

    private fun cleanTarget(value: String): String = value
        .removePrefix("آقای ").removePrefix("اقای ").removePrefix("خانم ")
        .removeSuffix(" عزیز").trim()

    private fun containsAny(text: String, vararg parts: String): Boolean = parts.any { text.contains(it) }

    fun requiredPermission(request: Request): String? = when (request.kind) {
        Kind.CALL_CONTACT, Kind.SMS_CONTACT -> Manifest.permission.READ_CONTACTS
        Kind.FLASH_ON, Kind.FLASH_OFF -> Manifest.permission.CAMERA
        else -> null
    }

    fun execute(context: Context, request: Request): Outcome {
        val permission = requiredPermission(request)
        if (permission != null && context.checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            return Outcome(true, "برای این فرمان، مجوز لازم باید از خود اندروید تأیید شود.", permission = permission)
        }

        return try {
            when (request.kind) {
                Kind.CALL_CONTACT, Kind.SMS_CONTACT -> contactAction(context, request)
                Kind.OPEN_CAMERA -> Outcome(true, "دوربین را باز می‌کنم.", Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Kind.OPEN_SETTINGS -> Outcome(true, "تنظیمات گوشی را باز می‌کنم.", Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Kind.OPEN_BROWSER -> Outcome(true, "مرورگر را باز می‌کنم.", Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Kind.OPEN_GALLERY -> Outcome(true, "گالری را باز می‌کنم.", Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Kind.OPEN_CLOCK -> Outcome(true, "برنامهٔ ساعت را باز می‌کنم.", Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Kind.OPEN_CALCULATOR -> openCalculator(context)
                Kind.VOLUME_UP, Kind.VOLUME_DOWN, Kind.VOLUME_MUTE, Kind.VOLUME_UNMUTE -> adjustVolume(context, request.kind)
                Kind.FLASH_ON, Kind.FLASH_OFF -> setFlashlight(context, request.kind == Kind.FLASH_ON)
                Kind.WIFI_PANEL -> openWifiPanel()
                Kind.BLUETOOTH_SETTINGS -> Outcome(true, "برای تغییر بلوتوث، تنظیمات سیستمی اندروید را باز می‌کنم.", Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Kind.ALARM -> Outcome(true, "صفحهٔ ثبت زنگ هشدار را باز می‌کنم.", Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, request.hour).putExtra(AlarmClock.EXTRA_MINUTES, request.minute).putExtra(AlarmClock.EXTRA_MESSAGE, "All Bat").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Kind.TIMER -> if (request.minute in 1..180) Outcome(true, "تایمر را در برنامهٔ ساعت تنظیم می‌کنم.", Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, request.minute * 60).putExtra(AlarmClock.EXTRA_MESSAGE, "All Bat").putExtra(AlarmClock.EXTRA_SKIP_UI, false).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) else Outcome(true, "مدت تایمر باید بین ۱ تا ۱۸۰ دقیقه باشد.")
            }
        } catch (error: SecurityException) {
            Outcome(true, "اندروید اجازهٔ اجرای این عملیات را نداد؛ مجوز یا محدودیت سیستم را بررسی کن.")
        } catch (error: Exception) {
            Outcome(true, "اجرای فرمان ممکن نشد؛ برنامهٔ موردنیاز یا قابلیت آن در این گوشی در دسترس نیست.")
        }
    }

    private fun contactAction(context: Context, request: Request): Outcome {
        val numbers = mutableListOf<String>()
        var cursor: Cursor? = null
        try {
            val filterUri = Uri.withAppendedPath(ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(request.target))
            cursor = context.contentResolver.query(
                filterUri,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null
            )
            while (cursor?.moveToNext() == true) {
                val name = cursor.getString(0).orEmpty()
                val number = cursor.getString(1).orEmpty()
                if (number.isNotBlank()) numbers.add("$name|$number")
            }
        } finally {
            cursor?.close()
        }
        val unique = numbers.distinctBy { it.substringAfter('|').filter { c -> c.isDigit() } }
        if (unique.isEmpty()) return Outcome(true, "مخاطبی با نام «${request.target}» پیدا نکردم. نام را دقیق‌تر بگو یا از مخاطبین انتخاب کن.")
        if (unique.size > 1) {
            val names = unique.map { it.substringBefore('|').trim() }.distinct()
            return if (names.size > 1) {
                Outcome(true, "چند مخاطب مشابه پیدا کردم: ${names.take(4).joinToString("، ")}. نام کامل‌تر را بگو تا اشتباهی تماس گرفته نشود.")
            } else {
                Outcome(true, "برای «${names.firstOrNull().orEmpty()}» چند شماره ثبت شده است؛ ابتدا شمارهٔ پیش‌فرض را در مخاطبین مشخص کن.")
            }
        }
        val number = unique.first().substringAfter('|').trim()
        return if (request.kind == Kind.CALL_CONTACT) {
            Outcome(true, "شمارهٔ ${request.target} در شماره‌گیر آماده شد؛ تماس را خودت تأیید کن.", Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
            val uri = Uri.fromParts("smsto", number, null)
            val intent = Intent(Intent.ACTION_SENDTO, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (request.body.isNotBlank()) intent.putExtra("sms_body", request.body)
            Outcome(true, "پیام برای ${request.target} آماده شد؛ پیش از ارسال آن را بررسی کن.", intent)
        }
    }

    private fun adjustVolume(context: Context, kind: Kind): Outcome {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when (kind) {
            Kind.VOLUME_UP -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            Kind.VOLUME_DOWN -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            Kind.VOLUME_MUTE -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            else -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
        }
        return Outcome(true, "تنظیم صدای رسانه انجام شد.")
    }

    private fun setFlashlight(context: Context, enabled: Boolean): Outcome {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = manager.cameraIdList.firstOrNull { id -> manager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return Outcome(true, "چراغ‌قوه در این دستگاه در دسترس نیست.")
        manager.setTorchMode(cameraId, enabled)
        return Outcome(true, if (enabled) "چراغ‌قوه روشن شد." else "چراغ‌قوه خاموش شد.")
    }

    private fun openWifiPanel(): Outcome {
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        else Intent(Settings.ACTION_WIFI_SETTINGS)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return Outcome(true, "پنل اینترنت اندروید باز می‌شود؛ تغییر اتصال را خودت انتخاب کن.", intent)
    }

    private fun openCalculator(context: Context): Outcome {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) Outcome(true, "ماشین‌حساب را باز می‌کنم.", intent)
        else Outcome(true, "ماشین‌حساب پیش‌فرض در این گوشی پیدا نشد.")
    }

    fun launch(context: Context, outcome: Outcome, launchActivity: (Intent) -> Unit): String {
        if (outcome.intent != null) launchActivity(outcome.intent)
        else Toast.makeText(context, outcome.message, Toast.LENGTH_SHORT).show()
        return outcome.message
    }

    /** Returns a non-Google speech provider installed on this device, preferring system providers. */
    @Suppress("DEPRECATION")
    fun findNonGoogleRecognitionService(context: Context): ComponentName? {
        val intent = Intent(RecognitionService.SERVICE_INTERFACE).addCategory(Intent.CATEGORY_DEFAULT)
        val services = try {
            if (Build.VERSION.SDK_INT >= 33) context.packageManager.queryIntentServices(
                intent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong())
            ) else context.packageManager.queryIntentServices(intent, PackageManager.MATCH_DEFAULT_ONLY)
        } catch (_: Exception) { emptyList() }
        val candidates = services.mapNotNull { it.serviceInfo }.filter { service ->
            service.packageName != context.packageName && service.exported &&
                service.permission == "android.permission.BIND_SPEECH_RECOGNITION_SERVICE" &&
                !service.packageName.startsWith("com.google.") &&
                !service.packageName.contains("googlequicksearchbox", ignoreCase = true)
        }
        val chosen = candidates.sortedWith(compareBy<android.content.pm.ServiceInfo> {
            val system = (it.applicationInfo.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
            when {
                system && it.packageName.contains("samsung", ignoreCase = true) -> 0
                system -> 1
                else -> 2
            }
        }.thenBy { it.packageName }).firstOrNull() ?: return null
        return ComponentName(chosen.packageName, chosen.name)
    }

    fun speechIntent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
    }
}
