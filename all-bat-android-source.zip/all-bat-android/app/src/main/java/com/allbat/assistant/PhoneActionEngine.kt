package com.allbat.assistant

import android.Manifest
import android.app.ActivityManager
import android.app.KeyguardManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.AudioManager
import android.telephony.SmsManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.hardware.camera2.CameraManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

/** Allow-listed Android device tools. The model may request only named tools; arguments are validated here. */
internal object PhoneActionEngine {
    data class Request(val kind: Kind, val target: String = "", val body: String = "", val hour: Int = -1, val minute: Int = 0)
    enum class Kind { CALL_CONTACT, SMS_CONTACT, OPEN_CAMERA, OPEN_SETTINGS, OPEN_BROWSER, OPEN_GALLERY, OPEN_CLOCK, OPEN_CALCULATOR, VOLUME_UP, VOLUME_DOWN, VOLUME_MUTE, VOLUME_UNMUTE, FLASH_ON, FLASH_OFF, WIFI_PANEL, BLUETOOTH_SETTINGS, ALARM, TIMER }
    data class Outcome(val handled: Boolean, val message: String, val intent: Intent? = null, val permission: String? = null)
    data class ToolOutcome(
        val ok: Boolean,
        val message: String,
        val data: JSONObject = JSONObject(),
        val intent: Intent? = null,
        val permissions: List<String> = emptyList()
    ) {
        fun toJson(): String = JSONObject()
            .put("ok", ok)
            .put("message", message)
            .put("data", data)
            .toString()
    }

    private val emergencyNumbers = setOf("112", "911", "999", "110", "119", "000", "118", "100")

    fun normalize(input: String): String {
        val digits = input
            .replace('۰', '0').replace('۱', '1').replace('۲', '2').replace('۳', '3').replace('۴', '4')
            .replace('۵', '5').replace('۶', '6').replace('۷', '7').replace('۸', '8').replace('۹', '9')
            .replace('٠', '0').replace('١', '1').replace('٢', '2').replace('٣', '3').replace('٤', '4')
            .replace('٥', '5').replace('٦', '6').replace('٧', '7').replace('٨', '8').replace('٩', '9')
        return Normalizer.normalize(digits, Normalizer.Form.NFKC)
            .replace('ي', 'ی').replace('ك', 'ک')
            .replace("\u200c", " ").replace("\u200f", " ").replace("\u200e", " ")
            .lowercase(Locale.ROOT)
            .replace(Regex("[،؛,:!?؟.!]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    /** Legacy parser remains for migration compatibility; the agent flow uses executeTool(). */
    fun parse(raw: String): Request? {
        val text = normalize(raw)
        if (text.isBlank()) return null
        val callWith = Regex("^(?:لطفا\\s+)?با\\s+(.+?)\\s+تماس\\s+بگیر$").matchEntire(text)
        if (callWith != null) return Request(Kind.CALL_CONTACT, target = cleanTarget(callWith.groupValues[1]))
        val phoneCall = Regex("^(?:لطفا\\s+)?(?:به\\s+)?(.+?)\\s+(?:زنگ\\s+بزن|تماس\\s+بگیر|زنگ\\s+بزنید)$").matchEntire(text)
        if (phoneCall != null) return Request(Kind.CALL_CONTACT, target = cleanTarget(phoneCall.groupValues[1]))
        val sms = Regex("^(?:لطفا\\s+)?به\\s+(.+?)\\s+پیام(?:ک)?\\s+بده(?:\\s+(?:که\\s+)?(.+))?$").matchEntire(text)
        if (sms != null) return Request(Kind.SMS_CONTACT, target = cleanTarget(sms.groupValues[1]), body = sms.groupValues.getOrElse(2) { "" }.trim())
        return null
    }

    private fun cleanTarget(value: String): String = value
        .removePrefix("آقای ").removePrefix("اقای ").removePrefix("خانم ")
        .removeSuffix(" عزیز").trim()

    /** Harmless tools that may run while the phone is locked; everything else needs the lock screen opened first. */
    private val safeWhenLocked = setOf(
        "set_flashlight", "set_volume", "media_control", "set_timer", "set_alarm",
        "get_datetime", "device_status", "battery_analysis", "set_ringer_mode", "find_phone"
    )

    private fun isPhoneLocked(context: Context): Boolean = try {
        (context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
    } catch (_: Exception) { false }

    fun executeTool(context: Context, name: String, argsJson: String): ToolOutcome {
        val args = try { JSONObject(argsJson.ifBlank { "{}" }) } catch (_: Exception) {
            return ToolOutcome(false, "ساختار آرگومان ابزار معتبر نیست.")
        }
        if (name !in safeWhenLocked && isPhoneLocked(context)) {
            return ToolOutcome(false, "گوشی قفل است؛ برای این کار اول قفل صفحه را باز کن. روی صفحهٔ قفل فقط کارهای کم‌خطر مثل چراغ‌قوه، صدا، تایمر، آلارم، ساعت، باتری، حالت زنگ و پیدا کردن گوشی مجازند.",
                JSONObject().put("action", "device_locked"))
        }
        return try {
            when (name) {
                "call_contact" -> callContactTool(context, args.optString("name").trim(), args.optInt("choice", 0))
                "open_app" -> openAppTool(context, args.optString("app_name").trim())
                "set_volume" -> setVolumeTool(context, args.optString("action").trim().lowercase(Locale.ROOT), args.optInt("steps", 1))
                "set_flashlight" -> if (args.has("enabled") && !args.isNull("enabled")) flashlightTool(context, args.optBoolean("enabled"))
                    else ToolOutcome(false, "برای چراغ‌قوه باید enabled مشخص شود.")
                "set_connection" -> if (args.has("type") && args.has("enabled") && !args.isNull("enabled"))
                    connectionTool(context, args.optString("type").trim().lowercase(Locale.ROOT), args.optBoolean("enabled"))
                    else ToolOutcome(false, "نوع اتصال و وضعیت درخواستی مشخص نشده است.")
                "set_alarm" -> if (args.has("hour") && args.has("minute"))
                    alarmTool(args.optInt("hour", -1), args.optInt("minute", -1), args.optString("label", "All Bat"))
                    else ToolOutcome(false, "ساعت و دقیقهٔ زنگ هشدار باید مشخص شوند.")
                "set_timer" -> if (args.has("seconds")) timerTool(args.optInt("seconds", 0), args.optString("label", "All Bat"))
                    else ToolOutcome(false, "مدت تایمر باید مشخص شود.")
                "open_settings" -> settingsTool(context, args.optString("section", "main"))
                "navigate_to" -> DeviceExtras.navigate(context, args.optString("destination").trim())
                "web_search" -> DeviceExtras.webSearch(context, args.optString("query").trim(), args.optString("url").trim())
                "share_text" -> DeviceExtras.shareText(context, args.optString("text").trim())
                "media_control" -> DeviceExtras.media(context, args.optString("action").trim().lowercase(Locale.ROOT))
                "set_ringer_mode" -> DeviceExtras.ringer(context, args.optString("mode").trim().lowercase(Locale.ROOT))
                "device_status" -> DeviceExtras.deviceStatus(context)
                "battery_analysis" -> DeviceExtras.batteryAnalysis(context)
                "read_screen_text" -> DeviceExtras.readScreenText(context)
                "ocr_image" -> DeviceExtras.ocrImageRequest()
                "set_display_settings" -> DeviceExtras.setDisplaySettings(context, args)
                "set_do_not_disturb" -> DeviceExtras.setDoNotDisturb(context, args.optString("mode").trim().lowercase(Locale.ROOT))
                "get_datetime" -> DeviceExtras.dateTime()
                "create_calendar_event" -> DeviceExtras.calendarEvent(args)
                "list_calendar_events" -> DeviceExtras.listCalendarEvents(context, args)
                "save_note" -> LocalNotesStore.save(context, args.optString("title"), args.optString("content"))
                "list_notes" -> LocalNotesStore.list(context, args.optInt("count", 10))
                "search_notes" -> LocalNotesStore.search(context, args.optString("query"), args.optInt("count", 5))
                "open_document" -> DeviceExtras.documentPickerRequest(false, args)
                "share_document" -> DeviceExtras.documentPickerRequest(true, args)
                "add_contact" -> DeviceExtras.addContact(args.optString("name").trim(), args.optString("phone").trim())
                "find_phone" -> DeviceExtras.findPhone(context, args.optString("action", "start").trim().lowercase(Locale.ROOT))
                "read_sms" -> DeviceExtras.readSms(context, args.optInt("count", 1))
                "screen_control" -> DeviceExtras.screenControl(context, args)
                "read_notifications" -> DeviceExtras.readNotifications(context, args.optInt("count", 5))
                "close_app" -> closeAppTool(context, args.optString("app_name").trim(), args.optBoolean("all", false))
                "install_offline_speech" -> installOfflineSpeechTool(context, args.optString("component", "recognition").trim().lowercase(Locale.ROOT))
                "create_sms_draft" -> smsDraftTool(context, args.optString("name").trim(), args.optString("message").trim(), args.optInt("choice", 0))
                else -> ToolOutcome(false, "این ابزار در فهرست مجاز All Bat وجود ندارد.")
            }
        } catch (e: SecurityException) {
            ToolOutcome(false, "اندروید مجوز لازم را نداد. مجوز سیستم باید تأیید شود.")
        } catch (e: Exception) {
            ToolOutcome(false, "اجرای ابزار ناموفق بود: ${e.javaClass.simpleName}")
        }
    }

    fun requiredPermission(request: Request): String? = when (request.kind) {
        Kind.CALL_CONTACT, Kind.SMS_CONTACT -> Manifest.permission.READ_CONTACTS
        Kind.FLASH_ON, Kind.FLASH_OFF -> Manifest.permission.CAMERA
        else -> null
    }

    fun execute(context: Context, request: Request): Outcome {
        return when (request.kind) {
            Kind.CALL_CONTACT -> {
                val result = callContactTool(context, request.target)
                Outcome(true, result.message, result.intent, result.permissions.firstOrNull())
            }
            Kind.SMS_CONTACT -> {
                val result = smsDraftTool(context, request.target, request.body)
                Outcome(true, result.message, result.intent, result.permissions.firstOrNull())
            }
            Kind.OPEN_CAMERA -> Outcome(true, "دوربین را باز می‌کنم.", Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Kind.OPEN_SETTINGS -> Outcome(true, "تنظیمات گوشی را باز می‌کنم.", Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Kind.OPEN_BROWSER -> Outcome(true, "مرورگر را باز می‌کنم.", Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Kind.OPEN_GALLERY -> Outcome(true, "گالری را باز می‌کنم.", Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Kind.OPEN_CLOCK -> Outcome(true, "برنامهٔ ساعت را باز می‌کنم.", Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Kind.OPEN_CALCULATOR -> Outcome(true, "ماشین‌حساب را باز می‌کنم.", Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Kind.VOLUME_UP -> legacyVolume(context, "up")
            Kind.VOLUME_DOWN -> legacyVolume(context, "down")
            Kind.VOLUME_MUTE -> legacyVolume(context, "mute")
            Kind.VOLUME_UNMUTE -> legacyVolume(context, "unmute")
            Kind.FLASH_ON -> Outcome(true, "چراغ‌قوه را روشن می‌کنم.")
            Kind.FLASH_OFF -> Outcome(true, "چراغ‌قوه را خاموش می‌کنم.")
            Kind.WIFI_PANEL -> Outcome(true, "پنل اینترنت اندروید را باز می‌کنم.", wifiPanelIntent())
            Kind.BLUETOOTH_SETTINGS -> Outcome(true, "تنظیمات بلوتوث را باز می‌کنم.", Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Kind.ALARM -> Outcome(true, "صفحهٔ تنظیم زنگ هشدار را باز می‌کنم.", Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, request.hour).putExtra(AlarmClock.EXTRA_MINUTES, request.minute).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Kind.TIMER -> Outcome(true, "تایمر را در برنامهٔ ساعت باز می‌کنم.", Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, request.minute * 60).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    // Resolve the contact before asking for the ability to place calls. This avoids
    // requesting CALL_PHONE when the name is missing or the user still needs to choose.
    private fun requiredContactPermissions(): List<String> = listOf(Manifest.permission.READ_CONTACTS)

    private fun missingPermissions(context: Context, permissions: List<String>): List<String> = permissions.filter {
        context.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
    }

    /** Builds the "which contact?" outcome. The host shows a picker or the model asks the user by number. */
    private fun contactChoiceRequired(tool: String, query: String, matches: List<Pair<String, String>>): ToolOutcome {
        val shown = matches.take(8)
        val choices = JSONArray()
        val lines = StringBuilder()
        shown.forEachIndexed { i, (display, number) ->
            val hint = maskNumber(number)
            choices.put(JSONObject().put("index", i + 1).put("name", display).put("hint", hint))
            lines.append("${i + 1}) $display ($hint)  ")
        }
        val message = "چند مخاطب مطابق «$query» پیدا شد: ${lines.toString().trim()}. " +
            "از کاربر بپرس کدام را می‌خواهد (مثلاً «${query} ۱ یا ${query} ۲؟») و بعد همین ابزار را با choice برابر شمارهٔ انتخابی دوباره صدا بزن. حدس نزن."
        return ToolOutcome(false, message, JSONObject()
            .put("action", "contact_choice_required")
            .put("tool", tool)
            .put("choices", choices))
    }

    private fun pickContact(tool: String, query: String, matches: List<Pair<String, String>>, choice: Int): Pair<Pair<String, String>?, ToolOutcome?> {
        if (matches.size == 1) return matches.first() to null
        if (choice in 1..minOf(matches.size, 8)) return matches[choice - 1] to null
        if (choice != 0) return null to ToolOutcome(false, "شمارهٔ انتخابی معتبر نیست؛ بین ۱ تا ${minOf(matches.size, 8)} انتخاب کن.")
        return null to contactChoiceRequired(tool, query, matches)
    }

    private fun callContactTool(context: Context, name: String, choice: Int = 0): ToolOutcome {
        if (name.isBlank() || name.length > 100) return ToolOutcome(false, "نام مخاطب خالی یا بیش از حد طولانی است.")
        val missing = missingPermissions(context, requiredContactPermissions())
        if (missing.isNotEmpty()) return ToolOutcome(false, "برای پیدا کردن مخاطب، مجوز دسترسی به مخاطبین را تأیید کن.", permissions = missing)
        val matches = findContactNumbers(context, name)
        if (matches.isEmpty()) return ToolOutcome(false, "مخاطبی با نام «$name» پیدا نشد.")
        val (picked, needChoice) = pickContact("call_contact", name, matches, choice)
        if (needChoice != null) return needChoice
        val (matchedName, number) = picked!!
        // CALL_PHONE is requested only after the contact has been resolved and, when needed,
        // the user has explicitly selected one of the numbered matches.
        val callPermissionMissing = missingPermissions(context, listOf(Manifest.permission.CALL_PHONE))
        if (callPermissionMissing.isNotEmpty()) {
            return ToolOutcome(false, "مخاطب $matchedName مشخص شد؛ برای برقراری تماس مستقیم، مجوز تماس تلفنی را تأیید کن.",
                JSONObject().put("contact", matchedName), permissions = callPermissionMissing)
        }
        val digits = number.filter { it.isDigit() }
        if (digits in emergencyNumbers) return ToolOutcome(false, "برای جلوگیری از تماس ناخواسته با شمارهٔ اضطراری، این شماره به‌صورت خودکار گرفته نمی‌شود.")
        val intent = Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return ToolOutcome(true, "تماس با $matchedName شروع شد.", JSONObject().put("contact", matchedName), intent)
    }

    private fun smsDraftTool(context: Context, name: String, message: String, choice: Int = 0): ToolOutcome {
        if (name.isBlank() || message.isBlank()) return ToolOutcome(false, "نام مخاطب و متن پیام لازم است.")
        if (message.length > 2000) return ToolOutcome(false, "متن پیام بیش از حد طولانی است.")
        val missing = missingPermissions(context, listOf(Manifest.permission.READ_CONTACTS))
        if (missing.isNotEmpty()) return ToolOutcome(false, "برای پیدا کردن مخاطب، مجوز مخاطبین لازم است.", permissions = missing)
        val matches = findContactNumbers(context, name)
        if (matches.isEmpty()) return ToolOutcome(false, "مخاطبی با این نام پیدا نشد.")
        val (picked, needChoice) = pickContact("create_sms_draft", name, matches, choice)
        if (needChoice != null) return needChoice
        val (matchedName, number) = picked!!
        // No messaging app is launched here. The host displays an editable native preview;
        // only its explicit Send button can pass this payload to sendConfirmedSms().
        val data = JSONObject()
            .put("action", "sms_confirmation_required")
            .put("contact_name", matchedName)
            .put("number", number)
            .put("message", message)
        return ToolOutcome(true, "پیش‌نمایش پیام آماده است؛ منتظر تأیید کاربر هستم.", data)
    }

    /** Internal only: called after the user has tapped Send in SmsPreviewView. */
    fun sendConfirmedSms(context: Context, number: String, message: String, contactName: String): ToolOutcome {
        val cleanNumber = number.trim()
        val cleanMessage = message.trim()
        if (cleanNumber.isBlank() || cleanNumber.length > 40 || cleanNumber.any { !(it.isDigit() || it in "+*#(). -") }) {
            return ToolOutcome(false, "شمارهٔ مقصد معتبر نیست.")
        }
        if (cleanMessage.isBlank() || cleanMessage.length > 2000) {
            return ToolOutcome(false, "متن پیام خالی یا بیش از حد طولانی است.")
        }
        if (context.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return ToolOutcome(false, "برای ارسال پیامک، مجوز SMS لازم است.", permissions = listOf(Manifest.permission.SEND_SMS))
        }
        return try {
            @Suppress("DEPRECATION")
            val manager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java) ?: SmsManager.getDefault()
            } else SmsManager.getDefault()
            val parts = manager.divideMessage(cleanMessage)
            if (parts.size > 1) {
                manager.sendMultipartTextMessage(cleanNumber, null, parts, null, null)
            } else {
                manager.sendTextMessage(cleanNumber, null, cleanMessage, null, null)
            }
            ToolOutcome(true, "پیامک برای $contactName به سرویس پیامک اندروید تحویل داده شد.",
                JSONObject().put("contact_name", contactName).put("submitted", true))
        } catch (e: SecurityException) {
            ToolOutcome(false, "مجوز ارسال پیامک در اندروید پذیرفته نشد.")
        } catch (e: Exception) {
            ToolOutcome(false, "ارسال پیامک انجام نشد: ${e.javaClass.simpleName}")
        }
    }

    // Common Persian names and family-name forms are indexed in both scripts. This is a
    // local-only lookup aid: contact names and phone numbers are never sent to the model.
    private val contactNameAliasGroups: List<Set<String>> = listOf(
        setOf("علی", "ali", "aali", "aly"),
        setOf("محمد", "mohammad", "mohamad", "muhammad", "mohamed", "mohammed"),
        setOf("محمدی", "mohammadi", "mohamadi", "muhammadi", "mohamady"),
        setOf("رضا", "reza", "rida"),
        setOf("رضایی", "rezaei", "rezaee", "rezayi"),
        setOf("حسین", "hossein", "hosein", "hussein", "hussain", "husain", "hosayn"),
        setOf("حسینی", "hoseini", "hosseini", "husseini", "hussaini", "husaini"),
        setOf("حسن", "hasan", "hassan"),
        setOf("فاطمه", "fatemeh", "fatima", "fatma"),
        setOf("زهرا", "zahra", "zahraa"),
        setOf("مریم", "maryam", "mariam"),
        setOf("امیر", "amir", "ameer"),
        setOf("امیری", "amiri"),
        setOf("احمد", "ahmad", "ahmed"),
        setOf("احمدی", "ahmadi", "ahmedy"),
        setOf("مهدی", "mehdi", "mahdi"),
        setOf("مهدوی", "mahdavi", "mahdavy"),
        setOf("سارا", "sara", "sarah"),
        setOf("نرگس", "narges", "nargis"),
        setOf("نازنین", "nazanin", "nazneen"),
        setOf("امین", "amin", "ameen"),
        setOf("جواد", "javad", "jawad"),
        setOf("جعفری", "jafari", "jaafari"),
        setOf("موسوی", "mousavi", "musavi", "moosavi"),
        setOf("کریمی", "karimi"),
        setOf("اکبری", "akbari"),
        setOf("رحیمی", "rahimi"),
        setOf("قاسمی", "ghasemi", "qasemi")
    )
    private val contactNameAliasIndex: Map<String, Set<String>> = buildMap {
        contactNameAliasGroups.forEach { group -> group.forEach { alias -> put(alias, group) } }
    }

    private fun persianToLatinContactKey(value: String): String = buildString {
        value.forEach { ch ->
            append(when (ch) {
                'ا', 'آ', 'ع' -> "a"
                'ب' -> "b"
                'پ' -> "p"
                'ت', 'ط' -> "t"
                'ث', 'س', 'ص' -> "s"
                'ج' -> "j"
                'چ' -> "ch"
                'ح', 'ه' -> "h"
                'خ' -> "kh"
                'د' -> "d"
                'ذ', 'ز', 'ض', 'ظ' -> "z"
                'ر' -> "r"
                'ژ' -> "zh"
                'ش' -> "sh"
                'غ', 'ق' -> "gh"
                'ف' -> "f"
                'ک', 'ك' -> "k"
                'گ' -> "g"
                'ل' -> "l"
                'م' -> "m"
                'ن' -> "n"
                'و' -> "v"
                'ی', 'ي', 'ئ' -> "i"
                'ء', 'ٔ', 'ً', 'ٌ', 'ٍ', 'َ', 'ُ', 'ِ', 'ّ', 'ْ', 'ـ' -> ""
                else -> if (ch.isLetterOrDigit() && ch.code < 128) ch.toString() else " "
            })
        }
    }.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), " ").trim()

    private fun contactTokenAliases(raw: String): Set<String> {
        val token = normalize(raw).replace(Regex("""[^\p{L}\p{N}]"""), "").trim()
        if (token.isBlank()) return emptySet()
        val aliases = linkedSetOf(token)
        aliases.addAll(contactNameAliasIndex[token].orEmpty())
        val latinized = persianToLatinContactKey(token).replace(" ", "")
        if (latinized.isNotBlank()) aliases.add(latinized)
        // Normalize common Latin spelling differences without making very short names fuzzy.
        if (token.any { it.code < 128 }) {
            aliases.add(token.replace("ph", "f").replace("ou", "u").replace("oo", "u"))
        }
        return aliases.filterTo(linkedSetOf()) { it.length >= 2 }
    }

    private fun contactSearchVariants(query: String): List<String> {
        val normalized = normalize(query)
        val tokens = normalized.split(' ').filter { it.isNotBlank() }
        if (tokens.isEmpty()) return emptyList()
        var combinations = listOf("")
        for (token in tokens) {
            val variants = contactTokenAliases(token).take(6).ifEmpty { listOf(token) }
            val next = ArrayList<String>(minOf(24, combinations.size * variants.size))
            loop@ for (prefix in combinations) {
                for (variant in variants) {
                    next.add(if (prefix.isBlank()) variant else "$prefix $variant")
                    if (next.size >= 24) break@loop
                }
            }
            combinations = next
        }
        return (listOf(normalized) + combinations).distinct().take(24)
    }

    private fun contactTokensEquivalent(left: String, right: String): Boolean {
        val a = normalize(left).replace(Regex("""[^\p{L}\p{N}]"""), "")
        val b = normalize(right).replace(Regex("""[^\p{L}\p{N}]"""), "")
        if (a.isBlank() || b.isBlank()) return false
        if (a == b) return true
        if (contactTokenAliases(a).intersect(contactTokenAliases(b)).isNotEmpty()) return true
        return (a.length >= 4 && b.startsWith(a)) || (b.length >= 4 && a.startsWith(b))
    }

    private fun contactNameMatches(displayName: String, query: String): Boolean {
        val wanted = normalize(query).split(' ').filter { it.isNotBlank() }
        val actual = normalize(displayName).split(Regex("""[\s,._-]+""")).filter { it.isNotBlank() }
        if (wanted.isEmpty() || actual.isEmpty()) return false
        // Every part spoken by the user must match a name token; order may differ in saved contacts.
        return wanted.all { part -> actual.any { token -> contactTokensEquivalent(part, token) } }
    }

    private fun findContactNumbers(context: Context, query: String): List<Pair<String, String>> {
        val results = LinkedHashMap<String, Pair<String, String>>()
        // Search the original Persian/Latin spelling plus bounded transliteration variants.
        // CONTENT_FILTER_URI keeps this efficient and avoids enumerating the full address book.
        val searchVariants = contactSearchVariants(query)
        for ((variantIndex, searchTerm) in searchVariants.withIndex()) {
            var cursor: Cursor? = null
            try {
                val uri = Uri.withAppendedPath(ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(searchTerm))
                cursor = context.contentResolver.query(uri,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                    null, null, null)
                while (cursor?.moveToNext() == true) {
                    val display = cursor.getString(0).orEmpty().trim()
                    val number = cursor.getString(1).orEmpty().trim()
                    if (display.isBlank() || number.isBlank() || !contactNameMatches(display, query)) continue
                    val key = normalize(display) + "|" + number.filter { it.isDigit() }
                    results[key] = display to number
                }
            } catch (_: Exception) {
                // Some OEM providers reject individual transliteration variants; keep trying the others.
            } finally {
                cursor?.close()
            }
            // Preserve the requested fast path: transliteration is attempted only when the
            // original-script search found no contact.
            if (variantIndex == 0 && results.isNotEmpty()) break
        }
        return results.values.toList()
            .distinctBy { it.second.filter { ch -> ch.isDigit() } }
            // Stable order: the same numbering must be produced when the tool is called again with `choice`.
            .sortedWith(compareBy({ normalize(it.first) }, { it.second.filter { ch -> ch.isDigit() } }))
    }

    private fun maskNumber(number: String): String {
        val digits = number.filter { it.isDigit() }
        return if (digits.length <= 4) "••••" else "••••" + digits.takeLast(4)
    }

    private fun openAppTool(context: Context, requested: String): ToolOutcome {
        if (requested.isBlank() || requested.length > 100) return ToolOutcome(false, "نام برنامه خالی یا نامعتبر است.")
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val activities = try {
            queryLaunchableActivities(context, query)
        } catch (_: Exception) { emptyList() }
        val target = normalize(requested)
        val apps = activities.mapNotNull { info ->
            val label = info.loadLabel(context.packageManager)?.toString()?.trim().orEmpty()
            val pkg = info.activityInfo?.packageName.orEmpty()
            val cls = info.activityInfo?.name.orEmpty()
            if (label.isBlank() || pkg.isBlank() || cls.isBlank()) null else Triple(label, pkg, cls)
        }.distinctBy { it.second }
        val exact = apps.filter { normalize(it.first) == target || normalize(it.second) == target }
        val matched = if (exact.isNotEmpty()) exact else apps.filter {
            normalize(it.first).contains(target) || target.contains(normalize(it.first)) ||
                normalize(it.second).contains(target) || target.contains(normalize(it.second))
        }
        if (matched.isEmpty()) return ToolOutcome(false, "برنامه‌ای با نام «$requested» در فهرست برنامه‌های قابل اجرا پیدا نشد.")
        if (matched.size > 1) {
            val choices = JSONArray(); matched.take(8).forEach { choices.put(it.first) }
            return ToolOutcome(false, "چند برنامه با این نام وجود دارد؛ نام دقیق‌تر را بگو.", JSONObject().put("matches", choices))
        }
        val (label, pkg, cls) = matched.first()
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(pkg, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return ToolOutcome(true, "برنامهٔ $label را باز می‌کنم.", JSONObject().put("app", label).put("package", pkg), launch)
    }

    @Suppress("DEPRECATION")
    private fun queryLaunchableActivities(context: Context, query: Intent): List<android.content.pm.ResolveInfo> =
        if (Build.VERSION.SDK_INT >= 33) context.packageManager.queryIntentActivities(
            query, PackageManager.ResolveInfoFlags.of(0L)
        ) else context.packageManager.queryIntentActivities(query, 0)

    private fun setVolumeTool(context: Context, action: String, requestedSteps: Int): ToolOutcome {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val steps = requestedSteps.coerceIn(1, 10)
        val direction = when (action) { "up", "increase", "زیاد", "زیادتر" -> AudioManager.ADJUST_RAISE
            "down", "decrease", "کم", "کمتر" -> AudioManager.ADJUST_LOWER
            "mute", "silent" -> AudioManager.ADJUST_MUTE
            "unmute", "sound" -> AudioManager.ADJUST_UNMUTE
            else -> return ToolOutcome(false, "عملیات صدا باید up، down، mute یا unmute باشد.") }
        repeat(if (action == "mute" || action == "unmute" || action == "silent" || action == "sound") 1 else steps) {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        }
        return ToolOutcome(true, "تنظیم صدای رسانه انجام شد.", JSONObject().put("action", action).put("steps", steps))
    }

    private fun flashlightTool(context: Context, enabled: Boolean): ToolOutcome {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val ids = manager.cameraIdList.filter { id ->
            try {
                manager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } catch (_: Exception) { false }
        }
        if (ids.isEmpty()) return ToolOutcome(false, "چراغ‌قوه در این دستگاه در دسترس نیست.")
        var changed = false
        for (id in ids) {
            try {
                manager.setTorchMode(id, enabled)
                changed = true
                if (enabled) break
            } catch (_: SecurityException) {
                return ToolOutcome(false, "برای کنترل چراغ‌قوه، مجوز دوربین لازم است.", permissions = listOf(Manifest.permission.CAMERA))
            } catch (_: Exception) {
                // Try the next flash unit; turning OFF is attempted on every unit.
            }
        }
        if (!changed) return ToolOutcome(false, "چراغ‌قوه در دسترس نیست؛ احتمالاً دوربین در حال استفاده است.")
        return ToolOutcome(true, if (enabled) "چراغ‌قوه روشن شد." else "چراغ‌قوه خاموش شد.", JSONObject().put("enabled", enabled))
    }

    private fun isClosableUserApp(pm: PackageManager, pkg: String): Boolean = try {
        val flags = pm.getApplicationInfo(pkg, 0).flags
        val system = (flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
        val updatedSystem = (flags and android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        !system || updatedSystem
    } catch (_: Exception) { false }

    /**
     * Android does not let third-party apps force-stop other apps. This ends the target's background
     * processes (KILL_BACKGROUND_PROCESSES). When the assistant is drawn over the target app (non-Activity
     * context), the user is first sent to the home screen so the target is no longer in the foreground.
     */
    private fun closeAppTool(context: Context, requested: String, all: Boolean): ToolOutcome {
        if (!all && (requested.isBlank() || requested.length > 100)) return ToolOutcome(false, "نام برنامه برای بستن مشخص نیست.")
        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val activities = try { queryLaunchableActivities(context, query) } catch (_: Exception) { emptyList() }
        val apps = activities.mapNotNull { info ->
            val label = info.loadLabel(pm)?.toString()?.trim().orEmpty()
            val pkg = info.activityInfo?.packageName.orEmpty()
            if (label.isBlank() || pkg.isBlank() || pkg == context.packageName) null else label to pkg
        }.distinctBy { it.second }
        val targets: List<Pair<String, String>>
        if (all) {
            targets = apps.filter { isClosableUserApp(pm, it.second) }.take(80)
            if (targets.isEmpty()) return ToolOutcome(false, "برنامهٔ کاربریِ قابل بستن پیدا نشد.")
        } else {
            val target = normalize(requested)
            val exact = apps.filter { normalize(it.first) == target || normalize(it.second) == target }
            val matched = if (exact.isNotEmpty()) exact else apps.filter {
                normalize(it.first).contains(target) || target.contains(normalize(it.first)) ||
                    normalize(it.second).contains(target) || target.contains(normalize(it.second))
            }
            if (matched.isEmpty()) return ToolOutcome(false, "برنامه‌ای با نام «$requested» پیدا نشد.")
            if (matched.size > 1) {
                val choices = JSONArray(); matched.take(8).forEach { choices.put(it.first) }
                return ToolOutcome(false, "چند برنامه با این نام وجود دارد؛ نام دقیق‌تر را بگو.", JSONObject().put("matches", choices))
            }
            if (!isClosableUserApp(pm, matched.first().second)) {
                return ToolOutcome(false, "«${matched.first().first}» برنامهٔ سیستمی است و بستنش از طریق دستیار مجاز نیست.")
            }
            targets = matched
        }
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val killAll = { targets.forEach { try { manager.killBackgroundProcesses(it.second) } catch (_: Exception) { } } }
        val goHome = context !is android.app.Activity
        if (goHome) {
            try {
                context.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) { }
            Handler(Looper.getMainLooper()).postDelayed({ killAll() }, 1100L)
        }
        killAll()
        val message = if (all) "پردازش‌های پس‌زمینهٔ ${targets.size} برنامه بسته شد."
            else "برنامهٔ ${targets.first().first} بسته شد. اندروید اجازهٔ توقف اجباری کامل را به برنامه‌های دیگر نمی‌دهد؛ اگر برنامه خودش دوباره اجرا شد، از «اطلاعات برنامه ← توقف اجباری» استفاده کن."
        return ToolOutcome(true, message, JSONObject().put("closed", JSONArray(targets.map { it.first })).put("went_home", goHome))
    }

    private fun installOfflineSpeechTool(context: Context, component: String): ToolOutcome {
        return when (component) {
            "voice", "tts" -> {
                val intent = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ToolOutcome(true, "صفحهٔ نصب داده‌های صوتی (خروجی گفتار آفلاین) اندروید باز شد؛ صدای فارسی را از آن‌جا دانلود کن.", JSONObject().put("component", "voice"), intent)
            }
            "recognition", "stt", "" -> {
                val message = OfflineSpeechModel.startInstall(context)
                ToolOutcome(!message.contains("باید") && !message.contains("کافی نیست"), message,
                    JSONObject().put("component", "recognition").put("installed", OfflineSpeechModel.isInstalled(context)).put("installing", OfflineSpeechModel.isInstalling()))
            }
            else -> ToolOutcome(false, "component باید recognition یا voice باشد.")
        }
    }

    private fun connectionTool(context: Context, type: String, enabled: Boolean): ToolOutcome {
        if ((type == "bluetooth" || type == "bt") && enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val missing = missingPermissions(context, listOf(Manifest.permission.BLUETOOTH_CONNECT))
            if (missing.isNotEmpty()) return ToolOutcome(false, "برای ارسال درخواست روشن‌کردن بلوتوث، مجوز دستگاه‌های نزدیک لازم است.", permissions = missing)
        }
        val intent = when (type) {
            "wifi", "wi-fi", "internet" -> wifiPanelIntent()
            "mobile_data", "mobile-data", "data" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                wifiPanelIntent() else Intent(Settings.ACTION_DATA_USAGE_SETTINGS)
            "bluetooth", "bt" -> if (enabled) Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE) else Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            else -> return ToolOutcome(false, "نوع اتصال باید wifi، bluetooth یا mobile_data باشد.")
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val message = when (type) {
            "wifi", "wi-fi", "internet" -> "پنل اینترنت اندروید باز شد؛ تغییر Wi-Fi باید در خود سیستم تأیید شود."
            "bluetooth", "bt" -> if (enabled) "درخواست روشن‌کردن بلوتوث را به پنجرهٔ سیستمی اندروید می‌فرستم." else "تنظیمات بلوتوث باز شد؛ خاموش‌کردن را در خود سیستم انجام بده."
            else -> "پنل اتصال اینترنت اندروید باز شد؛ تغییر اینترنت همراه را در صورت نمایش گزینه، در خود سیستم تأیید کن."
        }
        return ToolOutcome(true, message, JSONObject()
            .put("type", type)
            .put("requested_enabled", enabled)
            .put("system_confirmation_required", true)
            .put("change_confirmed", false), intent)
    }

    private fun wifiPanelIntent(): Intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
        Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    else Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    private fun alarmTool(hour: Int, minute: Int, label: String): ToolOutcome {
        if (hour !in 0..23 || minute !in 0..59) return ToolOutcome(false, "زمان زنگ هشدار معتبر نیست.")
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute).putExtra(AlarmClock.EXTRA_MESSAGE, label.take(80))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return ToolOutcome(true, "درخواست ثبت زنگ هشدار برای ساعت ${"%02d:%02d".format(hour, minute)} به برنامهٔ ساعت ارسال شد.", intent = intent)
    }

    private fun timerTool(seconds: Int, label: String): ToolOutcome {
        if (seconds !in 1..86400) return ToolOutcome(false, "مدت تایمر باید بین ۱ ثانیه تا ۲۴ ساعت باشد.")
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label.take(80)).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return ToolOutcome(true, "درخواست شروع تایمر ${seconds} ثانیه‌ای به برنامهٔ ساعت ارسال شد.", intent = intent)
    }

    private fun settingsTool(context: Context, section: String): ToolOutcome {
        val key = normalize(section).replace(' ', '_')
        if (key in setOf("assistant", "power_button", "دستیار", "دکمه_پاور")) {
            val intent = Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return ToolOutcome(true,
                "صفحهٔ انتخاب دستیار باز می‌شود؛ All Bat را به‌عنوان دستیار دیجیتال انتخاب کن. سپس تنظیم نگه‌داشتن دکمهٔ پاور/کلید کناری را روی دستیار قرار بده.",
                intent = intent)
        }

        val candidates = when (key) {
            "wifi", "wi_fi", "wi-fi", "internet", "network", "وای_فای", "اینترنت", "شبکه" -> listOf(wifiPanelIntent())
            "bluetooth", "بلوتوث" -> listOf(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            "sound", "audio", "volume", "صدا", "صوت" -> listOf(Intent(Settings.ACTION_SOUND_SETTINGS))
            "apps", "app", "applications", "برنامه_ها", "اپلیکیشن_ها", "اپ_ها" -> listOf(Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS), Intent(Settings.ACTION_APPLICATION_SETTINGS))
            "display", "screen", "نمایشگر", "صفحه_نمایش", "صفحه" -> listOf(Intent(Settings.ACTION_DISPLAY_SETTINGS))
            "battery", "power", "battery_saver", "باتری", "شارژ", "مصرف_باتری" -> listOf(Intent(Intent.ACTION_POWER_USAGE_SUMMARY), Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
            "storage", "memory", "حافظه", "حافظه_داخلی", "فضای_ذخیره_سازی", "فضای_ذخیره" -> listOf(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
            "location", "gps", "مکان", "موقعیت", "موقعیت_مکانی" -> listOf(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            "notifications", "notification", "اعلان_ها", "اعلان", "نوتیفیکیشن" -> listOf(Intent(Settings.ACTION_ALL_APPS_NOTIFICATION_SETTINGS))
            "security", "امنیت", "قفل_صفحه" -> listOf(Intent(Settings.ACTION_SECURITY_SETTINGS))
            "privacy", "حریم_خصوصی", "حریم_شخصی" -> listOf(Intent(Settings.ACTION_PRIVACY_SETTINGS))
            "accessibility", "دسترسی_پذیری", "قابلیت_دسترس" -> listOf(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            "date", "time", "date_time", "تاریخ", "تاریخ_و_ساعت", "زمان", "ساعت" -> listOf(Intent(Settings.ACTION_DATE_SETTINGS))
            "language", "locale", "زبان", "زبان_و_ورودی" -> listOf(Intent(Settings.ACTION_LOCALE_SETTINGS))
            "keyboard", "input", "کیبورد", "صفحه_کلید", "ورودی" -> listOf(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            "default_apps", "default_app", "برنامه_های_پیش_فرض", "برنامه_پیش_فرض" -> listOf(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            "home", "launcher", "صفحه_اصلی", "لانچر" -> listOf(Intent(Settings.ACTION_HOME_SETTINGS))
            "device", "about", "device_info", "درباره_گوشی", "درباره_دستگاه", "اطلاعات_گوشی" -> listOf(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS))
            "accounts", "account", "حساب", "حساب_ها" -> listOf(Intent(Settings.ACTION_SYNC_SETTINGS))
            "main", "تنظیمات", "" -> listOf(Intent(Settings.ACTION_SETTINGS))
            else -> emptyList()
        }
        if (candidates.isEmpty()) return ToolOutcome(false, "بخش تنظیمات «$section» در فهرست پشتیبانی‌شده نیست.")

        // ACTION_* settings screens are not guaranteed to exist on every Android/OEM build.
        // Resolve before launch; if the dedicated screen is missing, safely open system Settings.
        val chosen = candidates.firstOrNull { candidate ->
            candidate.resolveActivity(context.packageManager) != null
        } ?: if (key !in setOf("main", "تنظیمات", "")) {
            Intent(Settings.ACTION_SETTINGS).takeIf { it.resolveActivity(context.packageManager) != null }
        } else null

        if (chosen == null) return ToolOutcome(false, "صفحهٔ تنظیمات در این نسخهٔ اندروید پیدا نشد.")
        val dedicated = candidates.any { it.action == chosen.action }
        val message = if (dedicated) "صفحهٔ تنظیمات ${section} باز می‌شود." else
            "صفحهٔ اختصاصی این بخش در این گوشی در دسترس نبود؛ تنظیمات اصلی گوشی باز می‌شود تا بتوانی آن را پیدا کنی."
        return ToolOutcome(true, message, intent = chosen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun legacyVolume(context: Context, action: String): Outcome {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val direction = when (action) { "up" -> AudioManager.ADJUST_RAISE; "down" -> AudioManager.ADJUST_LOWER; "mute" -> AudioManager.ADJUST_MUTE; else -> AudioManager.ADJUST_UNMUTE }
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        return Outcome(true, "تنظیم صدای رسانه انجام شد.")
    }

    /** Returns a non-Google speech provider installed on this device, preferring system providers. */
    @Suppress("DEPRECATION")
    fun findNonGoogleRecognitionService(context: Context): android.content.ComponentName? {
        val intent = Intent(android.speech.RecognitionService.SERVICE_INTERFACE).addCategory(Intent.CATEGORY_DEFAULT)
        val services = try {
            if (Build.VERSION.SDK_INT >= 33) context.packageManager.queryIntentServices(
                intent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong())
            ) else context.packageManager.queryIntentServices(intent, PackageManager.MATCH_DEFAULT_ONLY)
        } catch (_: Exception) { emptyList() }
        val candidates = services.mapNotNull { it.serviceInfo }.filter { service ->
            service.packageName != context.packageName && service.exported &&
                service.permission == "android.permission.BIND_SPEECH_RECOGNITION_SERVICE" &&
                !service.packageName.startsWith("com.google.") &&
                !service.packageName.contains("googlequicksearchbox", ignoreCase = true)
        }
        val chosen = candidates.sortedWith(compareBy<android.content.pm.ServiceInfo> {
            val system = (it.applicationInfo.flags and (android.content.pm.ApplicationInfo.FLAG_SYSTEM or android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
            when { system && it.packageName.contains("samsung", ignoreCase = true) -> 0; system -> 1; else -> 2 }
        }.thenBy { it.packageName }).firstOrNull() ?: return null
        return android.content.ComponentName(chosen.packageName, chosen.name)
    }

    fun speechIntent(): Intent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
        putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR")
        putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        // Prefer the online recognizer when a network is available; offline recognition is
        // handled by the app's local Vosk path. Shorter end-of-speech windows reduce idle delay.
        putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
        putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
        putExtra(android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 400L)
    }
}
