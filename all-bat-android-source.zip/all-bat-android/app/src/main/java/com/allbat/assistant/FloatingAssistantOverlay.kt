package com.allbat.assistant

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min

/**
 * Native live-voice surface drawn over every app, styled after the Gemini Android overlay:
 *  - a round "captions" button at the top end,
 *  - a caption above the controls (dark pill = what you said, light card = the answer),
 *  - one row of controls: camera, share screen, blue blob, microphone, close.
 *
 * All measurements come from the reference screenshots (1080 px wide, ~2.75 density) and are
 * scaled down automatically on narrow screens.
 */
internal class FloatingAssistantOverlay(
    private val service: Service,
    private val onAction: (String) -> Unit
) {
    data class State(
        val userText: String = "",
        val answerText: String = "",
        val status: String = "گفت‌وگوی زنده فعال است",
        val generating: Boolean = false,
        val micMuted: Boolean = false,
        val cameraActive: Boolean = false,
        val screenActive: Boolean = false,
        /** Kept for compatibility with SessionForegroundService; both owners use the same live UI. */
        val voiceMode: Boolean = true
    )

    companion object {
        const val ACTION_MIC = "mic"
        const val ACTION_CAMERA = "camera"
        const val ACTION_SCREEN = "screen"
        const val ACTION_END = "end"
        const val ACTION_OPEN = "open"
        const val ACTION_COLLAPSE = "collapse"
        const val ACTION_STOP_RESPONSE = "stop_response"
    }

    private val manager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = service.resources.displayMetrics.density
    private val widthDp = service.resources.displayMetrics.widthPixels / density

    /** 1.0 on a 393 dp wide phone like the reference; shrinks the whole layout on narrower screens. */
    private val scale: Float = min(1f, (widthDp - 24f) / 360f)

    private var lastState = State()
    private var controlsExpanded = true
    private var captionsOn = true

    private var topWindow: View? = null
    private var panelWindow: LinearLayout? = null
    private var captionHost: FrameLayout? = null
    private var userPill: TextView? = null
    private var answerCard: TextView? = null
    private var row: LinearLayout? = null
    private var cameraButton: FrameLayout? = null
    private var screenButton: FrameLayout? = null
    private var micButton: FrameLayout? = null
    private var micIcon: View? = null
    private var micOffIcon: View? = null
    private var closeButton: FrameLayout? = null
    private var blob: View? = null
    private var captionToggle: FrameLayout? = null
    private var breathing: ObjectAnimator? = null
    private var bubbleWindow: View? = null
    private var bubbleX = 16
    private var bubbleY = 130

    // ---- sizing helpers -------------------------------------------------------------------

    /** Plain dp. */
    private fun dp(value: Int) = (value * density).toInt()

    /** dp scaled for narrow screens. */
    private fun d(value: Float) = (value * scale * density).toInt()

    private fun statusBarHeightPx(): Int {
        val id = service.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) service.resources.getDimensionPixelSize(id) else dp(24)
    }

    private fun navBarHeightPx(): Int {
        val res = service.resources
        val modeId = res.getIdentifier("config_navBarInteractionMode", "integer", "android")
        val mode = if (modeId > 0) res.getInteger(modeId) else 0
        if (mode == 2) return dp(14) // gesture navigation: only a thin handle
        val id = res.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (id > 0) res.getDimensionPixelSize(id) else dp(48)
    }

    private fun canDraw(): Boolean =
        Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(service)

    // ---- public API (unchanged signatures) ------------------------------------------------

    fun setVoiceMode(isMainAppLive: Boolean) {
        if (lastState.voiceMode != isMainAppLive) lastState = lastState.copy(voiceMode = isMainAppLive)
    }

    fun show() {
        if (!canDraw()) return
        if (controlsExpanded) {
            removeBubble()
            if (panelWindow == null) buildPanelWindow()
            if (topWindow == null) buildTopWindow()
        } else {
            removePanelWindows()
            if (bubbleWindow == null) buildBubble()
        }
        applyState()
    }

    fun update(newState: State) {
        lastState = newState
        if (!canDraw()) { removeAll(); return }
        val missing = if (controlsExpanded) (panelWindow == null || topWindow == null) else bubbleWindow == null
        if (missing) show() else applyState()
    }

    /** Orb tapped: switch between the full live controls and the small draggable floating orb. */
    fun toggleExpanded() {
        controlsExpanded = !controlsExpanded
        show()
    }

    fun collapse() {
        controlsExpanded = false
        show()
    }

    fun hide() = removeAll()

    fun destroy() = removeAll()

    // ---- drawables ------------------------------------------------------------------------

    private fun rounded(color: Int, radiusDp: Float) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = d(radiusDp).toFloat()
        setColor(color)
    }

    /** Soft white-to-lavender disc used by every round control in the reference. */
    private fun discBackground(top: Int, bottom: Int) = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)
    ).apply { shape = GradientDrawable.OVAL }

    private fun idleDisc() = discBackground(Color.rgb(252, 251, 255), Color.rgb(238, 235, 250))
    private fun activeDisc() = discBackground(Color.rgb(214, 228, 255), Color.rgb(176, 203, 255))
    private fun mutedDisc() = discBackground(Color.rgb(228, 226, 234), Color.rgb(214, 211, 224))

    /** The blue "orb": white at the top, deepening to blue at the bottom, like the reference. */
    private fun blobBackground() = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(
            Color.rgb(255, 255, 255),
            Color.rgb(246, 244, 255),
            Color.rgb(222, 232, 255),
            Color.rgb(132, 178, 255),
            Color.rgb(62, 125, 250)
        )
    ).apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(120).toFloat()
    }

    // ---- window construction --------------------------------------------------------------

    private fun overlayParams(width: Int, height: Int, title: String) = WindowManager.LayoutParams(
        width, height,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { this.title = title }

    private fun buildTopWindow() {
        val button = circleButton("captions", "نمایش یا پنهان‌کردن زیرنویس", d(49f)) {
            captionsOn = !captionsOn
            applyState()
        }
        captionToggle = button
        val params = overlayParams(d(49f), d(49f), "Digi captions toggle").apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(22)
            y = statusBarHeightPx() + dp(3)
        }
        try { manager.addView(button, params); topWindow = button } catch (_: Exception) { topWindow = null }
    }

    private fun buildPanelWindow() {
        val root = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
            setPadding(dp(16), 0, dp(16), 0)
        }

        // Caption area: dark pill for what the user said, light card for the answer.
        val host = FrameLayout(service)
        val user = captionText(dark = true)
        val answer = captionText(dark = false)
        host.addView(user, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        host.addView(answer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(host, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = d(21f)
        })
        captionHost = host; userPill = user; answerCard = answer

        // Controls: camera, share screen, blob, microphone, close.
        val controls = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL or Gravity.CENTER_HORIZONTAL
        }
        val size = d(49f)
        val camera = circleButton("camera", "دوربین", size) { onAction(ACTION_CAMERA) }
        val screen = circleButton("screen", "اشتراک‌گذاری صفحه", size) { onAction(ACTION_SCREEN) }
        val orb = View(service).apply {
            background = blobBackground()
            elevation = dp(4).toFloat()
            contentDescription = "Digi Live"
            isClickable = true
            setOnClickListener { toggleExpanded() }
        }
        val mic = circleButton("mic", "فعال یا غیرفعال کردن میکروفون", size) { onAction(ACTION_MIC) }
        val close = circleButton("close", "پایان گفت‌وگو", size) { onAction(ACTION_END) }

        // Second glyph drawn on top of the microphone while it is muted.
        val micOff = LineIconView(service, "mic_off", Color.rgb(31, 31, 35)).apply { visibility = View.GONE }
        mic.addView(micOff, FrameLayout.LayoutParams(d(24f), d(24f), Gravity.CENTER))
        micOffIcon = micOff
        micIcon = mic.getChildAt(0)

        controls.addView(camera, LinearLayout.LayoutParams(size, size).apply { marginEnd = d(8f) })
        controls.addView(screen, LinearLayout.LayoutParams(size, size).apply { marginEnd = d(16f) })
        controls.addView(orb, LinearLayout.LayoutParams(d(113f), d(65f)).apply { marginEnd = d(18f) })
        controls.addView(mic, LinearLayout.LayoutParams(size, size).apply { marginEnd = d(9f) })
        controls.addView(close, LinearLayout.LayoutParams(size, size))
        root.addView(controls, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        row = controls; cameraButton = camera; screenButton = screen
        blob = orb; micButton = mic; closeButton = close

        val params = overlayParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, "Digi assistant panel").apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = navBarHeightPx() + dp(17)
        }
        try {
            manager.addView(root, params)
            panelWindow = root
            startBreathing(orb)
        } catch (_: Exception) {
            panelWindow = null
        }
    }

    private fun buildBubble() {
        val size = dp(66)
        val orb = View(service).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.WHITE, Color.rgb(237, 243, 255), Color.rgb(63, 133, 255))
            ).apply { shape = GradientDrawable.OVAL }
            elevation = dp(8).toFloat()
            contentDescription = "باز کردن دستیار Digi"
        }
        val params = overlayParams(size, size, "Digi assistant orb").apply {
            gravity = Gravity.END or Gravity.BOTTOM
            x = dp(bubbleX)
            y = dp(bubbleY)
        }
        orb.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0f
            private var startY = 0f
            private var originX = 0
            private var originY = 0
            private var dragged = false
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = event.rawX; startY = event.rawY
                        originX = params.x; originY = params.y; dragged = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - startX).toInt()
                        val dy = (event.rawY - startY).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) dragged = true
                        if (dragged) {
                            params.x = (originX - dx).coerceAtLeast(0)
                            params.y = (originY - dy).coerceAtLeast(dp(12))
                            try { manager.updateViewLayout(orb, params) } catch (_: Exception) { }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        bubbleX = (params.x / density).toInt()
                        bubbleY = (params.y / density).toInt()
                        if (!dragged) toggleExpanded()
                        return true
                    }
                }
                return false
            }
        })
        try { manager.addView(orb, params); bubbleWindow = orb } catch (_: Exception) { bubbleWindow = null }
    }

    private fun captionText(dark: Boolean) = TextView(service).apply {
        textSize = 20f
        setTextColor(if (dark) Color.rgb(243, 239, 239) else Color.rgb(31, 27, 27))
        background = rounded(if (dark) Color.rgb(31, 27, 27) else Color.rgb(238, 235, 235), 28f)
        setPadding(d(21f), d(17f), d(21f), d(17f))
        minHeight = d(65f)
        gravity = Gravity.START or Gravity.CENTER_VERTICAL
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        maxLines = 6
        ellipsize = TextUtils.TruncateAt.END
        setLineSpacing(dp(3).toFloat(), 1.0f)
        elevation = dp(2).toFloat()
        visibility = View.GONE
    }

    private fun circleButton(icon: String, label: String, size: Int, callback: () -> Unit): FrameLayout {
        val container = FrameLayout(service).apply {
            background = idleDisc()
            elevation = dp(3).toFloat()
            contentDescription = label
            isClickable = true
            isFocusable = true
            setOnClickListener { callback() }
        }
        val glyph = size * 0.5f
        container.addView(
            LineIconView(service, icon, Color.rgb(31, 31, 35)),
            FrameLayout.LayoutParams(glyph.toInt(), glyph.toInt(), Gravity.CENTER)
        )
        return container
    }

    private fun startBreathing(target: View) {
        breathing?.cancel()
        breathing = ObjectAnimator.ofPropertyValuesHolder(
            target,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.045f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.045f)
        ).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    // ---- state -> views -------------------------------------------------------------------

    private fun applyState() {
        val s = lastState
        val hasAnswer = s.answerText.isNotBlank()
        val hasUser = s.userText.isNotBlank()

        answerCard?.apply {
            text = s.answerText.trim()
            visibility = if (captionsOn && hasAnswer) View.VISIBLE else View.GONE
        }
        userPill?.apply {
            text = s.userText.trim()
            visibility = if (captionsOn && !hasAnswer && hasUser) View.VISIBLE else View.GONE
        }
        val anyCaption = (answerCard?.visibility == View.VISIBLE) || (userPill?.visibility == View.VISIBLE)
        captionHost?.visibility = if (anyCaption) View.VISIBLE else View.GONE
        captionToggle?.alpha = if (captionsOn) 1f else 0.62f

        val sideVisibility = if (controlsExpanded) View.VISIBLE else View.GONE
        cameraButton?.visibility = sideVisibility
        screenButton?.visibility = sideVisibility
        micButton?.visibility = sideVisibility
        closeButton?.visibility = sideVisibility

        // Expanded: the wide blob sits in the middle of the row. Collapsed: only a round orb at the end.
        row?.gravity = Gravity.CENTER_VERTICAL or (if (controlsExpanded) Gravity.CENTER_HORIZONTAL else Gravity.END)
        blob?.let { orb ->
            val lp = orb.layoutParams as LinearLayout.LayoutParams
            val newWidth = if (controlsExpanded) d(113f) else d(65f)
            val newEnd = if (controlsExpanded) d(18f) else 0
            if (lp.width != newWidth || lp.marginEnd != newEnd) {
                lp.width = newWidth
                lp.marginEnd = newEnd
                orb.layoutParams = lp
            }
        }

        cameraButton?.background = if (s.cameraActive) activeDisc() else idleDisc()
        screenButton?.background = if (s.screenActive) activeDisc() else idleDisc()
        micButton?.background = if (s.micMuted) mutedDisc() else idleDisc()
        micOffIcon?.visibility = if (s.micMuted) View.VISIBLE else View.GONE
        breathing?.duration = if (s.generating) 750 else 1500
    }

    // ---- teardown -------------------------------------------------------------------------

    private fun removeBubble() {
        bubbleWindow?.let { try { manager.removeView(it) } catch (_: Exception) { } }
        bubbleWindow = null
    }

    private fun removePanelWindows() {
        breathing?.cancel()
        breathing = null
        panelWindow?.let { try { manager.removeView(it) } catch (_: Exception) { } }
        topWindow?.let { try { manager.removeView(it) } catch (_: Exception) { } }
        panelWindow = null; topWindow = null; captionHost = null; userPill = null; answerCard = null
        row = null; cameraButton = null; screenButton = null; micButton = null; micIcon = null
        micOffIcon = null; closeButton = null; blob = null; captionToggle = null
    }

    private fun removeAll() {
        removePanelWindows()
        removeBubble()
    }

    /** Thin line icons (no emoji) matching the monochrome reference glyphs. */
    private class LineIconView(context: Context, private val kind: String, color: Int) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            strokeWidth = 1.9f
            this.color = color
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val s = min(width, height) / 24f
            canvas.save()
            canvas.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
            canvas.scale(s, s)
            val p = paint
            fun line(x1: Float, y1: Float, x2: Float, y2: Float) = canvas.drawLine(x1, y1, x2, y2, p)
            fun rr(l: Float, t: Float, r: Float, b: Float, rad: Float) = canvas.drawRoundRect(RectF(l, t, r, b), rad, rad, p)
            when (kind) {
                "camera" -> {
                    rr(2.8f, 5.5f, 16.8f, 18.5f, 3.4f)
                    line(17.2f, 10f, 21.2f, 8f)
                    line(21.2f, 8f, 21.2f, 16f)
                    line(21.2f, 16f, 17.2f, 14f)
                }
                "screen" -> {
                    rr(2.5f, 3.5f, 21.5f, 20.5f, 4.2f)
                    line(12f, 16f, 12f, 8f)
                    line(8.4f, 11.4f, 12f, 7.8f)
                    line(15.6f, 11.4f, 12f, 7.8f)
                }
                "mic" -> {
                    rr(8.2f, 2.5f, 15.8f, 15f, 3.8f)
                    canvas.drawArc(RectF(4.8f, 8.4f, 19.2f, 20.2f), 0f, 180f, false, p)
                    line(12f, 19.6f, 12f, 22f)
                }
                "mic_off" -> {
                    // Slash drawn over the microphone while it is muted.
                    line(4.5f, 3.5f, 19.5f, 21f)
                }
                "close" -> {
                    line(5.2f, 5.2f, 18.8f, 18.8f)
                    line(18.8f, 5.2f, 5.2f, 18.8f)
                }
                "captions" -> {
                    rr(3f, 4.5f, 21f, 19.5f, 4f)
                    line(7.5f, 10.2f, 16.5f, 10.2f)
                    line(7.5f, 14f, 13f, 14f)
                }
            }
            canvas.restore()
        }
    }
}
