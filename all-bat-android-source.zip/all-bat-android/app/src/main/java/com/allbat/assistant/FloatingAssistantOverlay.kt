package com.allbat.assistant

import android.animation.ValueAnimator
import android.app.Service
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.ViewOutlineProvider
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.speech.tts.TextToSpeech
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

/** Native Gemini-inspired floating assistant. It is deliberately lightweight and touch friendly. */
internal class FloatingAssistantOverlay(
    private val service: Service,
    private val onAction: (String) -> Unit
) {
    data class State(
        val userText: String = "",
        val answerText: String = "",
        val status: String = "گفت‌وگوی زنده فعال است",
        val generating: Boolean = false,
        val micMuted: Boolean = false,
        val cameraActive: Boolean = false,
        val screenActive: Boolean = false,
        /** True whenever the Live microphone/socket session is actually active, independent of panel layout. */
        val liveActive: Boolean = false,
        /** Main-app Live uses a transcript and five controls; system-assistant mode uses the answer card and composer. */
        val voiceMode: Boolean = true
    )

    companion object {
        const val ACTION_MIC = "mic"
        const val ACTION_CAMERA = "camera"
        const val ACTION_SCREEN = "screen"
        const val ACTION_END = "end"
        const val ACTION_OPEN = "open"
        const val ACTION_COLLAPSE = "collapse"
        const val ACTION_STOP_RESPONSE = "stop_response"
        const val ACTION_HIDE_ORB = "hide_orb"
    }

    private val manager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = service.resources.displayMetrics.density
    private var bubble: View? = null
    private var expandedPanel: View? = null
    private var expanded = false
    private var lastState = State()
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var answerTextView: TextView? = null
    private var answerScrollView: ScrollView? = null
    private var userTextView: TextView? = null
    private var statusTextView: TextView? = null
    private var speakerButton: FrameLayout? = null
    private var micButton: FrameLayout? = null
    private var cameraButton: FrameLayout? = null
    private var screenButton: FrameLayout? = null
    private var controlsRow: LinearLayout? = null
    private var composerLabel: TextView? = null
    private var composerMic: FrameLayout? = null
    private var composerAction: FrameLayout? = null
    private var answerCard: LinearLayout? = null
    private var liveTranscriptView: TextView? = null
    private var liveTranscriptScrollView: ScrollView? = null
    private var detailsRoot: LinearLayout? = null
    private var orbView: PillOrbView? = null
    private var captionToggle: View? = null
    private var captionToggleIcon: LineIconView? = null
    private var captionsOn = true
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
    /** Last time the separate captions-toggle window was touched; used to ignore its "outside touch" echo on the panel. */
    private var lastToggleTouchAt = 0L

    private fun dp(value: Int) = (value * density).toInt()

    /** A wrap-content ScrollView that stops growing beyond a screen-relative height. */
    private fun boundedScrollView(maxHeightDp: Int, screenFraction: Float): ScrollView {
        val screenCap = (service.resources.displayMetrics.heightPixels * screenFraction).toInt()
        val maxHeightPx = min(dp(maxHeightDp), screenCap).coerceAtLeast(dp(112))
        return object : ScrollView(service) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                val incomingMode = View.MeasureSpec.getMode(heightMeasureSpec)
                val incomingSize = View.MeasureSpec.getSize(heightMeasureSpec)
                val allowedHeight = when (incomingMode) {
                    View.MeasureSpec.EXACTLY, View.MeasureSpec.AT_MOST -> min(incomingSize, maxHeightPx)
                    else -> maxHeightPx
                }
                super.onMeasure(
                    widthMeasureSpec,
                    View.MeasureSpec.makeMeasureSpec(allowedHeight, View.MeasureSpec.AT_MOST)
                )
            }
        }.apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            isNestedScrollingEnabled = false
            clipToPadding = false
        }
    }
    private fun rounded(color: Int, radiusDp: Int, stroke: Int = Color.TRANSPARENT) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(color)
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }
    private fun glassPill(radiusDp: Int = 999) = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(
            Color.argb(247, 255, 255, 255),
            Color.argb(238, 247, 248, 255),
            Color.argb(229, 235, 234, 255)
        )
    ).apply {
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), Color.argb(170, 255, 255, 255))
    }

    private fun glassCard() = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(
            Color.argb(251, 255, 255, 255),
            Color.argb(250, 255, 255, 255),
            Color.argb(246, 244, 246, 255)
        )
    ).apply {
        cornerRadius = dp(25).toFloat()
        setStroke(dp(1), Color.rgb(225, 231, 243))
    }

    private fun orbBackground() = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(Color.rgb(255, 255, 255), Color.rgb(237, 243, 255), Color.rgb(63, 133, 255))
    ).apply { cornerRadius = dp(999).toFloat() }

    fun setVoiceMode(isMainAppLive: Boolean) {
        if (lastState.voiceMode == isMainAppLive) return
        lastState = lastState.copy(voiceMode = isMainAppLive)
        if (expanded) { removePanel(); showPanel() }
    }

    fun show() {
        if (!canDraw()) return
        if (expanded) showPanel() else showBubble()
    }

    fun update(newState: State) {
        val modeChanged = lastState.voiceMode != newState.voiceMode
        val hasTranscript = newState.userText.isNotBlank() || newState.answerText.isNotBlank() || newState.generating
        val needsPanelRebuild = expanded && (
            modeChanged ||
                (hasTranscript && newState.voiceMode && liveTranscriptView == null) ||
                (hasTranscript && !newState.voiceMode && answerCard == null)
            )
        lastState = newState
        if (!canDraw()) { removeAll(); return }
        if (expanded) {
            // Refresh text and active colors in place. Rebuilding on every audio/text chunk causes flicker.
            if (needsPanelRebuild) { removePanel(); showPanel() } else updatePanelContent()
        } else {
            showBubbleIfMissing()
        }
    }

    fun toggleExpanded() {
        expanded = !expanded
        if (expanded) { removeBubble(); showPanel() } else { removePanel(); showBubble() }
    }

    fun collapse() { expanded = false; removePanel(); showBubble() }
    fun hide() {
        expanded = false
        removeAll()
    }

    /** Temporarily removes the windows (e.g. while a system consent sheet is shown) but remembers bubble/panel state. */
    fun suspend() { removeAll() }
    fun destroy() {
        removeAll()
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null; ttsReady = false
    }

    private fun canDraw(): Boolean = Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(service)

    private fun showBubbleIfMissing() { if (bubble == null) showBubble() }

    private fun showBubble() {
        if (!canDraw() || bubble != null) return
        val size = dp(66)
        val orb = FrameLayout(service).apply {
            background = orbBackground()
            elevation = dp(3).toFloat()
            contentDescription = "باز کردن دستیار؛ برای پنهان‌کردن، کمی نگه دار"
            setOnClickListener { toggleExpanded() }
        }
        val params = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.RIGHT or Gravity.BOTTOM; x = dp(16); y = dp(130); title = "All Bat assistant orb" }
        installDrag(orb, params)
        try { manager.addView(orb, params); bubble = orb } catch (_: Exception) { bubble = null }
    }

    private fun installDrag(view: View, params: WindowManager.LayoutParams) {
        view.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0f; private var startY = 0f; private var originX = 0; private var originY = 0; private var dragged = false; private var pressedAt = 0L
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { startX=event.rawX; startY=event.rawY; originX=params.x; originY=params.y; pressedAt=event.eventTime; dragged=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(event.rawX-startX).toInt(); val dy=(event.rawY-startY).toInt()
                        if (abs(dx)>dp(6)||abs(dy)>dp(6)) dragged=true
                        if (dragged) { params.x=(originX-dx).coerceAtLeast(0); params.y=(originY-dy).coerceAtLeast(dp(12)); try { manager.updateViewLayout(view,params) } catch (_:Exception) {} }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!dragged) {
                            val heldMs = event.eventTime - pressedAt
                            if (heldMs >= 700L) {
                                if (lastState.liveActive) {
                                    Toast.makeText(service, "برای پنهان‌کردن حباب، ابتدا گفت‌وگوی زنده را پایان بده.", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(service, "حباب شناور غیرفعال شد", Toast.LENGTH_SHORT).show()
                                    onAction(ACTION_HIDE_ORB)
                                }
                            } else {
                                v.performClick()
                            }
                        }
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> return true
                }
                return false
            }
        })
    }

    private fun showPanel() {
        if (!canDraw()) return
        if (expandedPanel != null) return
        val screenWidth = service.resources.displayMetrics.widthPixels
        val width = screenWidth
        val root = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
            setPadding(dp(17), dp(4), dp(17), dp(6))
            background = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
        }
        detailsRoot = root
        // Touching anywhere outside the panel (the rest of the screen) shrinks it back into the bubble.
        // The touch still reaches the app underneath, so nothing is blocked.
        root.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                mainHandler.postDelayed({
                    if (expanded && expandedPanel === root &&
                        android.os.SystemClock.uptimeMillis() - lastToggleTouchAt > 450L
                    ) collapse()
                }, 90L)
                true
            } else false
        }
        if (lastState.voiceMode) {
            // Live mode mirrors Gemini Live: transcript only, followed by the five circular controls.
            buildLiveTranscript(root)
            buildLiveControls(root)
        } else {
            // Default-assistant mode uses the full answer card and Ask Gemini composer.
            buildAnswerCard(root)
            buildComposer(root)
        }

        val params = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(9)
            title = "All Bat assistant panel"
        }
        try { manager.addView(root, params); expandedPanel = root; updatePanelContent() }
        catch (_: Exception) { expandedPanel = null }
        if (expandedPanel != null && lastState.voiceMode) showCaptionToggle()
        ensureTts()
    }

    private fun buildAnswerCard(root: LinearLayout) {
        val shouldShow = lastState.userText.isNotBlank() || lastState.answerText.isNotBlank() || lastState.generating
        if (!shouldShow) return
        val wrap = LinearLayout(service).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(7), dp(4), dp(10)) }
        val minimizeRow = LinearLayout(service).apply {
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val minimize = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(14), dp(7), dp(16), dp(7))
            background = glassPill()
            elevation = dp(4).toFloat()
            contentDescription = "Minimize assistant"
            isClickable = true
            isFocusable = true
            setOnClickListener { collapse() }
        }
        minimize.addView(LineIconView(service, "minimize", Color.rgb(35, 42, 56)),
            LinearLayout.LayoutParams(dp(15), dp(15)).apply { marginEnd = dp(8) })
        minimize.addView(TextView(service).apply {
            text = "Minimize"
            textSize = 12.5f
            setTextColor(Color.rgb(35, 42, 56))
            gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        minimizeRow.addView(minimize, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
        wrap.addView(minimizeRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val card = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(14), dp(10))
            background = glassCard()
            elevation = dp(6).toFloat()
        }
        userTextView = TextView(service).apply {
            textSize = 12f; setTextColor(Color.rgb(101, 108, 120)); maxLines = 2
            ellipsize = TextUtils.TruncateAt.END; visibility = View.GONE; setPadding(0, 0, 0, dp(4))
        }
        card.addView(userTextView)
        statusTextView = TextView(service).apply {
            textSize = 11f; setTextColor(Color.rgb(99, 111, 133)); visibility = View.GONE
        }
        card.addView(statusTextView)
        answerTextView = TextView(service).apply {
            textSize = 17f; setTextColor(Color.rgb(24, 27, 32))
            maxLines = Int.MAX_VALUE; ellipsize = null
            setLineSpacing(dp(2).toFloat(), 1.0f)
            setPadding(0, 0, dp(2), dp(3))
        }
        answerScrollView = boundedScrollView(280, 0.38f).apply {
            addView(answerTextView, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
        card.addView(answerScrollView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        val disclaimer = TextView(service).apply {
            text = "Gemini is AI and can make mistakes."; textSize = 12.5f; setTextColor(Color.rgb(97, 97, 97)); setPadding(0, dp(6), 0, dp(8))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.LEFT
        }
        card.addView(disclaimer)
        val actions = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        fun actionIcon(kind: String, description: String, blue: Boolean = false, callback: () -> Unit): FrameLayout {
            val btn = iconButton(kind, description, if (blue) Color.rgb(220, 235, 255) else Color.TRANSPARENT, Color.rgb(133, 136, 143), dp(36), callback)
            actions.addView(btn, LinearLayout.LayoutParams(dp(40), dp(38)))
            return btn
        }
        actionIcon("like", "پاسخ مفید بود") { Toast.makeText(service, "ممنون از بازخوردت", Toast.LENGTH_SHORT).show() }
        actionIcon("dislike", "پاسخ مفید نبود") { Toast.makeText(service, "بازخورد ثبت شد", Toast.LENGTH_SHORT).show() }
        actionIcon("share", "اشتراک‌گذاری پاسخ") { onAction(ACTION_OPEN) }
        actionIcon("copy", "کپی پاسخ") { copyAnswer() }
        actionIcon("more", "گزینه‌های بیشتر") { Toast.makeText(service, "گزینهٔ بیشتر در برنامه در دسترس است", Toast.LENGTH_SHORT).show() }
        val spacer = View(service); actions.addView(spacer, LinearLayout.LayoutParams(0, dp(1), 1f))
        speakerButton = iconButton("speaker", "خواندن پاسخ با صدا", Color.rgb(207, 226, 255), Color.rgb(23, 73, 149), dp(42)) { readAnswerAloud() }
        actions.addView(speakerButton, LinearLayout.LayoutParams(dp(44), dp(42)))
        card.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)))
        wrap.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(wrap, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        answerCard = wrap
    }

    private fun buildLiveTranscript(root: LinearLayout) {
        val shouldShow = lastState.userText.isNotBlank() || lastState.answerText.isNotBlank() || lastState.generating
        if (!shouldShow) return
        val transcript = TextView(service).apply {
            text = when {
                lastState.answerText.isNotBlank() -> lastState.answerText.trim()
                lastState.userText.isNotBlank() -> lastState.userText.trim()
                else -> "Just a sec…"
            }
            textSize = 18f
            setTextColor(Color.rgb(27, 28, 33))
            gravity = Gravity.TOP
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            textAlignment = View.TEXT_ALIGNMENT_TEXT_START
            layoutDirection = View.LAYOUT_DIRECTION_LOCALE
            maxLines = Int.MAX_VALUE
            ellipsize = null
            setLineSpacing(dp(6).toFloat(), 1.05f)
            setPadding(dp(28), dp(24), dp(28), dp(24))
            minimumHeight = dp(104)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(250, 241, 238, 238), Color.argb(248, 237, 234, 235))
            ).apply { cornerRadius = dp(30).toFloat() }
            elevation = dp(4).toFloat()
            contentDescription = "Live conversation transcript"
        }
        liveTranscriptScrollView = boundedScrollView(190, 0.28f).apply {
            addView(transcript, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
        root.addView(liveTranscriptScrollView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(14) })
        liveTranscriptView = transcript
    }

    private fun buildLiveControls(root: LinearLayout) {
        val row = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val size = dp(50)
        // Physical left-to-right order on RTL devices too: camera, screen, orb, mic, close.
        cameraButton = circleButton("camera", "دوربین", liveButtonColor(lastState.cameraActive)) { onAction(ACTION_CAMERA) }
        screenButton = circleButton("screen", "اشتراک‌گذاری صفحه", liveButtonColor(lastState.screenActive)) { onAction(ACTION_SCREEN) }
        row.addView(cameraButton, LinearLayout.LayoutParams(size, size).apply { marginEnd = dp(9) })
        row.addView(screenButton, LinearLayout.LayoutParams(size, size))
        val orb = PillOrbView(service).apply {
            contentDescription = "Digi Live"
            setOnClickListener { onAction(ACTION_OPEN) }
        }
        orbView = orb
        row.addView(orb, LinearLayout.LayoutParams(0, dp(64), 1f).apply { marginStart = dp(17); marginEnd = dp(17) })
        micButton = circleButton("mic", "فعال یا غیرفعال کردن میکروفون", micColor(lastState.micMuted)) { onAction(ACTION_MIC) }
        row.addView(micButton, LinearLayout.LayoutParams(size, size).apply { marginEnd = dp(9) })
        val end = circleButton("close", "پایان گفت‌وگو", LIVE_BUTTON_IDLE) { onAction(ACTION_END) }
        row.addView(end, LinearLayout.LayoutParams(size, size))
        root.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        controlsRow = row
    }

    private val LIVE_BUTTON_IDLE = Color.rgb(250, 248, 254)
    private fun liveButtonColor(active: Boolean) = if (active) Color.rgb(205, 224, 255) else LIVE_BUTTON_IDLE
    private fun micColor(muted: Boolean) = if (muted) Color.rgb(255, 214, 214) else LIVE_BUTTON_IDLE

    private fun circleBackground(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setStroke(1, Color.argb(60, 120, 124, 140))
    }

    /** Solid, opaque round control (white by default) with a bold line icon, as in the reference design. */
    private fun circleButton(icon: String, label: String, bg: Int, callback: () -> Unit): FrameLayout {
        val container = FrameLayout(service).apply {
            background = circleBackground(bg)
            elevation = dp(2).toFloat()
            contentDescription = label
            isClickable = true; isFocusable = true
            setOnClickListener { callback() }
        }
        container.addView(LineIconView(service, icon, Color.rgb(52, 55, 63), 1.25f), FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER))
        return container
    }

    /** Round button at the top-right that shows or hides the live captions card. */
    private fun showCaptionToggle() {
        if (captionToggle != null || !canDraw()) return
        val btn = circleButton("captions", "نمایش یا پنهان‌کردن زیرنویس", LIVE_BUTTON_IDLE) {
            captionsOn = !captionsOn
            updatePanelContent()
        }
        captionToggleIcon = (btn.getChildAt(0) as? LineIconView)
        btn.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) lastToggleTouchAt = android.os.SystemClock.uptimeMillis()
            false
        }
        val sbId = service.resources.getIdentifier("status_bar_height", "dimen", "android")
        val statusBar = if (sbId > 0) service.resources.getDimensionPixelSize(sbId) else dp(24)
        val params = WindowManager.LayoutParams(
            dp(50), dp(50), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.RIGHT; x = dp(23); y = statusBar + dp(4); title = "All Bat captions toggle" }
        try { manager.addView(btn, params); captionToggle = btn } catch (_: Exception) { captionToggle = null }
        updatePanelContent()
    }

    private fun removeCaptionToggle() {
        val v = captionToggle ?: return
        try { manager.removeView(v) } catch (_: Exception) { }
        captionToggle = null; captionToggleIcon = null
    }

    private fun buildComposer(root: LinearLayout) {
        val pill = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(7))
            background = glassPill()
            elevation = dp(7).toFloat()
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val plus = iconButton("plus", "گزینه‌های پیوست", Color.TRANSPARENT, Color.rgb(33, 35, 40), dp(47)) { onAction(ACTION_OPEN) }
        pill.addView(plus, LinearLayout.LayoutParams(dp(50), dp(50)))
        composerLabel = TextView(service).apply {
            text = "Ask Gemini"; textSize = 19f; setTextColor(Color.rgb(56, 59, 66)); gravity = Gravity.CENTER_VERTICAL or Gravity.START
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(4), 0, dp(4), 0)
            setOnClickListener { onAction(ACTION_OPEN) }
        }
        pill.addView(composerLabel, LinearLayout.LayoutParams(0, dp(50), 1f))
        composerMic = iconButton("mic", "شروع ورودی صوتی", Color.rgb(169, 200, 251), Color.rgb(17, 68, 146), dp(50)) { onAction(ACTION_MIC) }
        pill.addView(composerMic, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginEnd = dp(5) })
        composerAction = iconButton(if (lastState.generating) "stop" else "arrow", if (lastState.generating) "توقف" else "ارسال یا باز کردن گفتگو", if (lastState.generating) Color.rgb(169, 200, 251) else Color.rgb(231, 235, 244), Color.rgb(65, 75, 91), dp(48)) {
            if (lastState.generating) onAction(ACTION_STOP_RESPONSE) else onAction(ACTION_OPEN)
        }
        pill.addView(composerAction, LinearLayout.LayoutParams(dp(50), dp(50)))
        root.addView(pill, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(4)
            marginEnd = dp(4)
        })
    }

    private fun inactiveColor(active: Boolean) = if (active) Color.argb(138, 151, 190, 247) else Color.argb(54, 246, 248, 252)
    private fun activeColor(active: Boolean) = if (active) Color.argb(146, 147, 187, 246) else Color.argb(58, 245, 248, 253)

    private fun iconButton(icon: String, label: String, bg: Int, fg: Int, size: Int, callback: () -> Unit): FrameLayout {
        val container = FrameLayout(service).apply {
            background = rounded(bg, 999, Color.argb(48, 255, 255, 255))
            contentDescription = label
            isClickable = true; isFocusable = true
            setOnClickListener { callback() }
        }
        val glyph = LineIconView(service, icon, fg)
        val glyphSize = when {
            icon == "speaker" -> 20
            size <= dp(40) -> 17
            else -> 22
        }
        container.addView(glyph, FrameLayout.LayoutParams(dp(glyphSize), dp(glyphSize), Gravity.CENTER))
        return container
    }

    private fun updatePanelContent() {
        fun isNearBottom(scroll: ScrollView?): Boolean {
            if (scroll == null || scroll.childCount == 0) return true
            val content = scroll.getChildAt(0)
            return scroll.scrollY + scroll.height >= content.height - dp(28)
        }
        val followAnswer = isNearBottom(answerScrollView)
        val followLiveTranscript = isNearBottom(liveTranscriptScrollView)
        answerTextView?.text = when {
            lastState.answerText.isNotBlank() -> lastState.answerText.trim()
            lastState.generating -> "Just a sec…"
            else -> "در خدمتم؛ سؤال خودت را بگو."
        }
        userTextView?.apply {
            text = lastState.userText.trim()
            visibility = if (lastState.userText.isBlank()) View.GONE else View.VISIBLE
        }
        statusTextView?.apply {
            text = lastState.status
            visibility = if (lastState.generating || lastState.status.contains("بازیابی")) View.VISIBLE else View.GONE
        }
        composerLabel?.text = if (lastState.generating) "Just a sec…" else "Ask Gemini"
        composerMic?.alpha = if (lastState.generating) 0.62f else 1f
        micButton?.background = circleBackground(micColor(lastState.micMuted))
        screenButton?.background = circleBackground(liveButtonColor(lastState.screenActive))
        cameraButton?.background = circleBackground(liveButtonColor(lastState.cameraActive))
        orbView?.setActive(lastState.generating || lastState.liveActive)
        captionToggle?.alpha = 1f
        captionToggleIcon?.setKind(if (captionsOn) "captions" else "captions_off")
        // Keep generated answers and the voice controls in the same floating surface.
        val hasTranscript = lastState.userText.isNotBlank() || lastState.answerText.isNotBlank() || lastState.generating
        answerCard?.visibility = if (!lastState.voiceMode && hasTranscript) View.VISIBLE else View.GONE
        liveTranscriptView?.apply {
            text = when {
                lastState.answerText.isNotBlank() -> lastState.answerText.trim()
                lastState.userText.isNotBlank() -> lastState.userText.trim()
                lastState.generating -> "Just a sec…"
                else -> ""
            }
            visibility = if (lastState.voiceMode && hasTranscript) View.VISIBLE else View.GONE
        }
        liveTranscriptScrollView?.visibility =
            if (lastState.voiceMode && hasTranscript && captionsOn) View.VISIBLE else View.GONE
        if (followAnswer) answerScrollView?.post { answerScrollView?.fullScroll(View.FOCUS_DOWN) }
        if (followLiveTranscript) liveTranscriptScrollView?.post { liveTranscriptScrollView?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun ensureTts() {
        if (tts != null) return
        tts = TextToSpeech(service) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                val result = tts?.setLanguage(Locale("fa", "IR"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) tts?.language = Locale("fa")
            }
        }
    }

    private fun readAnswerAloud() {
        val text = lastState.answerText.trim()
        if (text.isBlank()) { Toast.makeText(service, "هنوز پاسخی برای خواندن وجود ندارد", Toast.LENGTH_SHORT).show(); return }
        ensureTts()
        if (!ttsReady || tts == null) { Toast.makeText(service, "موتور گفتار هنوز آماده نیست", Toast.LENGTH_SHORT).show(); return }
        @Suppress("DEPRECATION")
        tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null)
    }

    private fun copyAnswer() {
        val text = lastState.answerText.trim()
        if (text.isBlank()) { Toast.makeText(service, "پاسخی برای کپی وجود ندارد", Toast.LENGTH_SHORT).show(); return }
        val clipboard = service.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Digi response", text))
        Toast.makeText(service, "پاسخ کپی شد", Toast.LENGTH_SHORT).show()
    }

    private fun removeBubble() { val view = bubble ?: return; try { manager.removeView(view) } catch (_: Exception) {}; bubble = null }
    private fun removePanel() {
        mainHandler.removeCallbacksAndMessages(null)
        removeCaptionToggle()
        orbView?.setActive(false); orbView = null
        val view = expandedPanel ?: return
        try { manager.removeView(view) } catch (_: Exception) {}
        expandedPanel = null; answerTextView = null; answerScrollView = null; userTextView = null; statusTextView = null; speakerButton = null
        micButton = null; cameraButton = null; screenButton = null; controlsRow = null; composerLabel = null; composerMic = null; composerAction = null; answerCard = null; liveTranscriptView = null; liveTranscriptScrollView = null; detailsRoot = null
    }
    private fun removeAll() { removePanel(); removeBubble() }

    /** Thin custom line icons avoid emoji-dependent glyphs and match the monochrome reference UI. */
    private class LineIconView(context: Context, private var kind: String, color: Int, strokeDp: Float = 1.35f) : View(context) {
        fun setKind(newKind: String) { if (kind != newKind) { kind = newKind; invalidate() } }
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; strokeWidth = strokeDp * context.resources.displayMetrics.density; this.color = color
        }
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = color }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val s = min(width, height) / 24f
            canvas.save(); canvas.translate((width - 24f*s)/2f, (height-24f*s)/2f); canvas.scale(s,s)
            val p = paint
            fun line(x1:Float,y1:Float,x2:Float,y2:Float){canvas.drawLine(x1,y1,x2,y2,p)}
            fun rr(l:Float,t:Float,r:Float,b:Float,rad:Float){canvas.drawRoundRect(RectF(l,t,r,b),rad,rad,p)}
            fun circle(x:Float,y:Float,r:Float){canvas.drawCircle(x,y,r,p)}
            when(kind){
                "camera" -> { rr(2.8f,6f,17f,18f,3.8f); line(20.8f,9.5f,20.8f,14.5f) }
                "captions" -> { rr(3.5f,3.5f,20.5f,20.5f,5f); line(7.5f,10f,16.5f,10f); line(7.5f,14.5f,12.5f,14.5f) }
                "captions_off" -> { rr(3.5f,3.5f,20.5f,20.5f,5f); line(7.5f,10f,16.5f,10f); line(7.5f,14.5f,12.5f,14.5f); line(3f,3f,21f,21f) }
                "screen" -> { rr(2.5f,4f,21.5f,20f,3f); line(12f,16.5f,12f,7.5f); line(8.5f,11f,12f,7.5f); line(15.5f,11f,12f,7.5f) }
                "mic" -> { rr(8.2f,2.5f,15.8f,15f,3.8f); canvas.drawArc(RectF(4.5f,8.5f,19.5f,19.8f),0f,180f,false,p); line(12f,19.5f,12f,22f); line(8.5f,22f,15.5f,22f) }
                "close" -> { line(5f,5f,19f,19f); line(19f,5f,5f,19f) }
                "minimize" -> {
                    line(9f,4f,4f,4f); line(4f,4f,4f,9f)
                    line(15f,4f,20f,4f); line(20f,4f,20f,9f)
                    line(4f,15f,4f,20f); line(4f,20f,9f,20f)
                    line(20f,15f,20f,20f); line(20f,20f,15f,20f)
                }
                "plus" -> { line(12f,3f,12f,21f); line(3f,12f,21f,12f) }
                "arrow" -> { line(12f,21f,12f,3f); line(5f,10f,12f,3f); line(19f,10f,12f,3f) }
                "stop" -> { canvas.drawRoundRect(RectF(5f,5f,19f,19f),3f,3f,fillPaint) }
                "speaker" -> { val path=Path().apply{moveTo(3f,9f);lineTo(7f,9f);lineTo(12f,5f);lineTo(12f,19f);lineTo(7f,15f);lineTo(3f,15f);close()};canvas.drawPath(path,fillPaint);canvas.drawArc(RectF(9f,5f,20f,19f),-55f,110f,false,p);canvas.drawArc(RectF(7f,2f,23f,22f),-48f,96f,false,p) }
                "like" -> { val path=Path().apply{moveTo(8f,10f);lineTo(8f,20f);lineTo(17f,20f);quadTo(19f,20f,19.5f,17.5f);lineTo(21f,12f);quadTo(21.3f,10f,19f,10f);lineTo(14f,10f);lineTo(15f,5f);quadTo(15.2f,3f,13.2f,3f);lineTo(8f,10f);close()};canvas.drawPath(path,p);rr(3f,10f,7f,20f,1f) }
                "dislike" -> { canvas.save(); canvas.rotate(180f,12f,12f); val path=Path().apply{moveTo(8f,10f);lineTo(8f,20f);lineTo(17f,20f);quadTo(19f,20f,19.5f,17.5f);lineTo(21f,12f);quadTo(21.3f,10f,19f,10f);lineTo(14f,10f);lineTo(15f,5f);quadTo(15.2f,3f,13.2f,3f);lineTo(8f,10f);close()};canvas.drawPath(path,p);rr(3f,10f,7f,20f,1f);canvas.restore() }
                "share" -> { circle(5f,12f,2.2f); circle(18.5f,5f,2.2f); circle(18.5f,19f,2.2f); line(7f,11f,16.5f,6f); line(7f,13f,16.5f,18f) }
                "copy" -> { rr(7f,3f,19f,18f,2.5f); line(4f,7f,4f,19f); line(4f,19f,7f,21f); line(7f,21f,17f,21f) }
                "more" -> { circle(12f,5f,1f);circle(12f,12f,1f);circle(12f,19f,1f) }
            }
            canvas.restore()
        }
    }
}

/** Wide pill orb: white at the top fading to a glowing blue at the bottom. Drifts gently while active. */
internal class PillOrbView(context: Context) : View(context) {
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var animator: ValueAnimator? = null

    init {
        elevation = 2f * context.resources.displayMetrics.density
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, view.height / 2f)
            }
        }
        clipToOutline = true
        isClickable = true
    }

    fun setActive(active: Boolean) {
        if (active) {
            if (animator != null) return
            animator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 2600L
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                addUpdateListener { phase = it.animatedValue as Float; invalidate() }
                start()
            }
        } else {
            animator?.cancel(); animator = null
            phase = 0f; invalidate()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel(); animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        bodyPaint.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(Color.rgb(253, 252, 255), Color.rgb(246, 245, 255), Color.rgb(208, 223, 255), Color.rgb(120, 168, 250)),
            floatArrayOf(0f, 0.45f, 0.78f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, bodyPaint)
        // Soft blue glow along the bottom edge that slides sideways while active.
        val cx = w * (0.3f + 0.4f * phase)
        glowPaint.shader = RadialGradient(
            cx, h * 1.02f, w * 0.42f,
            intArrayOf(Color.argb(170, 70, 135, 255), Color.argb(80, 100, 160, 255), Color.argb(0, 100, 160, 255)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        canvas.save()
        canvas.scale(1f, 0.55f, cx, h)
        canvas.drawCircle(cx, h * 1.02f, w * 0.42f, glowPaint)
        canvas.restore()
    }
}
