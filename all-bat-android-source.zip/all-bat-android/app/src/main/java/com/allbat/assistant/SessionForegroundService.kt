package com.allbat.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** Visible foreground service for an explicitly started mic/camera session and its floating UI. */
class SessionForegroundService : Service() {
    companion object {
        const val ACTION_START_VOICE = "com.allbat.assistant.action.START_VOICE"
        const val ACTION_STOP_VOICE = "com.allbat.assistant.action.STOP_VOICE"
        const val ACTION_START_CAMERA = "com.allbat.assistant.action.START_CAMERA"
        const val ACTION_STOP_CAMERA = "com.allbat.assistant.action.STOP_CAMERA"
        const val ACTION_STOP_ALL = "com.allbat.assistant.action.STOP_ALL"
        const val ACTION_REFRESH_OVERLAY = "com.allbat.assistant.action.REFRESH_OVERLAY"
        const val ACTION_UPDATE_OVERLAY = "com.allbat.assistant.action.UPDATE_OVERLAY"
        const val ACTION_SHOW_ORB = "com.allbat.assistant.action.SHOW_ORB"
        const val ACTION_HIDE_ORB = "com.allbat.assistant.action.HIDE_ORB"
        const val ACTION_SURFACE_VISIBILITY = "com.allbat.assistant.action.SURFACE_VISIBILITY"
        const val ACTION_SESSION_BUBBLE_STATE = "com.allbat.assistant.action.SESSION_BUBBLE_STATE"
        const val EXTRA_SURFACE_OWNER = "surface_owner"
        const val EXTRA_SURFACE_VISIBLE = "surface_visible"
        const val EXTRA_SESSION_BUBBLE_VISIBLE = "session_bubble_visible"
        const val EXTRA_USER_TEXT = "overlay_user_text"
        const val EXTRA_ANSWER_TEXT = "overlay_answer_text"
        const val EXTRA_STATUS = "overlay_status"
        const val EXTRA_GENERATING = "overlay_generating"
        const val EXTRA_MIC_MUTED = "overlay_mic_muted"
        const val EXTRA_CAMERA_ACTIVE = "overlay_camera_active"
        const val EXTRA_SCREEN_ACTIVE = "overlay_screen_active"
        const val EXTRA_OVERLAY_OWNER = "overlay_owner"
        private const val CHANNEL_ID = "allbat_live_session"
        private const val NOTIFICATION_ID = 5101
    }

    private var voiceActive = false
    private var cameraActive = false
    private var mainSurfaceVisible = false
    private var assistantSurfaceVisible = false
    private var permissionSurfaceVisible = false
    private var sessionBubbleVisible = false
    private var bubbleHiddenUntilLiveEnds = false
    private var overlayOwner = "main"
    private var overlayState = FloatingAssistantOverlay.State()
    private var floatingOverlay: FloatingAssistantOverlay? = null
    private var overlayReceiverRegistered = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private var overlayPermissionPollCount = 0
    private var overlayPermissionPollActive = false
    private val overlayPermissionPoll = object : Runnable {
        override fun run() {
            if (!shouldShowFloatingBubble()) {
                overlayPermissionPollActive = false
                overlayPermissionPollCount = 0
                floatingOverlay?.hide()
                return
            }
            if (Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this@SessionForegroundService)) {
                overlayPermissionPollActive = false
                overlayPermissionPollCount = 0
                ensureOverlayVisible()
            } else if (overlayPermissionPollCount++ < 90) {
                // The system-assistant surface can be hidden while its Settings page is open.
                // Poll briefly so granting the special permission reveals the orb without a restart.
                mainHandler.postDelayed(this, 1000L)
            } else {
                overlayPermissionPollActive = false
                overlayPermissionPollCount = 0
            }
        }
    }

    private val overlayReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_UPDATE_OVERLAY -> {
                    overlayOwner = intent.getStringExtra(EXTRA_OVERLAY_OWNER)?.takeIf { it == "main" || it == "system_assistant" } ?: overlayOwner
                    overlayState = FloatingAssistantOverlay.State(
                        userText = intent.getStringExtra(EXTRA_USER_TEXT).orEmpty().take(600),
                        answerText = intent.getStringExtra(EXTRA_ANSWER_TEXT).orEmpty().take(3000),
                        status = intent.getStringExtra(EXTRA_STATUS).orEmpty().ifBlank { "گفت‌وگوی زنده فعال است" }.take(100),
                        generating = intent.getBooleanExtra(EXTRA_GENERATING, false),
                        micMuted = intent.getBooleanExtra(EXTRA_MIC_MUTED, false),
                        cameraActive = intent.getBooleanExtra(EXTRA_CAMERA_ACTIVE, cameraActive),
                        screenActive = intent.getBooleanExtra(EXTRA_SCREEN_ACTIVE, false),
                        voiceMode = overlayOwner == "main"
                    )
                    if (voiceActive) {
                        floatingOverlay?.update(overlayState.copy(voiceMode = voiceActive && overlayOwner == "main", liveActive = voiceActive))
                    }
                    ensureOverlayVisible()
                }
                ACTION_REFRESH_OVERLAY -> ensureOverlayVisible()
                ACTION_SESSION_BUBBLE_STATE -> {
                    sessionBubbleVisible = intent.getBooleanExtra(EXTRA_SESSION_BUBBLE_VISIBLE, false)
                    getSharedPreferences("allbat_session_state", MODE_PRIVATE).edit()
                        .putBoolean("session_bubble_visible", sessionBubbleVisible)
                        .apply()
                    ensureOverlayVisible()
                }
                ACTION_SURFACE_VISIBILITY -> {
                    val owner = intent.getStringExtra(EXTRA_SURFACE_OWNER)
                    val visible = intent.getBooleanExtra(EXTRA_SURFACE_VISIBLE, false)
                    when (owner) {
                        "main" -> mainSurfaceVisible = visible
                        "assistant" -> assistantSurfaceVisible = visible
                        "permission" -> permissionSurfaceVisible = visible
                    }
                    ensureOverlayVisible()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val sessionPrefs = getSharedPreferences("allbat_session_state", MODE_PRIVATE)
        mainSurfaceVisible = sessionPrefs.getBoolean("main_surface_visible", false)
        assistantSurfaceVisible = sessionPrefs.getBoolean("assistant_surface_visible", false)
        permissionSurfaceVisible = sessionPrefs.getBoolean("permission_surface_visible", false)
        sessionBubbleVisible = sessionPrefs.getBoolean("session_bubble_visible", false)
        createNotificationChannel()
        floatingOverlay = FloatingAssistantOverlay(this) { action -> handleOverlayAction(action) }
        val filter = IntentFilter().apply {
            addAction(ACTION_UPDATE_OVERLAY)
            addAction(ACTION_REFRESH_OVERLAY)
            addAction(ACTION_SURFACE_VISIBILITY)
            addAction(ACTION_SESSION_BUBBLE_STATE)
        }
        try {
            ContextCompat.registerReceiver(this, overlayReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            overlayReceiverRegistered = true
        } catch (error: Exception) {
            android.util.Log.w("AllBatOverlay", "Could not register overlay updates", error)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.getStringExtra(EXTRA_OVERLAY_OWNER)?.takeIf { it == "main" || it == "system_assistant" }?.let { overlayOwner = it }
        when (intent?.action) {
            ACTION_START_VOICE -> {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    voiceActive = true
                    bubbleHiddenUntilLiveEnds = false
                }
            }
            ACTION_STOP_VOICE -> {
                sessionBubbleVisible = false
                getSharedPreferences("allbat_session_state", MODE_PRIVATE).edit().putBoolean("session_bubble_visible", false).apply()
                voiceActive = false
                bubbleHiddenUntilLiveEnds = false
                overlayState = overlayState.copy(
                    status = "گفت‌وگوی زنده پایان یافت",
                    generating = false,
                    micMuted = true,
                    voiceMode = false,
                    liveActive = false
                )
                floatingOverlay?.hide()
            }
            ACTION_SHOW_ORB -> {
                bubbleHiddenUntilLiveEnds = false
                ensureOverlayVisible()
            }
            ACTION_HIDE_ORB -> {
                bubbleHiddenUntilLiveEnds = true
                floatingOverlay?.hide()
            }
            ACTION_START_CAMERA -> {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    cameraActive = true
                }
            }
            ACTION_STOP_CAMERA -> cameraActive = false
            ACTION_STOP_ALL -> {
                sessionBubbleVisible = false
                getSharedPreferences("allbat_session_state", MODE_PRIVATE).edit().putBoolean("session_bubble_visible", false).apply()
                voiceActive = false
                bubbleHiddenUntilLiveEnds = false
                cameraActive = false
                overlayState = overlayState.copy(
                    status = "گفت‌وگوی زنده پایان یافت",
                    generating = false,
                    micMuted = true,
                    cameraActive = false,
                    screenActive = false,
                    voiceMode = false,
                    liveActive = false
                )
                floatingOverlay?.hide()
            }
            ACTION_REFRESH_OVERLAY -> {
                // Used after the user returns from Android's overlay-permission settings.
            }
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            voiceActive = false
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraActive = false
        }

        // Keep an explicit, process-independent record so MainActivity can distinguish Back-to-background
        // from a genuinely idle app. The WebView is the owner of Live's socket/audio session.
        val sessionPrefs = getSharedPreferences("allbat_session_state", MODE_PRIVATE)
        sessionPrefs.edit()
            .putBoolean("voice_active", voiceActive)
            .putBoolean("camera_active", cameraActive)
            .apply()
        overlayState = overlayState.copy(voiceMode = voiceActive && overlayOwner == "main", liveActive = voiceActive)

        if (!voiceActive && !cameraActive) {
            floatingOverlay?.hide()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val types = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                var mask = 0
                if (voiceActive) {
                    mask = mask or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                    mask = mask or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                }
                if (cameraActive) mask = mask or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                mask
            } else 0
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, buildNotification(), types)
            } else {
                startForeground(NOTIFICATION_ID, buildNotification())
            }
            ensureOverlayVisible()
        } catch (e: SecurityException) {
            voiceActive = false
            cameraActive = false
            floatingOverlay?.hide()
            getSharedPreferences("allbat_session_state", MODE_PRIVATE).edit()
                .putBoolean("voice_active", false)
                .putBoolean("camera_active", false)
                .apply()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun shouldShowFloatingBubble(): Boolean =
        voiceActive && !sessionBubbleVisible && !bubbleHiddenUntilLiveEnds && !mainSurfaceVisible && !assistantSurfaceVisible && !permissionSurfaceVisible

    private fun ensureOverlayVisible() {
        if (!shouldShowFloatingBubble()) {
            mainHandler.removeCallbacks(overlayPermissionPoll)
            overlayPermissionPollActive = false
            overlayPermissionPollCount = 0
            floatingOverlay?.hide()
            return
        }
        if (Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this)) {
            mainHandler.removeCallbacks(overlayPermissionPoll)
            overlayPermissionPollActive = false
            overlayPermissionPollCount = 0
            floatingOverlay?.setVoiceMode(voiceActive && overlayOwner == "main")
            floatingOverlay?.show()
            floatingOverlay?.update(overlayState.copy(voiceMode = voiceActive && overlayOwner == "main", liveActive = voiceActive))
        } else {
            floatingOverlay?.hide()
            if (!overlayPermissionPollActive) {
                overlayPermissionPollActive = true
                overlayPermissionPollCount = 0
                mainHandler.postDelayed(overlayPermissionPoll, 1000L)
            }
        }
    }

    private fun handleOverlayAction(action: String) {
        val fromSystemAssistant = overlayOwner == "system_assistant"
        val broadcastAction = when (action) {
            FloatingAssistantOverlay.ACTION_MIC -> if (fromSystemAssistant) AllBatVoiceInteractionSession.ACTION_OVERLAY_MIC else MainActivity.ACTION_OVERLAY_MIC
            FloatingAssistantOverlay.ACTION_CAMERA -> if (fromSystemAssistant) AllBatVoiceInteractionSession.ACTION_OVERLAY_CAMERA else MainActivity.ACTION_OVERLAY_CAMERA
            FloatingAssistantOverlay.ACTION_SCREEN -> if (fromSystemAssistant) AllBatVoiceInteractionSession.ACTION_OVERLAY_SCREEN else MainActivity.ACTION_OVERLAY_SCREEN
            FloatingAssistantOverlay.ACTION_END -> if (fromSystemAssistant) AllBatVoiceInteractionSession.ACTION_OVERLAY_END else MainActivity.ACTION_OVERLAY_END
            FloatingAssistantOverlay.ACTION_STOP_RESPONSE -> if (fromSystemAssistant) AllBatVoiceInteractionSession.ACTION_OVERLAY_STOP_RESPONSE else MainActivity.ACTION_OVERLAY_STOP_RESPONSE
            FloatingAssistantOverlay.ACTION_OPEN -> MainActivity.ACTION_OVERLAY_OPEN
            FloatingAssistantOverlay.ACTION_COLLAPSE -> null
            else -> null
        }
        if (broadcastAction != null) {
            try { sendBroadcast(Intent(broadcastAction).setPackage(packageName)) }
            catch (error: Exception) { android.util.Log.w("AllBatOverlay", "Could not dispatch overlay action", error) }
        }
        if (action == FloatingAssistantOverlay.ACTION_HIDE_ORB) {
            floatingOverlay?.hide()
        }
        if (action == FloatingAssistantOverlay.ACTION_END) {
            android.os.Handler(mainLooper).postDelayed({
                if (!voiceActive) floatingOverlay?.hide()
            }, 250L)
        }
    }

    private fun buildNotification(): Notification {
        val title = when {
            voiceActive && cameraActive -> "گفت‌وگوی زنده و دوربین فعال‌اند"
            voiceActive -> "گفت‌وگوی زنده فعال است"
            else -> "دوربین زنده فعال است"
        }
        val contentIntent = PendingIntent.getActivity(
            this, 5102,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getActivity(
            this, 5103,
            Intent(this, MainActivity::class.java)
                .setAction(MainActivity.ACTION_STOP_ALL)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_assistant)
            .setContentTitle("All Bat Assistant")
            .setContentText(title)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$title. برای قطع کامل صدا و تصویر، دکمهٔ پایان را بزن."))
            .setContentIntent(contentIntent)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(R.drawable.ic_assistant, "پایان نشست", stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "گفت‌وگوی دستیار", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "اعلان دائمی برای مکالمهٔ زندهٔ شروع‌شده توسط کاربر"
                    setShowBadge(false)
                }
            )
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        voiceActive = false
        cameraActive = false
        getSharedPreferences("allbat_session_state", MODE_PRIVATE).edit()
            .putBoolean("voice_active", false)
            .putBoolean("camera_active", false)
            .apply()
        mainHandler.removeCallbacks(overlayPermissionPoll)
        overlayPermissionPollActive = false
        try { if (overlayReceiverRegistered) unregisterReceiver(overlayReceiver) } catch (_: Exception) { }
        overlayReceiverRegistered = false
        floatingOverlay?.destroy()
        floatingOverlay = null
        super.onDestroy()
    }
}
