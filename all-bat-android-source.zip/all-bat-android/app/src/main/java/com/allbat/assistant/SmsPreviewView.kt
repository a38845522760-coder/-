package com.allbat.assistant

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context.INPUT_METHOD_SERVICE
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Compact, native SMS confirmation card used in both the app and system-assistant surfaces. */
internal class SmsPreviewView(
    context: Context,
    contactName: String,
    phoneNumber: String,
    initialMessage: String,
    private val onCancel: () -> Unit,
    private val onSend: (String) -> Unit
) : LinearLayout(context) {
    private val density = resources.displayMetrics.density
    private val bodyContainer: LinearLayout
    private val preview = TextView(context)
    private val editor = EditText(context)
    private var editing = false

    private fun dp(value: Int): Int = (value * density + 0.5f).toInt()

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(context).apply {
            this.text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            gravity = Gravity.CENTER_VERTICAL
        }

    init {
        orientation = VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(16))
        background = rounded(Color.rgb(239, 243, 250), 26)
        isClickable = true
        isFocusable = true
        // Ignore taps while another app's overlay covers this card, so "Send" cannot be tricked by tapjacking.
        filterTouchesWhenObscured = true

        val header = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val appIcon = TextView(context).apply {
            text = "●"
            textSize = 21f
            setTextColor(Color.rgb(23, 97, 210))
            gravity = Gravity.CENTER
            background = rounded(Color.WHITE, 14)
        }
        header.addView(appIcon, LayoutParams(dp(36), dp(36)))
        header.addView(text("پیامک", 18f, Color.rgb(35, 38, 44), true),
            LayoutParams(0, dp(40), 1f).apply { marginStart = dp(10) })
        val close = text("×", 27f, Color.rgb(90, 94, 102)).apply {
            gravity = Gravity.CENTER
            setOnClickListener { onCancel() }
        }
        header.addView(close, LayoutParams(dp(36), dp(36)))
        addView(header, LayoutParams(LayoutParams.MATCH_PARENT, dp(42)))

        val recipient = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(12))
        }
        val avatar = FrameLayout(context).apply {
            background = rounded(Color.rgb(35, 112, 224), 48)
            val head = View(context).apply { background = rounded(Color.WHITE, 50) }
            addView(head, FrameLayout.LayoutParams(dp(15), dp(15), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = dp(15)
            })
            val shoulders = View(context).apply { background = rounded(Color.WHITE, 50) }
            addView(shoulders, FrameLayout.LayoutParams(dp(31), dp(14), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(12)
            })
        }
        recipient.addView(avatar, LayoutParams(dp(66), dp(66)))
        val recipientText = LinearLayout(context).apply { orientation = VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        recipientText.addView(text(contactName, 19f, Color.rgb(27, 29, 33), true),
            LayoutParams(LayoutParams.MATCH_PARENT, dp(30)))
        val digits = phoneNumber.filter { it.isDigit() || it == '+' }
        val masked = if (digits.length > 4) "•••• ${digits.takeLast(4)}" else "••••"
        recipientText.addView(text(masked, 15f, Color.rgb(60, 63, 68)),
            LayoutParams(LayoutParams.MATCH_PARENT, dp(24)))
        recipient.addView(recipientText, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(14) })
        addView(recipient, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        bodyContainer = LinearLayout(context).apply {
            orientation = VERTICAL
            background = rounded(Color.rgb(230, 235, 246), 26)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            minimumHeight = dp(92)
        }
        preview.apply {
            maxLines = 5
            ellipsize = android.text.TextUtils.TruncateAt.END
            text = initialMessage
            textSize = 19f
            setTextColor(Color.rgb(30, 32, 36))
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            setLineSpacing(dp(3).toFloat(), 1.0f)
        }
        editor.apply {
            setText(initialMessage)
            textSize = 18f
            setTextColor(Color.rgb(30, 32, 36))
            setHintTextColor(Color.GRAY)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.TOP or Gravity.START
            setPadding(0, dp(4), 0, dp(4))
            background = null
            minLines = 2
            maxLines = 5
            visibility = View.GONE
        }
        bodyContainer.addView(preview, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        bodyContainer.addView(editor, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        addView(bodyContainer, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
            bottomMargin = dp(14)
        })

        val buttons = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR // Modify on the left, Send on the right.
            gravity = Gravity.CENTER_VERTICAL
        }
        val modify = TextView(context).apply {
            text = "ویرایش"
            textSize = 18f
            setTextColor(Color.rgb(35, 38, 42))
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(1), Color.rgb(125, 130, 137))
                cornerRadius = dp(38).toFloat()
            }
            setOnClickListener {
                if (!editing) {
                    editor.setText(preview.text)
                    preview.visibility = View.GONE
                    editor.visibility = View.VISIBLE
                    text = "ثبت تغییر"
                    editing = true
                    editor.requestFocus()
                    (context.getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
                        ?.showSoftInput(editor, InputMethodManager.SHOW_IMPLICIT)
                } else {
                    (context.getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
                        ?.hideSoftInputFromWindow(editor.windowToken, 0)
                    preview.text = editor.text?.toString().orEmpty().trim()
                    preview.visibility = View.VISIBLE
                    editor.visibility = View.GONE
                    text = "ویرایش"
                    editing = false
                }
            }
        }
        val send = TextView(context).apply {
            text = "ارسال"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(18, 91, 204), 38)
            setOnClickListener {
                val current = if (editing) editor.text?.toString().orEmpty().trim() else preview.text?.toString().orEmpty().trim()
                if (current.isNotBlank()) onSend(current)
            }
        }
        buttons.addView(modify, LayoutParams(0, dp(56), 1f).apply { marginEnd = dp(8) })
        buttons.addView(send, LayoutParams(0, dp(56), 1f).apply { marginStart = dp(4) })
        addView(buttons, LayoutParams(LayoutParams.MATCH_PARENT, dp(56)))
    }
}
