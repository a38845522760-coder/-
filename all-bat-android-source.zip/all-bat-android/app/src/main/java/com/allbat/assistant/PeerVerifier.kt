package com.allbat.assistant

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import java.security.MessageDigest

/**
 * Checks that another installed app is really ours: the package name alone proves nothing, because a malicious
 * app can take a package name that is not installed yet. The signing certificate cannot be faked.
 */
internal object PeerVerifier {
    /** True when [pinHex] is blank (check disabled on purpose) or [packageName] is signed by that certificate. */
    fun matches(context: Context, packageName: String, pinHex: String): Boolean {
        val pin = pinHex.replace(":", "").trim().lowercase()
        if (pin.isEmpty()) return true
        return signerDigests(context, packageName).contains(pin)
    }

    @Suppress("DEPRECATION")
    private fun signerDigests(context: Context, packageName: String): Set<String> = try {
        val pm = context.packageManager
        val signatures: Array<Signature> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            val signing = info.signingInfo
            when {
                signing == null -> emptyArray()
                signing.hasMultipleSigners() -> signing.apkContentsSigners ?: emptyArray()
                else -> signing.signingCertificateHistory ?: emptyArray()
            }
        } else {
            pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES).signatures ?: emptyArray()
        }
        signatures.map { sha256Hex(it.toByteArray()) }.toSet()
    } catch (_: Exception) {
        emptySet()
    }

    private fun sha256Hex(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}
