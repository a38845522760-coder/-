package com.allbat.assistant

import android.content.Context
import org.json.JSONArray

/** Shared preferences for the wake-phrase preference and local speech transcript profile. */
internal object VoiceAssistantConfig {
    const val PREFS = "allbat_voice_assistant"
    const val KEY_ENABLED = "wake_enabled"
    const val KEY_SPEECH_SAMPLES = "speech_samples_json"
    const val KEY_PROFILE_READY = "speech_profile_ready"
    const val KEY_STATUS = "hotword_status"

    const val STATUS_DISABLED = "disabled"
    const val STATUS_API_UNSUPPORTED = "api_unsupported"

    fun speechSamples(context: Context): ArrayList<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_SPEECH_SAMPLES, null) ?: return arrayListOf()
        return try {
            val json = JSONArray(raw)
            ArrayList<String>(json.length()).apply {
                for (index in 0 until json.length()) {
                    val value = json.optString(index).trim()
                    if (value.isNotEmpty()) add(value.take(240))
                }
            }
        } catch (_: Exception) {
            arrayListOf()
        }
    }

    fun saveSpeechSamples(context: Context, samples: List<String>) {
        val json = JSONArray()
        samples.asSequence().map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(12)
            .forEach { json.put(it) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_SPEECH_SAMPLES, json.toString())
            .putBoolean(KEY_PROFILE_READY, json.length() >= 2)
            .apply()
    }

    fun setStatus(context: Context, status: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_STATUS, status)
            .apply()
    }
}
