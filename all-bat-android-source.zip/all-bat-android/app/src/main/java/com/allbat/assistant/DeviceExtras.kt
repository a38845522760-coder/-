package com.allbat.assistant

import android.Manifest
import android.app.ActivityManager
import android.app.NotificationManager
import android.os.PowerManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.view.KeyEvent
import com.allbat.assistant.PhoneActionEngine.ToolOutcome
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

/** Additional allow-listed tools that need no Google service. Every function validates its own arguments. */
internal object DeviceExtras {
    private val main = Handler(Looper.getMainLooper())

    // ---------------------------------------------------------------- navigation / web / share
    fun navigate(context: Context, destination: String): ToolOutcome {
        if (destination.isBlank() || destination.length > 200) return ToolOutcome(false, "مقصد خالی یا بیش از حد طولانی است.")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(destination)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return ToolOutcome(true, "مقصد «$destination» را در برنامهٔ نقشهٔ گوشی باز می‌کنم.", JSONObject().put("destination", destination), intent)
    }

    fun webSearch(context: Context, query: String, url: String): ToolOutcome {
        val target: Uri = when {
            url.isNotBlank() -> {
                val parsed = Uri.parse(url.trim())
                val scheme = parsed.scheme?.lowercase(Locale.ROOT)
                if ((scheme != "https" && scheme != "http") || parsed.host.isNullOrBlank() || url.length > 500) {
                    return ToolOutcome(false, "فقط نشانی‌های http یا https معتبر باز می‌شوند.")
                }
                parsed
            }
            query.isNotBlank() && query.length <= 300 -> Uri.parse("https://duckduckgo.com/?q=" + Uri.encode(query))
            else -> return ToolOutcome(false, "عبارت جستجو یا نشانی مشخص نیست.")
        }
        val message = if (url.isNotBlank()) "لینک را در مرورگر باز می‌کنم." else "«$query» را در مرورگر جستجو می‌کنم."
        return ToolOutcome(true, message, JSONObject().put("url", target.toString()),
            Intent(Intent.ACTION_VIEW, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun shareText(context: Context, text: String): ToolOutcome {
        if (text.isBlank() || text.length > 4000) return ToolOutcome(false, "متن اشتراک‌گذاری خالی یا بیش از حد طولانی است.")
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        return ToolOutcome(true, "برگهٔ اشتراک‌گذاری اندروید را باز می‌کنم.", JSONObject(),
            Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------------------------------------------------------------- media / ringer
    fun media(context: Context, action: String): ToolOutcome {
        val code = when (action) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "toggle", "play_pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous", "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> return ToolOutcome(false, "عملیات رسانه باید play، pause، toggle، next، previous یا stop باشد.")
        }
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ToolOutcome(true, "فرمان پخش‌کننده ارسال شد.", JSONObject().put("action", action))
    }

    fun ringer(context: Context, mode: String): ToolOutcome {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val target = when (mode) {
            "normal", "ring", "sound" -> AudioManager.RINGER_MODE_NORMAL
            "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
            "silent" -> AudioManager.RINGER_MODE_SILENT
            else -> return ToolOutcome(false, "حالت زنگ باید normal، vibrate یا silent باشد.")
        }
        return try {
            audio.ringerMode = target
            val label = when (target) {
                AudioManager.RINGER_MODE_NORMAL -> "زنگ‌دار"
                AudioManager.RINGER_MODE_VIBRATE -> "لرزش"
                else -> "بی‌صدا"
            }
            ToolOutcome(true, "گوشی روی حالت $label قرار گرفت.", JSONObject().put("mode", mode))
        } catch (_: SecurityException) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (!manager.isNotificationPolicyAccessGranted) {
                ToolOutcome(false, "برای تغییر کامل حالت زنگ، اندروید اجازهٔ «مزاحم نشوید» را می‌خواهد؛ صفحهٔ آن را باز کردم و بعد از فعال‌کردنِ All Bat دوباره بگو.",
                    JSONObject(), Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } else ToolOutcome(false, "اندروید تغییر حالت زنگ را نپذیرفت.")
        }
    }

    // ---------------------------------------------------------------- status / date
    fun deviceStatus(context: Context): ToolOutcome {
        val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        val stat = StatFs(Environment.getDataDirectory().path)
        val freeGb = stat.availableBytes / 1_073_741_824.0
        val totalGb = stat.totalBytes / 1_073_741_824.0

        val memory = ActivityManager.MemoryInfo()
        (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(memory)
        val freeRamMb = memory.availMem / 1_048_576

        var network = "بدون اینترنت"
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
            if (caps != null) network = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi‑Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "اینترنت همراه"
                else -> "متصل"
            }
        } catch (_: Exception) { }

        val ringer = when ((context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> "بی‌صدا"
            AudioManager.RINGER_MODE_VIBRATE -> "لرزش"
            else -> "زنگ‌دار"
        }
        val message = (if (percent >= 0) "باتری $percent٪${if (charging) " (در حال شارژ)" else ""}. " else "") +
            String.format(Locale.US, "حافظهٔ داخلی %.1f گیگابایت آزاد از %.1f. ", freeGb, totalGb) +
            "رم آزاد حدود $freeRamMb مگابایت. اتصال: $network. حالت زنگ: $ringer."
        return ToolOutcome(true, message, JSONObject()
            .put("battery_percent", percent).put("charging", charging)
            .put("storage_free_gb", Math.round(freeGb * 10) / 10.0).put("ram_free_mb", freeRamMb)
            .put("network", network).put("ringer", ringer))
    }

    // ---------------------------------------------------------------- OCR / current visible screen
    fun readScreenText(context: Context): ToolOutcome {
        val service = AllBatAccessibilityService.instance
        if (service == null) {
            return ToolOutcome(false,
                "برای خواندن متن قابل‌دسترسی صفحه، سرویس دسترسی‌پذیری All Bat باید با انتخاب خودت فعال شود. صفحهٔ تنظیمات را باز کردم.",
                JSONObject().put("action", "accessibility_required"),
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        val result = service.readVisibleText()
        val data = JSONObject().put("source", "active_accessibility_window")
        if (result.first) data.put("text", result.second)
        return ToolOutcome(result.first, if (result.first) "متن قابل‌دسترسی صفحه استخراج شد؛ حالا می‌توانم دربارهٔ همین متن توضیح بدهم." else result.second, data)
    }

    fun ocrImageRequest(): ToolOutcome = ToolOutcome(true,
        "یک تصویر را از انتخاب‌گر رسمی اندروید انتخاب کن تا متن آن به‌صورت محلی استخراج شود.",
        JSONObject().put("action", "document_picker_required").put("mime_types", JSONArray(listOf("image/*"))).put("share", false).put("ocr", true))

    // ---------------------------------------------------------------- display settings
    fun setDisplaySettings(context: Context, args: JSONObject): ToolOutcome {
        val action = args.optString("action").trim().lowercase(Locale.ROOT)
        if (action == "status") {
            val brightness = try { Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) } catch (_: Exception) { 128 }
            val mode = try { Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL) } catch (_: Exception) { Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL }
            val timeoutMs = try { Settings.System.getLong(context.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, 30_000L) } catch (_: Exception) { 30_000L }
            val autoRotate = try { Settings.System.getInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1 } catch (_: Exception) { false }
            val percent = (brightness * 100 / 255).coerceIn(0, 100)
            val data = JSONObject().put("brightness_percent", percent).put("automatic_brightness", mode == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC)
                .put("screen_timeout_seconds", (timeoutMs / 1000L).toInt()).put("auto_rotate", autoRotate)
            return ToolOutcome(true, "روشنایی $percent درصد، خاموش‌شدن صفحه پس از ${timeoutMs / 1000L} ثانیه و چرخش خودکار ${if (autoRotate) "روشن" else "خاموش"} است.", data)
        }
        if (action !in setOf("brightness", "timeout", "auto_rotate")) {
            return ToolOutcome(false, "action باید status، brightness، timeout یا auto_rotate باشد.")
        }
        if (!Settings.System.canWrite(context)) {
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return ToolOutcome(false, "برای تغییر تنظیمات نمایشگر، باید اجازهٔ ویژهٔ «تغییر تنظیمات سیستم» را خودت در اندروید فعال کنی؛ بعد از بازگشت، فرمان را دوباره بگو.",
                JSONObject().put("action", "write_settings_required"), intent)
        }
        return try {
            when (action) {
                "brightness" -> {
                    val percent = args.optInt("percent", -1)
                    if (percent !in 1..100) return ToolOutcome(false, "درصد روشنایی باید بین ۱ تا ۱۰۰ باشد.")
                    // Explicit brightness control switches automatic brightness to manual mode.
                    val modeWritten = Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    val valueWritten = Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (percent * 255 / 100).coerceIn(1, 255))
                    if (!modeWritten || !valueWritten) return ToolOutcome(false, "اندروید تغییر روشنایی را نپذیرفت.")
                    ToolOutcome(true, "روشنایی نمایشگر روی $percent درصد تنظیم شد؛ روشنایی خودکار برای این تغییر به حالت دستی رفت.", JSONObject().put("brightness_percent", percent))
                }
                "timeout" -> {
                    val seconds = args.optInt("seconds", -1)
                    if (seconds !in 15..3600) return ToolOutcome(false, "زمان خاموش‌شدن صفحه باید بین ۱۵ تا ۳۶۰۰ ثانیه باشد.")
                    val written = Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, seconds * 1000)
                    if (!written) return ToolOutcome(false, "اندروید تغییر زمان خاموش‌شدن صفحه را نپذیرفت.")
                    ToolOutcome(true, "زمان خاموش‌شدن خودکار صفحه روی $seconds ثانیه تنظیم شد.", JSONObject().put("screen_timeout_seconds", seconds))
                }
                else -> {
                    if (!args.has("enabled")) return ToolOutcome(false, "برای چرخش خودکار باید enabled مشخص شود.")
                    val enabled = args.optBoolean("enabled")
                    val written = Settings.System.putInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (enabled) 1 else 0)
                    if (!written) return ToolOutcome(false, "اندروید تغییر چرخش خودکار را نپذیرفت.")
                    ToolOutcome(true, "چرخش خودکار صفحه ${if (enabled) "روشن" else "خاموش"} شد.", JSONObject().put("auto_rotate", enabled))
                }
            }
        } catch (_: SecurityException) {
            ToolOutcome(false, "اندروید اجازهٔ تغییر تنظیم نمایشگر را نداد؛ دسترسی ویژه را در تنظیمات بررسی کن.")
        } catch (_: Exception) {
            ToolOutcome(false, "تغییر تنظیم نمایشگر انجام نشد.")
        }
    }

    // ---------------------------------------------------------------- Do Not Disturb
    fun setDoNotDisturb(context: Context, mode: String): ToolOutcome {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val target = when (mode) {
            "off" -> NotificationManager.INTERRUPTION_FILTER_ALL
            "priority" -> NotificationManager.INTERRUPTION_FILTER_PRIORITY
            "alarms" -> NotificationManager.INTERRUPTION_FILTER_ALARMS
            "none" -> NotificationManager.INTERRUPTION_FILTER_NONE
            "status" -> manager.currentInterruptionFilter
            else -> return ToolOutcome(false, "mode باید off، priority، alarms، none یا status باشد.")
        }
        val label = when (target) {
            NotificationManager.INTERRUPTION_FILTER_ALL -> "خاموش"
            NotificationManager.INTERRUPTION_FILTER_PRIORITY -> "فقط موارد اولویت‌دار"
            NotificationManager.INTERRUPTION_FILTER_ALARMS -> "فقط زنگ‌های هشدار"
            NotificationManager.INTERRUPTION_FILTER_NONE -> "همهٔ مزاحمت‌ها مسدود"
            else -> "نامشخص"
        }
        if (mode == "status") return ToolOutcome(true, "حالت مزاحم‌نشوید: $label.", JSONObject().put("mode", target).put("label", label))
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return ToolOutcome(false, "این قابلیت به اندروید ۶ یا جدیدتر نیاز دارد.")
        if (!manager.isNotificationPolicyAccessGranted) {
            return ToolOutcome(false, "برای تغییر حالت مزاحم‌نشوید، دسترسی ویژهٔ اعلان‌ها لازم است؛ صفحهٔ رسمی مجوز را باز کردم. پس از فعال‌سازی، فرمان را دوباره بگو.",
                JSONObject().put("action", "notification_policy_required"),
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        return try {
            manager.setInterruptionFilter(target)
            ToolOutcome(true, "حالت مزاحم‌نشوید روی «$label» تنظیم شد.", JSONObject().put("mode", target).put("label", label))
        } catch (_: SecurityException) {
            ToolOutcome(false, "اندروید اجازهٔ تغییر حالت مزاحم‌نشوید را نداد.")
        } catch (_: Exception) {
            ToolOutcome(false, "تغییر حالت مزاحم‌نشوید انجام نشد.")
        }
    }

    // ---------------------------------------------------------------- battery analysis (read-only)
    fun batteryAnalysis(context: Context): ToolOutcome {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return ToolOutcome(false, "وضعیت باتری از اندروید دریافت نشد.")
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val percent = if (level >= 0) (level * 100 / scale).coerceIn(0, 100) else -1
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val healthCode = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        val health = when (healthCode) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "over_voltage"
            BatteryManager.BATTERY_HEALTH_COLD -> "cold"
            else -> "unknown"
        }
        val tempC = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE).let { if (it == Int.MIN_VALUE) null else it / 10.0 }
        val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
        val technology = intent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY).orEmpty().take(40)
        val power = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val saver = power.isPowerSaveMode
        val thermal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) power.currentThermalStatus else -1
        val tips = mutableListOf<String>()
        if (percent in 0..25 && !charging) tips.add("باتری کم است؛ شارژکردن را در اولویت بگذار.")
        if (tempC != null && tempC >= 42.0) tips.add("دمای گزارش‌شده بالاست؛ استفادهٔ سنگین را کم کن و گوشی را در محیط خنک قرار بده.")
        if (saver) tips.add("حالت صرفه‌جویی انرژی روشن است.")
        if (percent >= 80 && !charging) tips.add("وضعیت شارژ برای استفادهٔ عادی مناسب است.")
        if (tips.isEmpty()) tips.add("از داده‌های در دسترس، هشدار مشخصی دیده نمی‌شود.")
        val data = JSONObject().put("battery_percent", percent).put("charging", charging).put("health", health)
            .put("power_save_mode", saver).put("voltage_mv", voltageMv).put("technology", technology)
            .put("thermal_status", thermal).put("recommendations", JSONArray(tips))
        if (tempC != null) data.put("temperature_c", tempC)
        val tempMessage = tempC?.let { " دمای باتری حدود ${String.format(Locale.US, "%.1f", it)} درجه است." }.orEmpty()
        return ToolOutcome(true, "باتری $percent درصد است؛ ${if (charging) "در حال شارژ" else "بدون شارژ"}، سلامت گزارش‌شده: $health.$tempMessage ${tips.joinToString(" ")}", data)
    }

    private val jalaliMonths = arrayOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
    private val weekdays = arrayOf("", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه")

    private fun gregorianToJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + gdm[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31
            jd = 1 + days % 31
        } else {
            jm = 7 + (days - 186) / 30
            jd = 1 + (days - 186) % 30
        }
        return Triple(jy, jm, jd)
    }

    fun dateTime(): ToolOutcome {
        val now = Calendar.getInstance()
        val (jy, jm, jd) = gregorianToJalali(now.get(Calendar.YEAR), now.get(Calendar.MONTH) + 1, now.get(Calendar.DAY_OF_MONTH))
        val time = String.format(Locale.US, "%02d:%02d", now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE))
        val weekday = weekdays[now.get(Calendar.DAY_OF_WEEK)]
        val shamsi = "$weekday $jd ${jalaliMonths[jm - 1]} $jy"
        val gregorian = String.format(Locale.US, "%04d-%02d-%02d", now.get(Calendar.YEAR), now.get(Calendar.MONTH) + 1, now.get(Calendar.DAY_OF_MONTH))
        return ToolOutcome(true, "ساعت $time، $shamsi (میلادی $gregorian).",
            JSONObject().put("time", time).put("jalali", shamsi).put("gregorian", gregorian))
    }

    // ---------------------------------------------------------------- calendar / contacts
    fun listCalendarEvents(context: Context, args: JSONObject): ToolOutcome {
        if (context.checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            return ToolOutcome(false, "برای خواندن برنامهٔ تقویم، مجوز تقویم لازم است.",
                permissions = listOf(Manifest.permission.READ_CALENDAR))
        }
        val daysAhead = args.optInt("days_ahead", 7).coerceIn(1, 30)
        val begin = System.currentTimeMillis()
        val endCalendar = Calendar.getInstance().apply { timeInMillis = begin; add(Calendar.DAY_OF_YEAR, daysAhead) }
        val end = endCalendar.timeInMillis
        val instancesUri = CalendarContract.Instances.CONTENT_URI.buildUpon()
            .appendPath(begin.toString()).appendPath(end.toString()).build()
        val projection = arrayOf(
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.EVENT_LOCATION,
            CalendarContract.Instances.ALL_DAY
        )
        return try {
            val events = JSONArray()
            context.contentResolver.query(instancesUri, projection, null, null,
                "${CalendarContract.Instances.BEGIN} ASC")?.use { cursor ->
                while (cursor.moveToNext() && events.length() < 20) {
                    val title = cursor.getString(0).orEmpty().take(200)
                    val start = cursor.getLong(1)
                    val finish = cursor.getLong(2)
                    val location = cursor.getString(3).orEmpty().take(200)
                    val allDay = cursor.getInt(4) != 0
                    val event = JSONObject()
                        .put("title", title)
                        .put("start_millis", start)
                        .put("end_millis", finish)
                        .put("all_day", allDay)
                    if (location.isNotBlank()) event.put("location", location)
                    events.put(event)
                }
            }
            val msg = if (events.length() == 0) "در $daysAhead روز آینده رویدادی در تقویم پیدا نشد."
                else "${events.length()} رویداد آینده از تقویم خوانده شد."
            ToolOutcome(true, msg, JSONObject().put("events", events).put("days_ahead", daysAhead)
                .put("truncated", events.length() >= 20))
        } catch (_: SecurityException) {
            ToolOutcome(false, "دسترسی به تقویم توسط اندروید تأیید نشد.")
        } catch (_: Exception) {
            ToolOutcome(false, "خواندن رویدادهای تقویم انجام نشد.")
        }
    }

    fun documentPickerRequest(share: Boolean, args: JSONObject): ToolOutcome {
        val category = args.optString("file_type", "any").trim().lowercase(Locale.ROOT)
        val mimeTypes = when (category) {
            "any" -> arrayOf("*/*")
            "pdf" -> arrayOf("application/pdf")
            "text" -> arrayOf("text/plain", "text/markdown", "text/csv", "application/json", "application/xml")
            "document" -> arrayOf("application/pdf", "application/msword",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.oasis.opendocument.text")
            "spreadsheet" -> arrayOf("text/csv", "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.oasis.opendocument.spreadsheet")
            "image" -> arrayOf("image/*")
            "audio" -> arrayOf("audio/*")
            "video" -> arrayOf("video/*")
            else -> return ToolOutcome(false, "نوع فایل پشتیبانی نمی‌شود؛ از any، pdf، text، document، spreadsheet، image، audio یا video استفاده کن.")
        }
        val message = if (share) "انتخاب‌گر امن اندروید برای انتخاب فایلی که می‌خواهی به اشتراک بگذاری باز می‌شود."
            else "انتخاب‌گر امن اندروید برای بازکردن فایل باز می‌شود."
        return ToolOutcome(true, message, JSONObject()
            .put("action", "document_picker_required")
            .put("mime_types", JSONArray(mimeTypes.toList()))
            .put("share", share))
    }

    fun calendarEvent(args: JSONObject): ToolOutcome {
        val title = args.optString("title").trim()
        if (title.isBlank() || title.length > 200) return ToolOutcome(false, "عنوان رویداد خالی یا بیش از حد طولانی است.")
        val intent = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val location = args.optString("location").trim()
        if (location.isNotBlank()) intent.putExtra(CalendarContract.Events.EVENT_LOCATION, location.take(200))
        val description = args.optString("description").trim()
        if (description.isNotBlank()) intent.putExtra(CalendarContract.Events.DESCRIPTION, description.take(1000))
        val start = args.optString("start_iso").trim()
        var detail = ""
        if (start.isNotBlank()) {
            try {
                val begin = java.time.LocalDateTime.parse(start).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
                val minutes = args.optInt("duration_minutes", 60).coerceIn(5, 24 * 60)
                intent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
                intent.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + minutes * 60_000L)
                detail = " برای $start"
            } catch (_: Exception) {
                return ToolOutcome(false, "قالب زمان باید مثل 2026-11-02T15:30 باشد.")
            }
        }
        return ToolOutcome(true, "پیش‌نویس رویداد «$title»$detail در تقویم باز شد؛ ذخیره‌اش با تأیید خودت است.", JSONObject().put("title", title), intent)
    }

    fun addContact(name: String, phone: String): ToolOutcome {
        if (name.isBlank() && phone.isBlank()) return ToolOutcome(false, "نام یا شماره‌ای برای مخاطب جدید گفته نشد.")
        if (name.length > 100 || phone.length > 40) return ToolOutcome(false, "نام یا شماره بیش از حد طولانی است.")
        val intent = Intent(ContactsContract.Intents.Insert.ACTION).setType(ContactsContract.RawContacts.CONTENT_TYPE)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (name.isNotBlank()) intent.putExtra(ContactsContract.Intents.Insert.NAME, name)
        if (phone.isNotBlank()) intent.putExtra(ContactsContract.Intents.Insert.PHONE, phone)
        return ToolOutcome(true, "صفحهٔ افزودن مخاطب با اطلاعات پر‌شده باز شد؛ ذخیره‌اش با تأیید خودت است.", JSONObject(), intent)
    }

    // ---------------------------------------------------------------- find my phone
    @Volatile private var finderRingtone: Ringtone? = null
    @Volatile private var finderRunning = false
    private var savedAlarmVolume = -1
    private val finderStop = Runnable { stopFinder(appContextHolder) }
    private var appContextHolder: Context? = null

    private fun stopFinder(context: Context?) {
        finderRunning = false
        main.removeCallbacks(finderStop)
        try { finderRingtone?.stop() } catch (_: Exception) { }
        finderRingtone = null
        val app = context ?: appContextHolder ?: return
        try {
            val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (savedAlarmVolume >= 0) audio.setStreamVolume(AudioManager.STREAM_ALARM, savedAlarmVolume, 0)
        } catch (_: Exception) { }
        savedAlarmVolume = -1
        setTorchAll(app, false)
    }

    private fun setTorchAll(context: Context, on: Boolean) {
        try {
            val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            manager.cameraIdList.forEach { id ->
                try {
                    if (manager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                        manager.setTorchMode(id, on)
                    }
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
    }

    fun findPhone(context: Context, action: String): ToolOutcome {
        val app = context.applicationContext
        appContextHolder = app
        if (action == "stop") {
            stopFinder(app)
            return ToolOutcome(true, "آلارم پیدا کردن گوشی متوقف شد.")
        }
        if (action != "start" && action.isNotBlank()) return ToolOutcome(false, "action باید start یا stop باشد.")
        if (finderRunning) return ToolOutcome(true, "آلارم پیدا کردن گوشی از قبل روشن است؛ برای قطع، بگو «آلارم پیدا کردن را قطع کن».")
        return try {
            val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            savedAlarmVolume = audio.getStreamVolume(AudioManager.STREAM_ALARM)
            audio.setStreamVolume(AudioManager.STREAM_ALARM, audio.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
            val ringtone = RingtoneManager.getRingtone(app, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                ?: return ToolOutcome(false, "صدای آلارم گوشی در دسترس نیست.")
            ringtone.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            if (Build.VERSION.SDK_INT >= 28) ringtone.isLooping = true
            ringtone.play()
            finderRingtone = ringtone
            finderRunning = true
            var on = false
            val blink = object : Runnable {
                override fun run() {
                    if (!finderRunning) return
                    on = !on
                    setTorchAll(app, on)
                    main.postDelayed(this, 500L)
                }
            }
            main.post(blink)
            main.postDelayed(finderStop, 60_000L)
            ToolOutcome(true, "آلارم پیدا کردن گوشی روشن شد (حداکثر یک دقیقه). برای قطع بگو «آلارم پیدا کردن را قطع کن».")
        } catch (_: Exception) {
            stopFinder(app)
            ToolOutcome(false, "راه‌اندازی آلارم پیدا کردن گوشی ممکن نشد.")
        }
    }

    // ---------------------------------------------------------------- SMS reading
    fun readSms(context: Context, requestedCount: Int): ToolOutcome {
        if (context.checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            return ToolOutcome(false, "برای خواندن پیامک‌ها، مجوز پیامک لازم است.", permissions = listOf(Manifest.permission.READ_SMS))
        }
        val count = requestedCount.coerceIn(1, 5)
        val canLookup = context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        val items = JSONArray()
        val spoken = StringBuilder()
        context.contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body", "date"), null, null, "date DESC")?.use { cursor ->
            while (cursor.moveToNext() && items.length() < count) {
                val address = cursor.getString(0).orEmpty()
                val body = cursor.getString(1).orEmpty().take(400)
                val date = cursor.getLong(2)
                var sender = address
                if (canLookup && address.isNotBlank()) {
                    try {
                        context.contentResolver.query(
                            Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address)),
                            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
                        )?.use { c -> if (c.moveToFirst()) sender = c.getString(0).orEmpty().ifBlank { address } }
                    } catch (_: Exception) { }
                }
                items.put(JSONObject().put("from", sender).put("text", body).put("time", java.text.DateFormat.getDateTimeInstance().format(java.util.Date(date))))
                spoken.append("از $sender: $body. ")
            }
        }
        if (items.length() == 0) return ToolOutcome(true, "پیامکی در صندوق ورودی پیدا نشد.", JSONObject().put("messages", items))
        return ToolOutcome(true, spoken.toString().trim(), JSONObject().put("messages", items))
    }

    // ---------------------------------------------------------------- accessibility & notifications
    fun screenControl(context: Context, args: JSONObject): ToolOutcome {
        val service = AllBatAccessibilityService.instance
        if (service == null) {
            return ToolOutcome(false, "برای کنترل صفحه، سرویس دسترسی‌پذیری All Bat باید در تنظیمات اندروید روشن شود. صفحهٔ آن را باز کردم (در اندروید ۱۳ به بعد ممکن است اول لازم باشد در «اطلاعات برنامه» گزینهٔ «اجازهٔ تنظیمات محدودشده» را بزنی).",
                JSONObject().put("action", "accessibility_required"), Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        val action = args.optString("action").trim().lowercase(Locale.ROOT)
        val text = args.optString("text").trim()
        val result = service.perform(action, text.take(500))
        return ToolOutcome(result.first, result.second, JSONObject().put("action", action))
    }

    fun readNotifications(context: Context, requestedCount: Int): ToolOutcome {
        val listener = AllBatNotificationListener.instance
        if (listener == null) {
            return ToolOutcome(false, "برای خواندن اعلان‌ها باید «دسترسی به اعلان‌ها» برای All Bat روشن شود. صفحهٔ آن را باز کردم.",
                JSONObject().put("action", "notification_access_required"),
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        val count = requestedCount.coerceIn(1, 10)
        val items = JSONArray()
        val spoken = StringBuilder()
        val pm = context.packageManager
        val active = try { listener.activeNotifications?.toList().orEmpty() } catch (_: Exception) { emptyList() }
        for (sbn in active.sortedByDescending { it.postTime }) {
            if (items.length() >= count) break
            if (sbn.packageName == context.packageName || sbn.isOngoing) continue
            val extras = sbn.notification.extras
            val title = extras.getCharSequence("android.title")?.toString().orEmpty()
            val body = extras.getCharSequence("android.text")?.toString().orEmpty()
            if (title.isBlank() && body.isBlank()) continue
            val app = try { pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString() } catch (_: Exception) { sbn.packageName }
            items.put(JSONObject().put("app", app).put("title", title.take(120)).put("text", body.take(300)))
            spoken.append("$app: $title ${body.take(160)}. ")
        }
        if (items.length() == 0) return ToolOutcome(true, "اعلان تازه‌ای وجود ندارد.", JSONObject().put("notifications", items))
        return ToolOutcome(true, spoken.toString().trim(), JSONObject().put("notifications", items))
    }
}
