package com.allbat.assistant

import android.Manifest
import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.view.KeyEvent
import com.allbat.assistant.PhoneActionEngine.ToolOutcome
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

/** Additional allow-listed tools that need no Google service. Every function validates its own arguments. */
internal object DeviceExtras {
    private val main = Handler(Looper.getMainLooper())

    // ---------------------------------------------------------------- navigation / web / share
    fun navigate(context: Context, destination: String): ToolOutcome {
        if (destination.isBlank() || destination.length > 200) return ToolOutcome(false, "مقصد خالی یا بیش از حد طولانی است.")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(destination)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return ToolOutcome(true, "مقصد «$destination» را در برنامهٔ نقشهٔ گوشی باز می‌کنم.", JSONObject().put("destination", destination), intent)
    }

    fun webSearch(context: Context, query: String, url: String): ToolOutcome {
        val target: Uri = when {
            url.isNotBlank() -> {
                val parsed = Uri.parse(url.trim())
                val scheme = parsed.scheme?.lowercase(Locale.ROOT)
                if ((scheme != "https" && scheme != "http") || parsed.host.isNullOrBlank() || url.length > 500) {
                    return ToolOutcome(false, "فقط نشانی‌های http یا https معتبر باز می‌شوند.")
                }
                parsed
            }
            query.isNotBlank() && query.length <= 300 -> Uri.parse("https://duckduckgo.com/?q=" + Uri.encode(query))
            else -> return ToolOutcome(false, "عبارت جستجو یا نشانی مشخص نیست.")
        }
        val message = if (url.isNotBlank()) "لینک را در مرورگر باز می‌کنم." else "«$query» را در مرورگر جستجو می‌کنم."
        return ToolOutcome(true, message, JSONObject().put("url", target.toString()),
            Intent(Intent.ACTION_VIEW, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun shareText(context: Context, text: String): ToolOutcome {
        if (text.isBlank() || text.length > 4000) return ToolOutcome(false, "متن اشتراک‌گذاری خالی یا بیش از حد طولانی است.")
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        return ToolOutcome(true, "برگهٔ اشتراک‌گذاری اندروید را باز می‌کنم.", JSONObject(),
            Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------------------------------------------------------------- media / ringer
    fun media(context: Context, action: String): ToolOutcome {
        val code = when (action) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "toggle", "play_pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous", "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> return ToolOutcome(false, "عملیات رسانه باید play، pause، toggle، next، previous یا stop باشد.")
        }
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ToolOutcome(true, "فرمان پخش‌کننده ارسال شد.", JSONObject().put("action", action))
    }

    fun ringer(context: Context, mode: String): ToolOutcome {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val target = when (mode) {
            "normal", "ring", "sound" -> AudioManager.RINGER_MODE_NORMAL
            "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
            "silent" -> AudioManager.RINGER_MODE_SILENT
            else -> return ToolOutcome(false, "حالت زنگ باید normal، vibrate یا silent باشد.")
        }
        return try {
            audio.ringerMode = target
            val label = when (target) {
                AudioManager.RINGER_MODE_NORMAL -> "زنگ‌دار"
                AudioManager.RINGER_MODE_VIBRATE -> "لرزش"
                else -> "بی‌صدا"
            }
            ToolOutcome(true, "گوشی روی حالت $label قرار گرفت.", JSONObject().put("mode", mode))
        } catch (_: SecurityException) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (!manager.isNotificationPolicyAccessGranted) {
                ToolOutcome(false, "برای تغییر کامل حالت زنگ، اندروید اجازهٔ «مزاحم نشوید» را می‌خواهد؛ صفحهٔ آن را باز کردم و بعد از فعال‌کردنِ All Bat دوباره بگو.",
                    JSONObject(), Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } else ToolOutcome(false, "اندروید تغییر حالت زنگ را نپذیرفت.")
        }
    }

    // ---------------------------------------------------------------- status / date
    fun deviceStatus(context: Context): ToolOutcome {
        val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        val stat = StatFs(Environment.getDataDirectory().path)
        val freeGb = stat.availableBytes / 1_073_741_824.0
        val totalGb = stat.totalBytes / 1_073_741_824.0

        val memory = ActivityManager.MemoryInfo()
        (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(memory)
        val freeRamMb = memory.availMem / 1_048_576

        var network = "بدون اینترنت"
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
            if (caps != null) network = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi‑Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "اینترنت همراه"
                else -> "متصل"
            }
        } catch (_: Exception) { }

        val ringer = when ((context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> "بی‌صدا"
            AudioManager.RINGER_MODE_VIBRATE -> "لرزش"
            else -> "زنگ‌دار"
        }
        val message = (if (percent >= 0) "باتری $percent٪${if (charging) " (در حال شارژ)" else ""}. " else "") +
            String.format(Locale.US, "حافظهٔ داخلی %.1f گیگابایت آزاد از %.1f. ", freeGb, totalGb) +
            "رم آزاد حدود $freeRamMb مگابایت. اتصال: $network. حالت زنگ: $ringer."
        return ToolOutcome(true, message, JSONObject()
            .put("battery_percent", percent).put("charging", charging)
            .put("storage_free_gb", Math.round(freeGb * 10) / 10.0).put("ram_free_mb", freeRamMb)
            .put("network", network).put("ringer", ringer))
    }

    private val jalaliMonths = arrayOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
    private val weekdays = arrayOf("", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه")

    private fun gregorianToJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + gdm[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31
            jd = 1 + days % 31
        } else {
            jm = 7 + (days - 186) / 30
            jd = 1 + (days - 186) % 30
        }
        return Triple(jy, jm, jd)
    }

    fun dateTime(): ToolOutcome {
        val now = Calendar.getInstance()
        val (jy, jm, jd) = gregorianToJalali(now.get(Calendar.YEAR), now.get(Calendar.MONTH) + 1, now.get(Calendar.DAY_OF_MONTH))
        val time = String.format(Locale.US, "%02d:%02d", now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE))
        val weekday = weekdays[now.get(Calendar.DAY_OF_WEEK)]
        val shamsi = "$weekday $jd ${jalaliMonths[jm - 1]} $jy"
        val gregorian = String.format(Locale.US, "%04d-%02d-%02d", now.get(Calendar.YEAR), now.get(Calendar.MONTH) + 1, now.get(Calendar.DAY_OF_MONTH))
        return ToolOutcome(true, "ساعت $time، $shamsi (میلادی $gregorian).",
            JSONObject().put("time", time).put("jalali", shamsi).put("gregorian", gregorian))
    }

    // ---------------------------------------------------------------- calendar / contacts
    fun calendarEvent(args: JSONObject): ToolOutcome {
        val title = args.optString("title").trim()
        if (title.isBlank() || title.length > 200) return ToolOutcome(false, "عنوان رویداد خالی یا بیش از حد طولانی است.")
        val intent = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val location = args.optString("location").trim()
        if (location.isNotBlank()) intent.putExtra(CalendarContract.Events.EVENT_LOCATION, location.take(200))
        val description = args.optString("description").trim()
        if (description.isNotBlank()) intent.putExtra(CalendarContract.Events.DESCRIPTION, description.take(1000))
        val start = args.optString("start_iso").trim()
        var detail = ""
        if (start.isNotBlank()) {
            try {
                val begin = java.time.LocalDateTime.parse(start).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
                val minutes = args.optInt("duration_minutes", 60).coerceIn(5, 24 * 60)
                intent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
                intent.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + minutes * 60_000L)
                detail = " برای $start"
            } catch (_: Exception) {
                return ToolOutcome(false, "قالب زمان باید مثل 2026-11-02T15:30 باشد.")
            }
        }
        return ToolOutcome(true, "پیش‌نویس رویداد «$title»$detail در تقویم باز شد؛ ذخیره‌اش با تأیید خودت است.", JSONObject().put("title", title), intent)
    }

    fun addContact(name: String, phone: String): ToolOutcome {
        if (name.isBlank() && phone.isBlank()) return ToolOutcome(false, "نام یا شماره‌ای برای مخاطب جدید گفته نشد.")
        if (name.length > 100 || phone.length > 40) return ToolOutcome(false, "نام یا شماره بیش از حد طولانی است.")
        val intent = Intent(ContactsContract.Intents.Insert.ACTION).setType(ContactsContract.RawContacts.CONTENT_TYPE)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (name.isNotBlank()) intent.putExtra(ContactsContract.Intents.Insert.NAME, name)
        if (phone.isNotBlank()) intent.putExtra(ContactsContract.Intents.Insert.PHONE, phone)
        return ToolOutcome(true, "صفحهٔ افزودن مخاطب با اطلاعات پر‌شده باز شد؛ ذخیره‌اش با تأیید خودت است.", JSONObject(), intent)
    }

    // ---------------------------------------------------------------- find my phone
    @Volatile private var finderRingtone: Ringtone? = null
    @Volatile private var finderRunning = false
    private var savedAlarmVolume = -1
    private val finderStop = Runnable { stopFinder(appContextHolder) }
    private var appContextHolder: Context? = null

    private fun stopFinder(context: Context?) {
        finderRunning = false
        main.removeCallbacks(finderStop)
        try { finderRingtone?.stop() } catch (_: Exception) { }
        finderRingtone = null
        val app = context ?: appContextHolder ?: return
        try {
            val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (savedAlarmVolume >= 0) audio.setStreamVolume(AudioManager.STREAM_ALARM, savedAlarmVolume, 0)
        } catch (_: Exception) { }
        savedAlarmVolume = -1
        setTorchAll(app, false)
    }

    private fun setTorchAll(context: Context, on: Boolean) {
        try {
            val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            manager.cameraIdList.forEach { id ->
                try {
                    if (manager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                        manager.setTorchMode(id, on)
                    }
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
    }

    fun findPhone(context: Context, action: String): ToolOutcome {
        val app = context.applicationContext
        appContextHolder = app
        if (action == "stop") {
            stopFinder(app)
            return ToolOutcome(true, "آلارم پیدا کردن گوشی متوقف شد.")
        }
        if (action != "start" && action.isNotBlank()) return ToolOutcome(false, "action باید start یا stop باشد.")
        if (finderRunning) return ToolOutcome(true, "آلارم پیدا کردن گوشی از قبل روشن است؛ برای قطع، بگو «آلارم پیدا کردن را قطع کن».")
        return try {
            val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            savedAlarmVolume = audio.getStreamVolume(AudioManager.STREAM_ALARM)
            audio.setStreamVolume(AudioManager.STREAM_ALARM, audio.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
            val ringtone = RingtoneManager.getRingtone(app, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                ?: return ToolOutcome(false, "صدای آلارم گوشی در دسترس نیست.")
            ringtone.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            if (Build.VERSION.SDK_INT >= 28) ringtone.isLooping = true
            ringtone.play()
            finderRingtone = ringtone
            finderRunning = true
            var on = false
            val blink = object : Runnable {
                override fun run() {
                    if (!finderRunning) return
                    on = !on
                    setTorchAll(app, on)
                    main.postDelayed(this, 500L)
                }
            }
            main.post(blink)
            main.postDelayed(finderStop, 60_000L)
            ToolOutcome(true, "آلارم پیدا کردن گوشی روشن شد (حداکثر یک دقیقه). برای قطع بگو «آلارم پیدا کردن را قطع کن».")
        } catch (_: Exception) {
            stopFinder(app)
            ToolOutcome(false, "راه‌اندازی آلارم پیدا کردن گوشی ممکن نشد.")
        }
    }

    // ---------------------------------------------------------------- SMS reading
    fun readSms(context: Context, requestedCount: Int): ToolOutcome {
        if (context.checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            return ToolOutcome(false, "برای خواندن پیامک‌ها، مجوز پیامک لازم است.", permissions = listOf(Manifest.permission.READ_SMS))
        }
        val count = requestedCount.coerceIn(1, 5)
        val canLookup = context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        val items = JSONArray()
        val spoken = StringBuilder()
        context.contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body", "date"), null, null, "date DESC")?.use { cursor ->
            while (cursor.moveToNext() && items.length() < count) {
                val address = cursor.getString(0).orEmpty()
                val body = cursor.getString(1).orEmpty().take(400)
                val date = cursor.getLong(2)
                var sender = address
                if (canLookup && address.isNotBlank()) {
                    try {
                        context.contentResolver.query(
                            Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address)),
                            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
                        )?.use { c -> if (c.moveToFirst()) sender = c.getString(0).orEmpty().ifBlank { address } }
                    } catch (_: Exception) { }
                }
                items.put(JSONObject().put("from", sender).put("text", body).put("time", java.text.DateFormat.getDateTimeInstance().format(java.util.Date(date))))
                spoken.append("از $sender: $body. ")
            }
        }
        if (items.length() == 0) return ToolOutcome(true, "پیامکی در صندوق ورودی پیدا نشد.", JSONObject().put("messages", items))
        return ToolOutcome(true, spoken.toString().trim(), JSONObject().put("messages", items))
    }

    // ---------------------------------------------------------------- accessibility & notifications
    fun screenControl(context: Context, args: JSONObject): ToolOutcome {
        val service = AllBatAccessibilityService.instance
        if (service == null) {
            return ToolOutcome(false, "برای کنترل صفحه، سرویس دسترسی‌پذیری All Bat باید در تنظیمات اندروید روشن شود. صفحهٔ آن را باز کردم (در اندروید ۱۳ به بعد ممکن است اول لازم باشد در «اطلاعات برنامه» گزینهٔ «اجازهٔ تنظیمات محدودشده» را بزنی).",
                JSONObject().put("action", "accessibility_required"), Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        val action = args.optString("action").trim().lowercase(Locale.ROOT)
        val text = args.optString("text").trim()
        val result = service.perform(action, text.take(500))
        return ToolOutcome(result.first, result.second, JSONObject().put("action", action))
    }

    fun readNotifications(context: Context, requestedCount: Int): ToolOutcome {
        val listener = AllBatNotificationListener.instance
        if (listener == null) {
            return ToolOutcome(false, "برای خواندن اعلان‌ها باید «دسترسی به اعلان‌ها» برای All Bat روشن شود. صفحهٔ آن را باز کردم.",
                JSONObject().put("action", "notification_access_required"),
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        val count = requestedCount.coerceIn(1, 10)
        val items = JSONArray()
        val spoken = StringBuilder()
        val pm = context.packageManager
        val active = try { listener.activeNotifications?.toList().orEmpty() } catch (_: Exception) { emptyList() }
        for (sbn in active.sortedByDescending { it.postTime }) {
            if (items.length() >= count) break
            if (sbn.packageName == context.packageName || sbn.isOngoing) continue
            val extras = sbn.notification.extras
            val title = extras.getCharSequence("android.title")?.toString().orEmpty()
            val body = extras.getCharSequence("android.text")?.toString().orEmpty()
            if (title.isBlank() && body.isBlank()) continue
            val app = try { pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString() } catch (_: Exception) { sbn.packageName }
            items.put(JSONObject().put("app", app).put("title", title.take(120)).put("text", body.take(300)))
            spoken.append("$app: $title ${body.take(160)}. ")
        }
        if (items.length() == 0) return ToolOutcome(true, "اعلان تازه‌ای وجود ندارد.", JSONObject().put("notifications", items))
        return ToolOutcome(true, spoken.toString().trim(), JSONObject().put("notifications", items))
    }
}
