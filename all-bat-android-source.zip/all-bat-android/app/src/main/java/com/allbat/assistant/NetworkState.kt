package com.allbat.assistant

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/** Cheap, permission-light connectivity check used to decide between online AI and offline commands. */
object NetworkState {
    fun isOnline(context: Context): Boolean {
        return try {
            val manager = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return true
            val network = manager.activeNetwork ?: return false
            val caps = manager.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (_: Exception) {
            true
        }
    }
}
