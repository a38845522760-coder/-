package com.allbat.assistant

import android.Manifest
import android.os.Build
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Gravity
import android.view.Window
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.animation.ValueAnimator
import android.view.animation.AccelerateDecelerateInterpolator
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.EditText
import android.text.Editable
import android.text.TextWatcher
import android.view.inputmethod.EditorInfo
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.widget.Toast
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.min

/**
 * Text-first assistant surface. The system screenshot is supplied by VoiceInteractionSession;
 * it is never started through MediaProjection and is never sent whole to the model. The user
 * chooses a rectangle in the web UI, and only that cropped image is attached to the draft.
 */
class AllBatVoiceInteractionSession(context: Context) : android.service.voice.VoiceInteractionSession(context) {
    companion object {
        const val ACTION_OVERLAY_MIC = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_TOGGLE_MIC"
        const val ACTION_OVERLAY_CAMERA = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_TOGGLE_CAMERA"
        const val ACTION_OVERLAY_SCREEN = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_TOGGLE_SCREEN"
        const val ACTION_OVERLAY_END = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_END_SESSION"
        const val ACTION_OVERLAY_STOP_RESPONSE = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_STOP_RESPONSE"
        // Texts taken verbatim from the reference design.
        const val DOCK_HINT = "Ask anything......."
    }

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private var assistantWebView: WebView? = null
    private var pageLoaded = false
    private var visible = false
    private var stopRequestedByUser = false
    private var sessionVoiceServiceStarted = false
    private var sessionCameraServiceStarted = false
    private var previousAudioMode: Int? = null
    private var voiceAudioFocusRequest: AudioFocusRequest? = null
    private val voiceAudioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { _ -> /* Keep duplex Live audio active; Chromium owns the stream lifecycle. */ }
    private var pendingScreenshotDataUrl: String? = null
    private var overlayReceiverRegistered = false
    private var assistantRoot: FrameLayout? = null
    private var assistantCard: FrameLayout? = null
    private var assistantDock: LinearLayout? = null
    private var assistantBackButton: View? = null
    private var assistantCloseButton: View? = null
    private var assistantOrb: OrbView? = null
    private var cardBackground: GradientDrawable? = null
    private var navigationInsetPx = 0
    private var keyboardVisible = false
    private var keyboardOverlapPx = 0
    private var imeInsetPx = 0
    private var baselineRootHeight = 0
    private var keyboardWatchUntil = 0L
    private var lastRootHeight = 0
    private var screenSelectionMode = false
    private var liveMode = false
    private var liveStartedAt = 0L
    private var contentHeightPx = 0
    private var liveText: TextView? = null
    private var composerInput: EditText? = null
    private var dockSendButton: View? = null
    private var dockStopResponseButton: View? = null
    private var dockStopButton: View? = null
    private var commandRecognitionForDictation = false
    private var dictationBaseText = ""
    private var liveStopRequestedAt = 0L
    private var textCard: FrameLayout? = null
    private var textScroll: BoundedScrollView? = null
    private var textView: TextView? = null
    private var smsConfirmationView: SmsPreviewView? = null
    private var smsPreviousPanelVisibility: Int = View.VISIBLE
    private var smsPreviousTextVisibility: Int = View.VISIBLE
    private var panelAnswerText = ""
    private var panelThinking = false
    private var panelGenerating = false
    private var dockHomeButton: View? = null
    private var dockMicButton: View? = null
    private var commandRecognizer: SpeechRecognizer? = null
    private var permissionReceiverRegistered = false
    private val commandSpeechTimeout = Runnable {
        if (commandRecognizer != null) {
            val dictation = commandRecognitionForDictation
            stopCommandSpeechRecognition()
            if (visible && dictation) {
                Toast.makeText(appContext, "زمان ضبط گفتار تمام شد؛ دوباره میکروفون را بزن.", Toast.LENGTH_SHORT).show()
            } else if (visible) {
                panelAnswerText = "زمان شنیدن تمام شد؛ دوباره دستیار را فراخوانی کن یا فرمان را بنویس."
                panelThinking = false
                refreshPanelText()
            }
        }
    }

    private val audioPermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == PhoneActionPermissionActivity.ACTION_AUDIO_PERMISSION_GRANTED && visible) {
                mainHandler.postDelayed({ startCommandSpeechRecognition(forDictation = commandRecognitionForDictation) }, 250L)
            }
        }
    }

    private val sessionOverlayReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val script = when (intent?.action) {
                ACTION_OVERLAY_MIC -> "window.__allbatToggleMicrophone && window.__allbatToggleMicrophone();"
                ACTION_OVERLAY_CAMERA -> "window.__allbatToggleCamera && window.__allbatToggleCamera();"
                ACTION_OVERLAY_SCREEN -> "window.__allbatToggleScreen && window.__allbatToggleScreen();"
                ACTION_OVERLAY_END -> {
                    stopRequestedByUser = true
                    "window.__assistantNativeStopAll && window.__assistantNativeStopAll();"
                }
                ACTION_OVERLAY_STOP_RESPONSE -> "window.__allbatStopCurrentResponse && window.__allbatStopCurrentResponse();"
                else -> return
            }
            evaluate(script)
            if (intent?.action == ACTION_OVERLAY_END) {
                try { SessionServiceControl.send(appContext, SessionForegroundService.ACTION_STOP_ALL) } catch (_: Exception) { }
            }
        }
    }

    private fun registerSessionOverlayReceiver() {
        if (overlayReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(ACTION_OVERLAY_MIC)
            addAction(ACTION_OVERLAY_CAMERA)
            addAction(ACTION_OVERLAY_SCREEN)
            addAction(ACTION_OVERLAY_END)
            addAction(ACTION_OVERLAY_STOP_RESPONSE)
        }
        try {
            ContextCompat.registerReceiver(appContext, sessionOverlayReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            overlayReceiverRegistered = true
        } catch (error: Exception) {
            android.util.Log.w("AllBatOverlay", "Could not register system-assistant overlay controls", error)
        }
        if (!permissionReceiverRegistered) {
            try {
                ContextCompat.registerReceiver(
                    appContext, audioPermissionReceiver,
                    IntentFilter(PhoneActionPermissionActivity.ACTION_AUDIO_PERMISSION_GRANTED),
                    ContextCompat.RECEIVER_NOT_EXPORTED
                )
                permissionReceiverRegistered = true
            } catch (error: Exception) {
                android.util.Log.w("AllBatAssistant", "Could not register microphone permission callback", error)
            }
        }
    }

    override fun onCreateContentView(): View {
        registerSessionOverlayReceiver()
        // Full-screen transparent layer: dark chat card on top, dock at the bottom.
        // The layout is forced LTR so the controls keep the exact positions of the reference design.
        val root = FrameLayout(context).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setOnClickListener { hide() } // tapping outside the card/dock closes the panel
            layoutTransition = android.animation.LayoutTransition().apply {
                val easing = PathInterpolator(0.22f, 0.0f, 0.0f, 1.0f)
                setDuration(android.animation.LayoutTransition.APPEARING, 190L)
                setDuration(android.animation.LayoutTransition.DISAPPEARING, 150L)
                setDuration(android.animation.LayoutTransition.CHANGE_APPEARING, 190L)
                setDuration(android.animation.LayoutTransition.CHANGE_DISAPPEARING, 170L)
                setInterpolator(android.animation.LayoutTransition.APPEARING, easing)
                setInterpolator(android.animation.LayoutTransition.DISAPPEARING, easing)
                setInterpolator(android.animation.LayoutTransition.CHANGE_APPEARING, easing)
                setInterpolator(android.animation.LayoutTransition.CHANGE_DISAPPEARING, easing)
                enableTransitionType(android.animation.LayoutTransition.APPEARING)
                enableTransitionType(android.animation.LayoutTransition.DISAPPEARING)
                enableTransitionType(android.animation.LayoutTransition.CHANGE_APPEARING)
                enableTransitionType(android.animation.LayoutTransition.CHANGE_DISAPPEARING)
            }
        }
        assistantRoot = root
        cardBackground = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.rgb(255, 255, 255), Color.rgb(247, 248, 252))
        ).apply { cornerRadius = dp(28).toFloat() }
        val card = FrameLayout(context).apply {
            background = cardBackground
            clipToOutline = true
            elevation = dp(10).toFloat()
            isClickable = true
        }
        assistantCard = card
        root.addView(
            card,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, defaultCardHeightPx(), Gravity.BOTTOM).apply {
                setMargins(dp(14), 0, dp(14), dp(92))
            }
        )


        val web = WebView(context).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                cacheMode = WebSettings.LOAD_DEFAULT
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                allowFileAccess = false
                allowContentAccess = false
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                safeBrowsingEnabled = true
                loadsImagesAutomatically = true
            }
            addJavascriptInterface(SessionBridge(), "AndroidAssistant")
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    mainHandler.post {
                        val origin = request.origin
                        if (!origin.scheme.equals("https", true) || !origin.host.equals(BuildConfig.SPACE_HOST, true)) {
                            request.deny()
                            return@post
                        }
                        val allowed = request.resources.filter { resource ->
                            when (resource) {
                                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                                else -> false
                            }
                        }.toTypedArray()
                        if (allowed.isNotEmpty()) request.grant(allowed) else request.deny()
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    if (uri.scheme.equals("https", true) && uri.host.equals(BuildConfig.SPACE_HOST, true)) return false
                    if (uri.scheme.equals("about", true) || uri.scheme.equals("blob", true) || uri.scheme.equals("data", true)) return false
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    pageLoaded = true
                    if (visible) evaluate("window.__allbatAssistantPanelMode && window.__allbatAssistantPanelMode(true);")
                    deliverPendingScreenshot()
                }
            }
        }
        assistantWebView = web
        ScreenCaptureService.frameSink = { frame ->
            mainHandler.post {
                if (pageLoaded && assistantWebView != null) {
                    assistantWebView?.evaluateJavascript(
                        "window.__assistantNativeFrame && window.__assistantNativeFrame(${JSONObject.quote(frame)});",
                        null
                    )
                }
            }
        }
        ScreenCaptureService.statusSink = { active ->
            mainHandler.post {
                if (assistantWebView != null) {
                    val function = if (active) "__assistantNativeScreenStarted" else "__assistantNativeScreenStopped"
                    assistantWebView?.evaluateJavascript("window.$function && window.$function();", null)
                }
            }
        }
        ScreenProjectionPermissionActivity.resultSink = { granted ->
            if (!granted) evaluate("window.__assistantNativeScreenDenied && window.__assistantNativeScreenDenied();")
        }
        card.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val backButton = chromeButton(R.drawable.ic_assistant_back, "Back") { hide() }
        card.addView(backButton, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.LEFT).apply { setMargins(dp(10), dp(10), 0, 0) })
        val closeButton = chromeButton(R.drawable.ic_assistant_close, "Close") { closeAssistant() }
        card.addView(closeButton, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.RIGHT).apply { setMargins(0, dp(10), dp(10), 0) })
        backButton.setColorFilter(Color.rgb(32, 33, 36))
        closeButton.setColorFilter(Color.rgb(32, 33, 36))
        assistantBackButton = backButton
        assistantCloseButton = closeButton
        root.addView(
            buildDock(),
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(78), Gravity.BOTTOM).apply { setMargins(dp(14), 0, dp(14), dp(12)) }
        )
        root.addView(buildTextCard(), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            setMargins(dp(14), 0, dp(14), dp(92))
        })
        // Transparent top layer: a swipe on the visible screen (outside the assistant controls)
        // starts region selection directly; a short outside tap keeps the existing dismiss action.
        root.addView(createScreenSelectionGestureLayer(), FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        installSystemInsetTracking(root)

        try {
            val html = appContext.assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            web.loadDataWithBaseURL(BuildConfig.SPACE_BASE_URL, html, "text/html", "UTF-8", null)
        } catch (error: Exception) {
            val safeError = error.javaClass.simpleName
            web.loadDataWithBaseURL(
                BuildConfig.SPACE_BASE_URL,
                "<!doctype html><html lang='fa' dir='rtl'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><body style='font-family:system-ui;padding:24px'><h3>رابط دستیار بارگذاری نشد</h3><p>ساخت برنامه را بررسی کن.</p><code>$safeError</code></body></html>",
                "text/html", "UTF-8", null
            )
        }
        return root
    }

    override fun onComputeInsets(outInsets: android.service.voice.VoiceInteractionSession.Insets) {
        super.onComputeInsets(outInsets)
        // Keep the underlying app full-size: the assistant is a floating layer, not a split view.
        outInsets.contentInsets.set(0, 0, 0, 0)
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        visible = true
        screenSelectionMode = false
        assistantWebView?.onResume()
        try {
            window?.setCancelable(true)
            window?.setCanceledOnTouchOutside(true)
            val activityWindow: Window? = window?.window
            activityWindow?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            activityWindow?.setWindowAnimations(R.style.AssistantSheetWindowAnimation)
            activityWindow?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
            activityWindow?.setGravity(Gravity.BOTTOM)
            val windowParams = activityWindow?.attributes
            if (windowParams != null) {
                windowParams.gravity = Gravity.BOTTOM
                windowParams.dimAmount = 0f
                windowParams.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                activityWindow.attributes = windowParams
            }
            relayoutAssistant()
        } catch (error: Exception) {
            android.util.Log.w("AllBatAssistant", "Could not configure assistant sheet window", error)
        }
        stopRequestedByUser = false
        liveMode = false
        composerInput?.setText("")
        panelAnswerText = ""
        panelThinking = false
        panelGenerating = false
        refreshPanelText()
        publishAssistantSurfaceVisibility(true)
        // A system invocation starts one explicit, one-shot speech capture. It stops as soon as
        // one utterance is received or the assistant surface is hidden; this is not hotword listening.
        if (pageLoaded) evaluate("window.__allbatAssistantPanelMode && window.__allbatAssistantPanelMode(true);")
        try { appContext.sendBroadcast(Intent(SessionForegroundService.ACTION_REFRESH_OVERLAY).setPackage(appContext.packageName)) } catch (_: Exception) { }
        deliverPendingScreenshot()
        mainHandler.postDelayed({ startCommandSpeechRecognition() }, 350L)
    }

    private fun startCommandSpeechRecognition(forDictation: Boolean = false) {
        if (!visible || liveMode || screenSelectionMode) return
        stopCommandSpeechRecognition()
        commandRecognitionForDictation = forDictation
        dictationBaseText = composerInput?.text?.toString().orEmpty().trim()
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            if (!forDictation) {
                panelAnswerText = "برای فرمان صوتی، مجوز میکروفون لازم است. در پنجرهٔ اندروید آن را فعال کن."
                panelThinking = false
                refreshPanelText()
            } else {
                Toast.makeText(appContext, "برای تبدیل گفتار به متن، مجوز میکروفون لازم است.", Toast.LENGTH_SHORT).show()
            }
            launchFromAssistant(Intent(appContext, PhoneActionPermissionActivity::class.java).apply {
                putExtra(PhoneActionPermissionActivity.EXTRA_PERMISSION, Manifest.permission.RECORD_AUDIO)
            })
            return
        }
        val provider = PhoneActionEngine.findNonGoogleRecognitionService(appContext)
        val online = NetworkState.isOnline(appContext)
        val offlineReady = OfflineSpeechModel.isInstalled(appContext)
        if ((!online || provider == null) && offlineReady) {
            startOfflineCommandRecognition(forDictation)
            return
        }
        if (!online && !offlineReady) {
            commandRecognitionForDictation = false
            if (forDictation) Toast.makeText(appContext, "اینترنت وصل نیست و موتور صوتی آفلاین نصب نشده است.", Toast.LENGTH_LONG).show()
            else {
                panelAnswerText = "اینترنت وصل نیست و موتور صوتی آفلاین هنوز نصب نشده. فرمان را بنویس؛ و وقتی آنلاین بودی بگو «موتور صوتی آفلاین را نصب کن» تا دفعهٔ بعد صوتی هم کار کند."
                panelThinking = false
                refreshPanelText()
            }
            return
        }
        if (provider == null) {
            commandRecognitionForDictation = false
            if (forDictation) Toast.makeText(appContext, "موتور تبدیل گفتار دستگاه پیدا نشد.", Toast.LENGTH_LONG).show()
            else {
                panelAnswerText = "روی این گوشی موتور تشخیص گفتارِ غیرگوگلی پیدا نشد. می‌توانی فرمان را بنویسی، یا (با اینترنت) بگویی «موتور صوتی آفلاین را نصب کن»."
                panelThinking = false
                refreshPanelText()
            }
            return
        }
        try {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(appContext, provider)
            commandRecognizer = recognizer
            if (!forDictation) {
                panelAnswerText = "گوش می‌دهم…"
                panelThinking = false
                refreshPanelText()
            } else {
                Toast.makeText(appContext, "گوش می‌دهم؛ بعد از صحبت، متن در کادر پیام قرار می‌گیرد.", Toast.LENGTH_SHORT).show()
            }
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    if (visible && !commandRecognitionForDictation) {
                        panelAnswerText = "گوش می‌دهم… فرمانت را بگو."
                        refreshPanelText()
                    }
                }
                override fun onBeginningOfSpeech() {
                    if (visible && !commandRecognitionForDictation) {
                        panelAnswerText = "صدایت دریافت شد…"
                        refreshPanelText()
                    }
                }
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() {
                    if (visible && !commandRecognitionForDictation) {
                        panelAnswerText = "در حال تشخیص گفتار…"
                        refreshPanelText()
                    }
                }
                override fun onError(error: Int) {
                    val dictation = commandRecognitionForDictation
                    commandRecognitionForDictation = false
                    releaseCommandSpeechRecognition(cancelActive = false)
                    if (visible && dictation) {
                        val message = when (error) {
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "مجوز میکروفون در دسترس نیست."
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "موتور تشخیص گفتار یا اتصال شبکه در دسترس نیست."
                            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "گفتاری تشخیص داده نشد؛ دوباره میکروفون را بزن."
                            else -> "تبدیل گفتار انجام نشد؛ دوباره امتحان کن."
                        }
                        Toast.makeText(appContext, message, Toast.LENGTH_SHORT).show()
                    } else if (visible) {
                        panelAnswerText = when (error) {
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "مجوز میکروفون در دسترس نیست."
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "موتور تشخیص گفتار دستگاه در دسترس نیست یا اتصال لازم را ندارد."
                            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "گفتاری تشخیص داده نشد؛ دوباره دستیار را فراخوانی کن یا فرمان را بنویس."
                            else -> "تشخیص گفتار شروع نشد؛ می‌توانی فرمان را بنویسی."
                        }
                        panelThinking = false
                        refreshPanelText()
                    }
                }
                override fun onResults(results: Bundle?) {
                    val recognized = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.trim().orEmpty()
                    val dictation = commandRecognitionForDictation
                    commandRecognitionForDictation = false
                    releaseCommandSpeechRecognition(cancelActive = false)
                    if (recognized.isNotBlank() && visible) {
                        if (dictation) updateDockDictationText(recognized)
                        else handleAssistantInput(recognized)
                    } else if (visible && dictation) {
                        Toast.makeText(appContext, "گفتاری تشخیص داده نشد؛ دوباره امتحان کن.", Toast.LENGTH_SHORT).show()
                    } else if (visible) {
                        panelAnswerText = "گفتاری تشخیص داده نشد؛ دوباره امتحان کن."
                        refreshPanelText()
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (visible && partial.isNotBlank()) {
                        if (commandRecognitionForDictation) updateDockDictationText(partial)
                        else {
                            panelAnswerText = partial.take(180)
                            refreshPanelText()
                        }
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
            recognizer.startListening(PhoneActionEngine.speechIntent())
            mainHandler.removeCallbacks(commandSpeechTimeout)
            mainHandler.postDelayed(commandSpeechTimeout, 15_000L)
        } catch (error: Exception) {
            commandRecognitionForDictation = false
            stopCommandSpeechRecognition()
            if (forDictation) Toast.makeText(appContext, "شروع تبدیل گفتار ناموفق بود؛ دوباره امتحان کن.", Toast.LENGTH_SHORT).show()
            else {
                panelAnswerText = "موتور تشخیص گفتار این دستگاه قابل اجرا نیست؛ فرمان را در کادر پایین بنویس."
                refreshPanelText()
            }
            android.util.Log.w("AllBatSpeech", "On-device speech provider could not be started", error)
        }
    }

    private var offlineRecognizer: OfflineVoiceRecognizer? = null

    /** On-device Persian recognition (Vosk) used when there is no internet or no system recognizer. */
    private fun startOfflineCommandRecognition(forDictation: Boolean = false) {
        offlineRecognizer?.stop()
        if (!forDictation) {
            panelAnswerText = "حالت آفلاین: گوش می‌دهم… فرمانت را بگو."
            panelThinking = false
            refreshPanelText()
        } else {
            Toast.makeText(appContext, "تبدیل گفتار آفلاین فعال شد.", Toast.LENGTH_SHORT).show()
        }
        val recognizer = OfflineVoiceRecognizer(appContext)
        offlineRecognizer = recognizer
        recognizer.start(object : OfflineVoiceRecognizer.Listener {
            override fun onPartial(text: String) {
                if (visible) {
                    if (forDictation) updateDockDictationText(text)
                    else {
                        panelAnswerText = text.take(180)
                        refreshPanelText()
                    }
                }
            }
            override fun onFinal(text: String) {
                offlineRecognizer = null
                if (visible && text.isNotBlank()) {
                    if (forDictation) updateDockDictationText(text)
                    else handleAssistantInput(text)
                } else if (visible && forDictation) {
                    Toast.makeText(appContext, "گفتاری تشخیص داده نشد؛ دوباره امتحان کن.", Toast.LENGTH_SHORT).show()
                }
                commandRecognitionForDictation = false
            }
            override fun onError(message: String) {
                offlineRecognizer = null
                commandRecognitionForDictation = false
                if (visible && forDictation) Toast.makeText(appContext, message, Toast.LENGTH_LONG).show()
                else if (visible) {
                    panelAnswerText = message
                    panelThinking = false
                    refreshPanelText()
                }
            }
        })
    }

    private fun updateDockDictationText(spoken: String) {
        val input = composerInput ?: return
        val phrase = spoken.trim()
        if (phrase.isEmpty()) return
        val combined = if (dictationBaseText.isBlank()) phrase else "$dictationBaseText $phrase"
        input.setText(combined)
        input.setSelection(input.text?.length ?: 0)
    }

    private fun stopCommandSpeechRecognition() {
        commandRecognitionForDictation = false
        releaseCommandSpeechRecognition(cancelActive = true)
    }

    private fun releaseCommandSpeechRecognition(cancelActive: Boolean) {
        if (cancelActive) {
            offlineRecognizer?.stop()
            offlineRecognizer = null
        }
        mainHandler.removeCallbacks(commandSpeechTimeout)
        val recognizer = commandRecognizer ?: return
        commandRecognizer = null
        if (cancelActive) try { recognizer.cancel() } catch (_: Exception) { }
        try { recognizer.destroy() } catch (_: Exception) { }
    }

    private fun handleAssistantInput(rawText: String) {
        panelAnswerText = "در حال ارسال درخواست به مدل…"
        panelThinking = true
        refreshPanelText()
        assistantWebView?.evaluateJavascript(
            "(window.__allbatAssistantSend ? window.__allbatAssistantSend(${JSONObject.quote(rawText.take(4000))}) : false)"
        ) { result ->
            if (result != "true" && visible) {
                panelThinking = false
                panelAnswerText = "ارسال پیام ممکن نشد؛ دوباره تلاش کن."
                refreshPanelText()
            }
        }
    }

    private fun defaultCardHeightPx(): Int {
        val screenHeight = context.resources.displayMetrics.heightPixels.coerceAtLeast(dp(420))
        val maxHeight = (screenHeight * 0.62f).toInt()
        val wanted = if (contentHeightPx > 0) contentHeightPx else dp(220)
        return wanted.coerceIn(dp(170), maxHeight)
    }

    private fun chromeButton(iconRes: Int, description: String, padding: Int = dp(10), onClick: () -> Unit): ImageView =
        ImageView(context).apply {
            setImageResource(iconRes)
            contentDescription = description
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(padding, padding, padding, padding)
            setOnClickListener { onClick() }
        }

    /** Text-only answer card (native). The WebView stays alive off-screen and only feeds it text. */
    private fun buildTextCard(): FrameLayout {
        val tv = TextView(context).apply {
            textSize = 17f
            setTextColor(Color.rgb(24, 25, 30))
            setLineSpacing(dp(5).toFloat(), 1.05f)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            textAlignment = View.TEXT_ALIGNMENT_TEXT_START
            setPadding(dp(26), dp(22), dp(26), dp(22))
            setTextIsSelectable(true)
        }
        textView = tv
        val scroll = BoundedScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        textScroll = scroll
        val card = FrameLayout(context).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(252, 252, 250, 250), Color.argb(252, 246, 243, 244))
            ).apply { cornerRadius = dp(30).toFloat() }
            clipToOutline = true
            elevation = dp(10).toFloat()
            isClickable = true
            addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        textCard = card
        refreshPanelText()
        return card
    }

    private fun refreshPanelText() {
        val tv = textView ?: return
        val scroll = textScroll
        val nearBottom = scroll == null || scroll.childCount == 0 ||
            scroll.scrollY + scroll.height >= scroll.getChildAt(0).height - dp(40)
        when {
            panelAnswerText.isNotBlank() -> { tv.text = panelAnswerText; tv.setTextColor(Color.rgb(24, 25, 30)) }
            panelThinking -> { tv.text = "Thinking........"; tv.setTextColor(Color.rgb(95, 99, 104)) }
            else -> { tv.text = "در خدمتم؛ سؤال خودت را بنویس یا گوی را بزن و صحبت کن."; tv.setTextColor(Color.rgb(110, 114, 120)) }
        }
        dockSendButton?.visibility = if (!liveMode && !panelGenerating) View.VISIBLE else View.GONE
        dockStopResponseButton?.visibility = if (!liveMode && panelGenerating) View.VISIBLE else View.GONE
        if (nearBottom) scroll?.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    /** Bottom dock from the reference: home, glowing orb, "Ask anything......." pill with mic, settings. */
    private fun buildDock(): LinearLayout {
        val dock = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(4, 4, 4), Color.rgb(20, 20, 20))
            ).apply { cornerRadius = dp(39).toFloat() }
            elevation = dp(8).toFloat()
            setPadding(dp(18), dp(4), dp(18), dp(4))
            minimumHeight = dp(78)
            isClickable = true
        }
        val homeBtn = chromeButton(R.drawable.ic_assistant_home, "Open app", dp(5)) { openAppFromAssistant() }
        dockHomeButton = homeBtn
        dock.addView(homeBtn, LinearLayout.LayoutParams(dp(36), dp(44)))
        val orb = OrbView(context).apply {
            contentDescription = "Voice conversation"
            setOnClickListener { toggleLiveFromDock() }
        }
        assistantOrb = orb
        dock.addView(orb, LinearLayout.LayoutParams(dp(54), dp(54)).apply { setMargins(dp(4), 0, dp(4), 0) })

        val pill = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutTransition = android.animation.LayoutTransition().apply {
                setDuration(android.animation.LayoutTransition.APPEARING, 180L)
                setDuration(android.animation.LayoutTransition.DISAPPEARING, 145L)
                val easing = PathInterpolator(0.22f, 0f, 0f, 1f)
                setInterpolator(android.animation.LayoutTransition.APPEARING, easing)
                setInterpolator(android.animation.LayoutTransition.DISAPPEARING, easing)
                enableTransitionType(android.animation.LayoutTransition.APPEARING)
                enableTransitionType(android.animation.LayoutTransition.DISAPPEARING)
            }
            background = GradientDrawable().apply {
                cornerRadius = dp(21).toFloat()
                setColor(Color.rgb(43, 43, 43))
            }
            setPadding(dp(16), dp(8), dp(6), dp(8))
            minimumHeight = dp(42)
            setOnClickListener { if (!liveMode) focusComposer() }
        }
        // Typing happens here, in the dock next to the orb. The web composer is hidden.
        val input = EditText(context).apply {
            hint = DOCK_HINT
            setHintTextColor(Color.rgb(150, 150, 150))
            setTextColor(Color.rgb(236, 236, 236))
            textSize = 15f
            background = null
            setPadding(0, dp(6), 0, dp(6))
            maxLines = 3
            setHorizontallyScrolling(false)
            setRawInputType(android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
            imeOptions = EditorInfo.IME_ACTION_SEND
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            gravity = Gravity.CENTER_VERTICAL
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendTypedMessage(); true } else false
            }
            setOnFocusChangeListener { _, _ -> watchKeyboard() }
            setOnClickListener { watchKeyboard() }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) = Unit
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) = Unit
                override fun afterTextChanged(s: Editable?) { dockSendButton?.alpha = if (s.isNullOrBlank()) 0.4f else 1f }
            })
        }
        composerInput = input
        pill.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        // Live transcript shown instead of the input while a voice conversation is active.
        val live = TextView(context).apply {
            setTextColor(Color.rgb(236, 236, 236))
            textSize = 15f
            maxLines = 3
            ellipsize = android.text.TextUtils.TruncateAt.END
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            visibility = View.GONE
        }
        liveText = live
        pill.addView(live, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val micBtn = chromeButton(R.drawable.ic_assistant_mic, "تبدیل گفتار به متن", dp(7)) {
            if (commandRecognitionForDictation && (commandRecognizer != null || offlineRecognizer != null)) stopCommandSpeechRecognition()
            else startCommandSpeechRecognition(forDictation = true)
        }
        dockMicButton = micBtn
        pill.addView(micBtn, LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(4) })

        val sendBtn = chromeButton(R.drawable.ic_assistant_send, "Send", dp(7)) { sendTypedMessage() }
        sendBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(242, 242, 242)) }
        sendBtn.alpha = 0.4f
        dockSendButton = sendBtn
        pill.addView(sendBtn, LinearLayout.LayoutParams(dp(34), dp(34)))

        // Stops only the current text answer. It never ends the Live voice session.
        val stopResponseBtn = chromeButton(R.drawable.ic_assistant_stop, "Stop current response", dp(8)) { stopCurrentResponse() }
        stopResponseBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(242, 242, 242)) }
        stopResponseBtn.visibility = View.GONE
        dockStopResponseButton = stopResponseBtn
        pill.addView(stopResponseBtn, LinearLayout.LayoutParams(dp(34), dp(34)))

        // Shown only during a voice conversation: ends it without closing the panel.
        val stopBtn = chromeButton(R.drawable.ic_assistant_stop, "End voice conversation", dp(8)) { endLiveFromDock() }
        stopBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(242, 242, 242)) }
        stopBtn.visibility = View.GONE
        dockStopButton = stopBtn
        pill.addView(stopBtn, LinearLayout.LayoutParams(dp(34), dp(34)))
        dock.addView(pill, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(6), 0, dp(6), 0) })

        dock.addOnLayoutChangeListener { _, _, top, _, bottom, _, oldTop, _, oldBottom ->
            if (bottom - top != oldBottom - oldTop) mainHandler.post { relayoutAssistant() }
        }
        assistantDock = dock
        return dock
    }

    private fun installSystemInsetTracking(root: View) {
        root.setOnApplyWindowInsetsListener { _, insets ->
            @Suppress("DEPRECATION")
            var bottom = insets.stableInsetBottom
            if (bottom <= 0) {
                val id = context.resources.getIdentifier("navigation_bar_height", "dimen", "android")
                if (id > 0) bottom = context.resources.getDimensionPixelSize(id)
            }
            var changed = false
            if (bottom != navigationInsetPx) {
                navigationInsetPx = bottom
                changed = true
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val ime = insets.getInsets(android.view.WindowInsets.Type.ime()).bottom
                if (ime != imeInsetPx) {
                    imeInsetPx = ime
                    changed = true
                }
            }
            if (updateKeyboardOverlap() || changed) relayoutAssistant()
            insets
        }
        root.viewTreeObserver.addOnGlobalLayoutListener {
            if (root.height > 0 && (updateKeyboardOverlap() || root.height != lastRootHeight)) {
                lastRootHeight = root.height
                relayoutAssistant()
            }
        }
    }

    /**
     * Works out how much of the assistant window the keyboard covers. In an assistant session
     * window adjustResize is often ignored, so the window keeps its full height and the keyboard
     * simply sits on top of the dock. We measure the overlap ourselves and lift the dock by it.
     * Returns true when the value changed.
     */
    private fun updateKeyboardOverlap(): Boolean {
        val root = assistantRoot ?: return false
        if (root.height <= 0) return false
        if (!keyboardVisible && root.height > baselineRootHeight) baselineRootHeight = root.height
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        val rootBottom = loc[1] + root.height
        val frame = Rect()
        root.getWindowVisibleDisplayFrame(frame)
        val frameOverlap = (rootBottom - frame.bottom).coerceAtLeast(0)
        // If the system really did shrink the window, the layout already moves up by itself.
        val resized = baselineRootHeight > 0 && root.height < baselineRootHeight - dp(100)
        var overlap = if (resized) frameOverlap else maxOf(frameOverlap, imeInsetPx)
        if (overlap < dp(80)) overlap = 0 // navigation bar only, not a keyboard
        val kb = resized || overlap > 0
        if (overlap == keyboardOverlapPx && kb == keyboardVisible) return false
        keyboardOverlapPx = overlap
        keyboardVisible = kb
        return true
    }

    private val keyboardWatcher = object : Runnable {
        override fun run() {
            if (!visible) return
            if (updateKeyboardOverlap()) relayoutAssistant()
            val focused = composerInput?.hasFocus() == true
            if (focused || android.os.SystemClock.uptimeMillis() < keyboardWatchUntil) {
                mainHandler.postDelayed(this, 100)
            }
        }
    }

    /** Re-checks the keyboard position every 100 ms while the input is focused (and briefly after). */
    private fun watchKeyboard() {
        keyboardWatchUntil = android.os.SystemClock.uptimeMillis() + 1200L
        mainHandler.removeCallbacks(keyboardWatcher)
        mainHandler.post(keyboardWatcher)
    }

    /** Positions the card above the dock; hides the dock while the keyboard is open or a region is being selected. */
    private fun relayoutAssistant() {
        val card = assistantCard ?: return
        val dock = assistantDock ?: return
        val root = assistantRoot ?: return
        val params = card.layoutParams as? FrameLayout.LayoutParams ?: return
        if (screenSelectionMode) {
            params.width = ViewGroup.LayoutParams.MATCH_PARENT
            params.height = ViewGroup.LayoutParams.MATCH_PARENT
            params.setMargins(0, 0, 0, 0)
            card.background = ColorDrawable(Color.TRANSPARENT)
            card.clipToOutline = false
            card.elevation = 0f
            dock.visibility = View.GONE
            card.alpha = 1f
            card.translationY = 0f
            textCard?.visibility = View.GONE
            assistantBackButton?.visibility = View.GONE
            assistantCloseButton?.visibility = View.GONE
        } else {
            val dockBottom = when {
                keyboardOverlapPx > 0 -> keyboardOverlapPx + dp(8) // sit right on top of the keyboard
                keyboardVisible -> dp(8)                           // window was resized by the system
                else -> dp(12) + navigationInsetPx
            }
            val dockHeight = if (dock.height > 0) dock.height else dp(78)
            val bottomMargin = dockHeight + dockBottom + dp(14)
            val rootHeight = if (root.height > 0) root.height else context.resources.displayMetrics.heightPixels
            val available = (rootHeight - bottomMargin - dp(24)).coerceAtLeast(dp(180))
            params.width = ViewGroup.LayoutParams.MATCH_PARENT
            params.height = minOf(defaultCardHeightPx(), available)
            params.setMargins(dp(14), 0, dp(14), bottomMargin)
            card.background = cardBackground
            card.clipToOutline = true
            card.elevation = dp(10).toFloat()
            // Keep the WebView attached and visible in Live mode (Chromium throttles hidden views);
            // the card is just moved off-screen so only the dock is seen.
            card.visibility = View.VISIBLE
            // The WebView card is kept alive but off-screen; the native text card is what the user sees.
            card.alpha = 0f
            card.translationY = context.resources.displayMetrics.heightPixels.toFloat()
            textScroll?.maxHeightPx = available
            textCard?.let { tc ->
                tc.visibility = if (liveMode && smsConfirmationView == null) View.GONE else View.VISIBLE
                val lp = tc.layoutParams as? FrameLayout.LayoutParams
                if (lp != null) { lp.setMargins(dp(14), 0, dp(14), bottomMargin); tc.layoutParams = lp }
            }
            assistantBackButton?.visibility = View.VISIBLE
            assistantCloseButton?.visibility = View.VISIBLE
            val idle = if (liveMode) View.GONE else View.VISIBLE
            dockHomeButton?.visibility = idle
            composerInput?.visibility = idle
            dockSendButton?.visibility = if (!liveMode && !panelGenerating) View.VISIBLE else View.GONE
            dockStopResponseButton?.visibility = if (!liveMode && panelGenerating) View.VISIBLE else View.GONE
            liveText?.visibility = if (liveMode) View.VISIBLE else View.GONE
            dockStopButton?.visibility = if (liveMode) View.VISIBLE else View.GONE
            dockMicButton?.visibility = if (!liveMode) View.VISIBLE else View.GONE
            val dockParams = dock.layoutParams as? FrameLayout.LayoutParams
            if (dockParams != null) {
                dockParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
                dockParams.setMargins(dp(14), 0, dp(14), dockBottom)
                dock.layoutParams = dockParams
            }
            // The dock stays visible above the keyboard so the user can type into it.
            dock.visibility = View.VISIBLE
        }
        card.layoutParams = params
    }

    private fun createScreenSelectionGestureLayer(): View {
        var startX = 0f
        var startY = 0f
        var moved = false
        val touchSlop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
        return View(context).apply {
            setOnTouchListener { _, event ->
                if (!visible || liveMode || screenSelectionMode || keyboardVisible || keyboardOverlapPx > 0 ||
                    pendingScreenshotDataUrl.isNullOrEmpty()) {
                    return@setOnTouchListener false
                }
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        if (isAssistantInteractiveTouch(event.rawX, event.rawY)) return@setOnTouchListener false
                        startX = event.x
                        startY = event.y
                        moved = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (kotlin.math.hypot((event.x - startX).toDouble(), (event.y - startY).toDouble()) > touchSlop) {
                            moved = true
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        val endX = event.x
                        val endY = event.y
                        if (moved) {
                            val root = assistantRoot
                            val left = min(startX, endX).coerceAtLeast(0f)
                            val top = min(startY, endY).coerceAtLeast(0f)
                            val right = maxOf(startX, endX).coerceAtMost((root?.width ?: 0).toFloat())
                            val bottom = maxOf(startY, endY).coerceAtMost((root?.height ?: 0).toFloat())
                            if (root != null && right - left >= dp(36) && bottom - top >= dp(36) && root.width > 0 && root.height > 0) {
                                stopCommandSpeechRecognition()
                                hideKeyboard()
                                val rect = JSONObject()
                                    .put("left", left / root.width.toFloat())
                                    .put("top", top / root.height.toFloat())
                                    .put("width", (right - left) / root.width.toFloat())
                                    .put("height", (bottom - top) / root.height.toFloat())
                                setScreenSelectionMode(true)
                                evaluate("window.__allbatAssistantStartRegionSelection && window.__allbatAssistantStartRegionSelection($rect);")
                            } else {
                                Toast.makeText(appContext, "محدوده انتخاب‌شده خیلی کوچک است؛ کمی بزرگ‌تر بکش.", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            hide()
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> true
                    else -> true
                }
            }
        }
    }

    private fun isAssistantInteractiveTouch(rawX: Float, rawY: Float): Boolean {
        fun contains(view: View?): Boolean {
            if (view == null || view.visibility != View.VISIBLE || view.alpha < 0.05f || view.width <= 0 || view.height <= 0) return false
            val location = IntArray(2)
            view.getLocationOnScreen(location)
            return rawX >= location[0] && rawX < location[0] + view.width &&
                rawY >= location[1] && rawY < location[1] + view.height
        }
        return contains(assistantDock) || contains(textCard) ||
            (assistantCard?.let { it.visibility == View.VISIBLE && it.alpha > 0.05f && contains(it) } == true)
    }

    private fun setScreenSelectionMode(enabled: Boolean) {
        if (!visible || screenSelectionMode == enabled) return
        screenSelectionMode = enabled
        relayoutAssistant()
    }

    private fun setLiveMode(enabled: Boolean) {
        if (liveMode == enabled) return
        liveMode = enabled
        if (enabled) { hideKeyboard(); liveText?.text = "…" } else liveText?.text = ""
        assistantOrb?.setPulsing(enabled)
        relayoutAssistant()
    }

    /** In Live mode the dock only shows the active orb and the live transcript text. */
    private fun updateDockText(userText: String?, answerText: String?, status: String?) {
        val text = when {
            !answerText.isNullOrBlank() -> answerText
            !userText.isNullOrBlank() -> userText
            else -> status.orEmpty()
        }.trim()
        liveText?.text = if (text.isEmpty()) "…" else text.takeLast(200)
    }

    private fun focusComposer() {
        val input = composerInput ?: return
        stopCommandSpeechRecognition()
        input.requestFocus()
        watchKeyboard()
        mainHandler.postDelayed({
            try {
                val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            } catch (_: Exception) { }
        }, 120)
    }

    private fun hideKeyboard() {
        try {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            val token = (composerInput ?: assistantRoot)?.windowToken
            if (token != null) imm.hideSoftInputFromWindow(token, 0)
            composerInput?.clearFocus()
        } catch (_: Exception) { }
        watchKeyboard()
    }

    /** Hands the typed text to the (hidden) web composer and presses its send button. */
    private fun sendTypedMessage() {
        val input = composerInput ?: return
        val text = input.text?.toString()?.trim().orEmpty()
        if (text.isEmpty() || liveMode) return
        if (panelGenerating) {
            Toast.makeText(appContext, "پاسخ قبلی هنوز در حال تولید است؛ برای لغو، دکمهٔ توقف را بزن.", Toast.LENGTH_SHORT).show()
            return
        }
        mainHandler.post {
            stopCommandSpeechRecognition()
            assistantWebView?.evaluateJavascript(
                "(window.__allbatAssistantSend ? window.__allbatAssistantSend(${JSONObject.quote(text)}) : false)"
            ) { result ->
                if (result == "true") {
                    input.setText("")
                    hideKeyboard()
                } else {
                    Toast.makeText(appContext, "پاسخ قبلی هنوز در حال تولید است؛ کمی صبر کن.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    /** Cancels the current text generation without hanging up an active Live session. */
    private fun stopCurrentResponse() {
        val web = assistantWebView ?: return
        web.evaluateJavascript("(window.__allbatStopCurrentResponse ? window.__allbatStopCurrentResponse() : false)") { result ->
            if (result != "true") {
                Toast.makeText(appContext, "توقف پاسخ در این لحظه انجام نشد؛ وضعیت اتصال را بررسی کن.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** Ends only the voice conversation; the panel stays open and returns to text mode. */
    private fun endLiveFromDock() {
        liveStopRequestedAt = android.os.SystemClock.uptimeMillis()
        evaluate("window.__assistantNativeStopAll && window.__assistantNativeStopAll();")
        try { SessionServiceControl.send(appContext, SessionForegroundService.ACTION_STOP_VOICE) } catch (_: Exception) { }
        sessionVoiceServiceStarted = false
        restoreCommunicationAudio()
        setLiveMode(false)
    }

    private fun toggleLiveFromDock() {
        stopCommandSpeechRecognition()
        evaluate("(function(){var b=document.getElementById('voiceChatBtn'); if(b){b.click();}})();")
    }

    private fun closeAssistant() {
        val live = appContext.getSharedPreferences("allbat_session_state", Context.MODE_PRIVATE).getBoolean("voice_active", false)
        if (live) {
            stopRequestedByUser = true
            evaluate("window.__assistantNativeStopAll && window.__assistantNativeStopAll();")
            try { SessionServiceControl.send(appContext, SessionForegroundService.ACTION_STOP_ALL) } catch (_: Exception) { }
        }
        hide()
    }

    private fun launchFromAssistant(intent: Intent): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 34) startAssistantActivity(intent, Bundle.EMPTY)
            else appContext.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (error: Exception) {
            Toast.makeText(appContext, "بازکردن این بخش ممکن نشد", Toast.LENGTH_SHORT).show()
            false
        }
    }

    private fun openAppFromAssistant() {
        launchFromAssistant(Intent(appContext, MainActivity::class.java))
        hide()
    }

    private fun publishAssistantSurfaceVisibility(visible: Boolean) {
        appContext.getSharedPreferences("allbat_session_state", Context.MODE_PRIVATE).edit()
            .putBoolean("assistant_surface_visible", visible)
            .apply()
        try {
            appContext.sendBroadcast(Intent(SessionForegroundService.ACTION_SURFACE_VISIBILITY)
                .setPackage(appContext.packageName).apply {
                    putExtra(SessionForegroundService.EXTRA_SURFACE_OWNER, "assistant")
                    putExtra(SessionForegroundService.EXTRA_SURFACE_VISIBLE, visible)
                })
        } catch (error: Exception) {
            android.util.Log.w("AllBatOverlay", "Could not publish assistant surface visibility", error)
        }
    }

    override fun onHandleScreenshot(screenshot: Bitmap?) {
        if (screenshot == null) {
            pendingScreenshotDataUrl = null
            evaluate("window.__allbatAssistantScreenshotUnavailable && window.__allbatAssistantScreenshotUnavailable();")
            return
        }
        try {
            pendingScreenshotDataUrl = encodeScreenshot(screenshot)
            deliverPendingScreenshot()
            mainHandler.post { relayoutAssistant() }
        } catch (error: Exception) {
            pendingScreenshotDataUrl = null
            android.util.Log.w("AllBatAssistant", "Could not prepare assistant screenshot", error)
            evaluate("window.__allbatAssistantScreenshotUnavailable && window.__allbatAssistantScreenshotUnavailable();")
        }
    }

    private fun encodeScreenshot(source: Bitmap): String {
        var resized: Bitmap? = null
        val bitmap: Bitmap
        val ratio = min(1f, 1600f / source.width.toFloat())
        if (ratio < 1f) {
            resized = Bitmap.createScaledBitmap(source, maxOf(1, (source.width * ratio).toInt()), maxOf(1, (source.height * ratio).toInt()), true)
            bitmap = resized
        } else {
            bitmap = source
        }
        val out = ByteArrayOutputStream()
        try {
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 68, out)) throw IllegalStateException("JPEG encoding failed")
            return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } finally {
            if (resized != null && resized !== source) resized.recycle()
            try { out.close() } catch (_: Exception) { }
        }
    }

    private fun deliverPendingScreenshot() {
        if (!pageLoaded || !visible) return
        val data = pendingScreenshotDataUrl ?: return
        evaluate("window.__allbatAssistantSetScreenshot && window.__allbatAssistantSetScreenshot(${JSONObject.quote(data)});")
    }

    private fun evaluate(script: String) {
        mainHandler.post { assistantWebView?.evaluateJavascript(script, null) }
    }

    private fun prepareCommunicationAudio() {
        val manager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            if (previousAudioMode == null) previousAudioMode = manager.mode
            manager.mode = AudioManager.MODE_IN_COMMUNICATION
        } catch (error: Exception) {
            android.util.Log.w("AllBatAudio", "Could not set communication mode for assistant session", error)
        }
        try {
            val request = voiceAudioFocusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAcceptsDelayedFocusGain(false)
                .setOnAudioFocusChangeListener(voiceAudioFocusChangeListener)
                .build()
                .also { voiceAudioFocusRequest = it }
            manager.requestAudioFocus(request)
        } catch (error: Exception) {
            android.util.Log.w("AllBatAudio", "Could not acquire assistant-session audio focus", error)
        }
    }

    private fun restoreCommunicationAudio() {
        val manager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try { voiceAudioFocusRequest?.let { manager.abandonAudioFocusRequest(it) } } catch (_: Exception) { }
        voiceAudioFocusRequest = null
        val mode = previousAudioMode
        if (mode != null) {
            try { manager.mode = mode } catch (_: Exception) { }
            previousAudioMode = null
        }
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    override fun onHide() {
        visible = false
        panelGenerating = false
        panelThinking = false
        stopCommandSpeechRecognition()
        screenSelectionMode = false
        publishAssistantSurfaceVisibility(false)
        pendingScreenshotDataUrl = null
        hideKeyboard()
        mainHandler.removeCallbacks(keyboardWatcher)
        keyboardOverlapPx = 0
        imeInsetPx = 0
        keyboardVisible = false
        mainHandler.post { relayoutAssistant() }
        evaluate("window.__allbatAssistantClearScreenshot && window.__allbatAssistantClearScreenshot(); window.__allbatAssistantPanelMode && window.__allbatAssistantPanelMode(false);")
        // Dismissing the panel is not an implicit hang-up. A user-started Live session may continue
        // in the foreground service; the next Home invocation intentionally creates a new text chat.
        super.onHide()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            hide()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        visible = false
        screenSelectionMode = false
        publishAssistantSurfaceVisibility(false)
        try { if (overlayReceiverRegistered) appContext.unregisterReceiver(sessionOverlayReceiver) } catch (_: Exception) { }
        overlayReceiverRegistered = false
        try { if (permissionReceiverRegistered) appContext.unregisterReceiver(audioPermissionReceiver) } catch (_: Exception) { }
        permissionReceiverRegistered = false
        stopCommandSpeechRecognition()
        if (stopRequestedByUser) {
            try { SessionServiceControl.send(appContext, SessionForegroundService.ACTION_STOP_ALL) } catch (_: Exception) { }
        }
        sessionVoiceServiceStarted = false
        sessionCameraServiceStarted = false
        val stillActive = appContext.getSharedPreferences("allbat_session_state", Context.MODE_PRIVATE).getBoolean("voice_active", false)
        if (stopRequestedByUser || !stillActive) restoreCommunicationAudio()
        ScreenCaptureService.frameSink = null
        ScreenCaptureService.statusSink = null
        ScreenProjectionPermissionActivity.resultSink = null
        assistantWebView?.apply {
            removeJavascriptInterface("AndroidAssistant")
            stopLoading()
            destroy()
        }
        assistantWebView = null
        closeSmsConfirmationCard(restore = false)
        super.onDestroy()
    }

    /** Places the editable SMS confirmation directly inside the assistant's white answer card. */
    private fun presentSmsConfirmationInAssistant(data: JSONObject): String {
        val awaiterId = DeviceToolAwaiter.create()
        val ready = java.util.concurrent.CountDownLatch(1)
        val shown = java.util.concurrent.atomic.AtomicBoolean(false)
        mainHandler.post {
            try {
                val panel = textCard
                if (panel == null) {
                    DeviceToolAwaiter.complete(awaiterId, JSONObject().put("ok", false)
                        .put("message", "کارت سفید دستیار در دسترس نیست؛ پیام ارسال نشد.").toString())
                    return@post
                }
                closeSmsConfirmationCard(restore = false)
                smsPreviousPanelVisibility = panel.visibility
                smsPreviousTextVisibility = textScroll?.visibility ?: View.VISIBLE
                textScroll?.visibility = View.GONE
                val contact = data.optString("contact_name").take(100)
                val number = data.optString("number").take(40)
                val body = data.optString("message").take(2000)
                val preview = SmsPreviewView(
                    context, contact, number, body,
                    onCancel = {
                        DeviceToolAwaiter.complete(awaiterId, JSONObject().put("ok", false)
                            .put("message", "کاربر ارسال پیامک را لغو کرد؛ هیچ پیامی ارسال نشد.").toString())
                        closeSmsConfirmationCard()
                    },
                    onSend = { editedBody ->
                        closeSmsConfirmationCard()
                        val smsIntent = Intent(appContext, PhoneActionPermissionActivity::class.java).apply {
                            putExtra(PhoneActionPermissionActivity.EXTRA_SMS_AWAITER_ID, awaiterId)
                            putExtra(PhoneActionPermissionActivity.EXTRA_SMS_CONTACT, contact)
                            putExtra(PhoneActionPermissionActivity.EXTRA_SMS_NUMBER, number)
                            putExtra(PhoneActionPermissionActivity.EXTRA_SMS_BODY, editedBody.take(2000))
                        }
                        if (!launchFromAssistant(smsIntent)) {
                            DeviceToolAwaiter.complete(awaiterId, JSONObject().put("ok", false)
                                .put("message", "صفحهٔ تأیید ارسال پیامک باز نشد؛ پیام ارسال نشد.").toString())
                        }
                    }
                )
                smsConfirmationView = preview
                panel.addView(preview, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                panel.visibility = View.VISIBLE
                relayoutAssistant()
                shown.set(true)
            } catch (_: Exception) {
                DeviceToolAwaiter.complete(awaiterId, JSONObject().put("ok", false)
                    .put("message", "نمایش پیش‌نمایش پیامک در دستیار ممکن نشد.").toString())
            } finally { ready.countDown() }
        }
        if (!ready.await(6, java.util.concurrent.TimeUnit.SECONDS) || !shown.get()) {
            DeviceToolAwaiter.complete(awaiterId, JSONObject().put("ok", false)
                .put("message", "نمایش تأیید پیامک شروع نشد.").toString())
        }
        return DeviceToolAwaiter.await(awaiterId, 120)
    }

    private fun closeSmsConfirmationCard(restore: Boolean = true) {
        val panel = textCard
        smsConfirmationView?.let { view ->
            try { panel?.removeView(view) } catch (_: Exception) { }
        }
        smsConfirmationView = null
        if (restore) {
            textScroll?.visibility = smsPreviousTextVisibility
            panel?.visibility = if (liveMode) View.GONE else smsPreviousPanelVisibility
            if (!liveMode) refreshPanelText()
            relayoutAssistant()
        }
    }

    inner class SessionBridge {
        @android.webkit.JavascriptInterface
        fun selectScreenRegion() {
            mainHandler.post {
                if (pendingScreenshotDataUrl.isNullOrEmpty()) {
                    evaluate("window.__allbatAssistantScreenshotUnavailable && window.__allbatAssistantScreenshotUnavailable();")
                } else {
                    evaluate("window.__allbatAssistantStartRegionSelection && window.__allbatAssistantStartRegionSelection();")
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun beginScreenRegionSelection() {
            mainHandler.post { setScreenSelectionMode(true) }
        }

        @android.webkit.JavascriptInterface
        fun finishScreenRegionSelection() {
            mainHandler.post { setScreenSelectionMode(false) }
        }

        @android.webkit.JavascriptInterface
        fun startScreenShare() {
            mainHandler.post {
                try {
                    // Keep Android's consent sheet in its own task. This prevents it from replacing
                    // the app the user was viewing and lets the live overlay return afterwards.
                    val request = Intent(appContext, ScreenProjectionPermissionActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                    }
                    startAssistantActivity(request, Bundle.EMPTY)
                } catch (primaryError: Exception) {
                    try {
                        val fallback = Intent(appContext, ScreenProjectionPermissionActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK or
                                Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                        }
                        appContext.startActivity(fallback)
                    } catch (fallbackError: Exception) {
                        primaryError.addSuppressed(fallbackError)
                        android.util.Log.e("AllBatScreen", "Could not launch MediaProjection consent", primaryError)
                        mainHandler.post {
                            evaluate("window.__assistantNativeScreenDenied && window.__assistantNativeScreenDenied();")
                            Toast.makeText(appContext, "بازکردن مجوز اشتراک صفحه ممکن نشد", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun stopScreenShare() {
            mainHandler.post { appContext.stopService(Intent(appContext, ScreenCaptureService::class.java)) }
        }

        @android.webkit.JavascriptInterface
        fun requestDefaultAssistant() {
            mainHandler.post {
                Toast.makeText(appContext, "برای تغییر دستیار پیش‌فرض، برنامه را از صفحهٔ اصلی باز کن", Toast.LENGTH_SHORT).show()
            }
        }

        @android.webkit.JavascriptInterface
        fun isDefaultAssistant(): Boolean = true

        @android.webkit.JavascriptInterface
        fun isAssistantSession(): Boolean = true

        @android.webkit.JavascriptInterface
        fun executeDeviceTool(name: String?, argsJson: String?): String {
            val toolName = name.orEmpty().take(80)
            val toolArgs = argsJson.orEmpty().take(4000)
            if (toolName.isBlank()) return JSONObject().put("ok", false).put("message", "نام ابزار خالی است.").toString()
            return try {
                val outcome = PhoneActionEngine.executeTool(appContext, toolName, toolArgs)
                if (outcome.data.optString("action") == "document_picker_required") {
                    val id = DeviceToolAwaiter.create()
                    val mimeJson = outcome.data.optJSONArray("mime_types") ?: org.json.JSONArray()
                    val mimeTypes = Array(mimeJson.length()) { index -> mimeJson.optString(index, "*/*") }
                    val started = java.util.concurrent.CountDownLatch(1)
                    val launchOk = java.util.concurrent.atomic.AtomicBoolean(false)
                    mainHandler.post {
                        try {
                            launchOk.set(launchFromAssistant(DeviceDocumentPickerActivity.createIntent(appContext, toolName, id, mimeTypes)))
                        } catch (_: Exception) { launchOk.set(false) }
                        finally { started.countDown() }
                    }
                    if (!started.await(6, java.util.concurrent.TimeUnit.SECONDS) || !launchOk.get()) {
                        DeviceToolAwaiter.complete(id, JSONObject().put("ok", false)
                            .put("message", "انتخاب‌گر امن فایل اندروید شروع نشد.").toString())
                    }
                    return DeviceToolAwaiter.await(id, 120)
                }
                if (outcome.permissions.isNotEmpty()) {
                    val id = DeviceToolAwaiter.create()
                    val started = java.util.concurrent.CountDownLatch(1)
                    val launchOk = java.util.concurrent.atomic.AtomicBoolean(false)
                    mainHandler.post {
                        try {
                            launchOk.set(launchFromAssistant(Intent(appContext, PhoneActionPermissionActivity::class.java).apply {
                                putExtra(PhoneActionPermissionActivity.EXTRA_TOOL_NAME, toolName)
                                putExtra(PhoneActionPermissionActivity.EXTRA_TOOL_ARGS, toolArgs)
                                putExtra(PhoneActionPermissionActivity.EXTRA_AWAITER_ID, id)
                            }))
                        } catch (_: Exception) { launchOk.set(false) }
                        finally { started.countDown() }
                    }
                    if (!started.await(6, java.util.concurrent.TimeUnit.SECONDS) || !launchOk.get()) {
                        DeviceToolAwaiter.complete(id, JSONObject().put("ok", false).put("message", "صفحهٔ مجوز اندروید باز نشد.").toString())
                    }
                    val permissionResult = DeviceToolAwaiter.await(id, 90)
                    val parsed = JSONObject(permissionResult)
                    val returnedData = parsed.optJSONObject("data")
                    if (toolName == "create_sms_draft" && parsed.optBoolean("ok") &&
                        returnedData?.optString("action") == "sms_confirmation_required") {
                        return presentSmsConfirmationInAssistant(returnedData)
                    }
                    return permissionResult
                }
                if (toolName == "create_sms_draft" && outcome.data.optString("action") == "sms_confirmation_required") {
                    return presentSmsConfirmationInAssistant(outcome.data)
                }
                if (outcome.intent != null) {
                    val started = java.util.concurrent.CountDownLatch(1)
                    val launchOk = java.util.concurrent.atomic.AtomicBoolean(false)
                    mainHandler.post {
                        launchOk.set(launchFromAssistant(outcome.intent))
                        started.countDown()
                    }
                    if (!started.await(6, java.util.concurrent.TimeUnit.SECONDS) || !launchOk.get()) {
                        JSONObject().put("ok", false).put("message", "اندروید اجازهٔ بازکردن مقصد را نداد.").toString()
                    } else outcome.toJson()
                } else outcome.toJson()
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                JSONObject().put("ok", false).put("message", "درخواست ابزار متوقف شد.").toString()
            } catch (_: Exception) {
                JSONObject().put("ok", false).put("message", "اجرای ابزار ناموفق بود.").toString()
            }
        }

        @android.webkit.JavascriptInterface
        fun appVersion(): String = BuildConfig.VERSION_NAME

        // The microphone is enabled only when the user explicitly presses Live in the assistant.
        @android.webkit.JavascriptInterface
        fun prepareAudioSession() {
            mainHandler.post { prepareCommunicationAudio() }
        }

        @android.webkit.JavascriptInterface
        fun cancelAudioSession() {
            mainHandler.post { restoreCommunicationAudio() }
        }

        @android.webkit.JavascriptInterface
        fun startVoiceSession() {
            mainHandler.post {
                if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(appContext, "ابتدا برنامه را باز کن و مجوز میکروفون را بده.", Toast.LENGTH_LONG).show()
                    return@post
                }
                try {
                    prepareCommunicationAudio()
                    ContextCompat.startForegroundService(
                        appContext,
                        Intent(appContext, SessionForegroundService::class.java)
                            .setAction(SessionForegroundService.ACTION_START_VOICE)
                            .putExtra(SessionForegroundService.EXTRA_OVERLAY_OWNER, "system_assistant")
                    )
                    sessionVoiceServiceStarted = true
                    liveStartedAt = android.os.SystemClock.uptimeMillis()
                    setLiveMode(true)
                    // Live itself does not depend on overlay permission. The bubble is optional
                    // and appears later only if Android has granted draw-over-apps access.
                } catch (error: Exception) {
                    Toast.makeText(appContext, "شروع نشست صوتی ممکن نشد", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun stopVoiceSession() {
            mainHandler.post {
                sessionVoiceServiceStarted = false
                setLiveMode(false)
                SessionServiceControl.send(appContext, SessionForegroundService.ACTION_STOP_VOICE)
                restoreCommunicationAudio()
            }
        }

        @android.webkit.JavascriptInterface
        fun startCameraSession() {
            mainHandler.post {
                if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(appContext, "برای روشن‌کردن دوربین، ابتدا برنامه را باز و مجوز دوربین را تأیید کن.", Toast.LENGTH_LONG).show()
                    return@post
                }
                try {
                    ContextCompat.startForegroundService(
                        appContext,
                        Intent(appContext, SessionForegroundService::class.java)
                            .setAction(SessionForegroundService.ACTION_START_CAMERA)
                            .putExtra(SessionForegroundService.EXTRA_OVERLAY_OWNER, "system_assistant")
                    )
                    sessionCameraServiceStarted = true
                } catch (_: Exception) { }
            }
        }

        @android.webkit.JavascriptInterface
        fun stopCameraSession() {
            mainHandler.post {
                sessionCameraServiceStarted = false
                SessionServiceControl.send(appContext, SessionForegroundService.ACTION_STOP_CAMERA)
            }
        }

        @android.webkit.JavascriptInterface
        fun updateAssistantOverlay(
            userText: String?, answerText: String?, status: String?, generating: Boolean,
            micMuted: Boolean, cameraActive: Boolean, screenActive: Boolean
        ) {
            val liveActive = appContext.getSharedPreferences("allbat_session_state", Context.MODE_PRIVATE).getBoolean("voice_active", false)
            mainHandler.post {
                if (liveActive && android.os.SystemClock.uptimeMillis() - liveStopRequestedAt > 2500L) setLiveMode(true)
                else if (android.os.SystemClock.uptimeMillis() - liveStartedAt > 4000L) setLiveMode(false)
                assistantOrb?.setPulsing(generating || liveMode)
                if (liveMode) updateDockText(userText, answerText, status)
            }
            val update = Intent(SessionForegroundService.ACTION_UPDATE_OVERLAY).setPackage(appContext.packageName).apply {
                putExtra(SessionForegroundService.EXTRA_USER_TEXT, userText.orEmpty().take(600))
                putExtra(SessionForegroundService.EXTRA_ANSWER_TEXT, answerText.orEmpty().take(3000))
                putExtra(SessionForegroundService.EXTRA_STATUS, status.orEmpty().take(100))
                putExtra(SessionForegroundService.EXTRA_GENERATING, generating)
                putExtra(SessionForegroundService.EXTRA_MIC_MUTED, micMuted)
                putExtra(SessionForegroundService.EXTRA_CAMERA_ACTIVE, cameraActive)
                putExtra(SessionForegroundService.EXTRA_SCREEN_ACTIVE, screenActive)
                putExtra(SessionForegroundService.EXTRA_OVERLAY_OWNER, "system_assistant")
            }
            try { appContext.sendBroadcast(update) } catch (_: Exception) { }
        }

        @android.webkit.JavascriptInterface
        fun setPanelText(text: String?, thinking: Boolean, generating: Boolean) {
            mainHandler.post {
                panelAnswerText = text.orEmpty().trim()
                panelThinking = thinking
                panelGenerating = generating
                refreshPanelText()
            }
        }

        @android.webkit.JavascriptInterface
        fun setPanelContentHeight(cssPixels: Int) {
            mainHandler.post {
                contentHeightPx = (cssPixels * context.resources.displayMetrics.density).toInt()
                relayoutAssistant()
            }
        }

        @android.webkit.JavascriptInterface
        fun hasFloatingAssistantOverlayPermission(): Boolean =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.M || android.provider.Settings.canDrawOverlays(appContext)

        @android.webkit.JavascriptInterface
        fun requestFloatingAssistantOverlay() {
            mainHandler.post {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || android.provider.Settings.canDrawOverlays(appContext)) {
                    appContext.getSharedPreferences("allbat_overlay", Context.MODE_PRIVATE).edit()
                        .putBoolean("permission_available", true)
                        .apply()
                    try { appContext.sendBroadcast(Intent(SessionForegroundService.ACTION_REFRESH_OVERLAY).setPackage(appContext.packageName)) } catch (_: Exception) { }
                    return@post
                }
                try {
                    appContext.startActivity(
                        Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${appContext.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) {
                    Toast.makeText(appContext, "تنظیم حباب شناور در دسترس نیست", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @android.webkit.JavascriptInterface fun markNextFileChooserAsCamera() = Unit
        // The offline companion is only wired into the main app screen; the system-assistant panel reports "not installed".
        @android.webkit.JavascriptInterface fun isOfflineBotInstalled(): Boolean = false
        @android.webkit.JavascriptInterface fun askOfflineBot(id: String, text: String) = Unit
        @android.webkit.JavascriptInterface fun cancelOfflineBot(id: String) = Unit
        @android.webkit.JavascriptInterface fun openOfflineBotApp() = Unit
    }
}

/** Dock silhouette: rounded top corners and concave "feet" flaring out at the bottom, like the reference. */
internal class DockBackground(private val flare: Float, private val radius: Float) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        val l = flare
        val r = w - flare
        path.reset()
        path.moveTo(0f, h)
        path.quadTo(l, h, l, h - flare)
        path.lineTo(l, radius)
        path.quadTo(l, 0f, l + radius, 0f)
        path.lineTo(r - radius, 0f)
        path.quadTo(r, 0f, r, radius)
        path.lineTo(r, h - flare)
        path.quadTo(r, h, w, h)
        path.close()
        paint.shader = LinearGradient(0f, 0f, 0f, h, Color.rgb(4, 4, 4), Color.rgb(22, 22, 22), Shader.TileMode.CLAMP)
    }

    override fun draw(canvas: Canvas) {
        canvas.drawPath(path, paint)
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
        invalidateSelf()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Glowing yellow-green to teal sphere shown in the dock. Pulses while a voice session or answer is active. */
internal class OrbView(context: Context) : View(context) {
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lightPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pulsing = false
    private var pulseAnimator: ValueAnimator? = null

    fun setPulsing(enabled: Boolean) {
        if (pulsing == enabled) return
        pulsing = enabled
        animate().cancel()
        if (enabled) {
            pulseAnimator?.cancel()
            pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1450L
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                interpolator = AccelerateDecelerateInterpolator()
                addUpdateListener { animator ->
                    val amount = animator.animatedValue as Float
                    val scale = 0.985f + (0.075f * amount)
                    scaleX = scale
                    scaleY = scale
                    alpha = 0.94f + (0.06f * amount)
                }
                start()
            }
        } else {
            pulseAnimator?.cancel()
            pulseAnimator = null
            animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220L)
                .setInterpolator(PathInterpolator(0.22f, 0f, 0f, 1f)).start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val outer = minOf(width, height) / 2f
        val r = outer * 0.74f
        glowPaint.shader = RadialGradient(
            cx, cy, outer,
            intArrayOf(Color.argb(150, 86, 217, 200), Color.argb(55, 86, 217, 200), Color.argb(0, 86, 217, 200)),
            floatArrayOf(0.55f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, outer, glowPaint)
        bodyPaint.shader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r,
            intArrayOf(Color.rgb(233, 245, 123), Color.rgb(181, 219, 79), Color.rgb(79, 185, 160), Color.rgb(60, 154, 203)),
            floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, bodyPaint)
        lightPaint.shader = RadialGradient(
            cx + r * 0.1f, cy + r * 0.38f, r * 0.8f,
            intArrayOf(Color.argb(210, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, lightPaint)
    }
}

/** ScrollView that wraps its content but never grows taller than [maxHeightPx]. */
internal class BoundedScrollView(context: Context) : android.widget.ScrollView(context) {
    var maxHeightPx: Int = Int.MAX_VALUE
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, View.MeasureSpec.makeMeasureSpec(maxHeightPx, View.MeasureSpec.AT_MOST))
    }
}
