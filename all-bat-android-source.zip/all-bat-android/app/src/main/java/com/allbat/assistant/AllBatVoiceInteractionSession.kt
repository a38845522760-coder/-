package com.allbat.assistant

import android.Manifest
import android.os.Build
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Gravity
import android.view.Window
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.widget.Toast
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.min

/**
 * Text-first assistant surface. The system screenshot is supplied by VoiceInteractionSession;
 * it is never started through MediaProjection and is never sent whole to the model. The user
 * chooses a rectangle in the web UI, and only that cropped image is attached to the draft.
 */
class AllBatVoiceInteractionSession(context: Context) : android.service.voice.VoiceInteractionSession(context) {
    companion object {
        const val ACTION_OVERLAY_MIC = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_TOGGLE_MIC"
        const val ACTION_OVERLAY_CAMERA = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_TOGGLE_CAMERA"
        const val ACTION_OVERLAY_SCREEN = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_TOGGLE_SCREEN"
        const val ACTION_OVERLAY_END = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_END_SESSION"
        const val ACTION_OVERLAY_STOP_RESPONSE = "com.allbat.assistant.overlay.SYSTEM_ASSISTANT_STOP_RESPONSE"
        // Texts taken verbatim from the reference design.
        const val DOCK_HINT = "Ask anything......."
    }

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private var assistantWebView: WebView? = null
    private var pageLoaded = false
    private var visible = false
    private var stopRequestedByUser = false
    private var sessionVoiceServiceStarted = false
    private var sessionCameraServiceStarted = false
    private var previousAudioMode: Int? = null
    private var voiceAudioFocusRequest: AudioFocusRequest? = null
    private val voiceAudioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { _ -> /* Keep duplex Live audio active; Chromium owns the stream lifecycle. */ }
    private var pendingScreenshotDataUrl: String? = null
    private var overlayReceiverRegistered = false
    private var assistantRoot: FrameLayout? = null
    private var assistantCard: FrameLayout? = null
    private var assistantDock: LinearLayout? = null
    private var assistantBackButton: View? = null
    private var assistantCloseButton: View? = null
    private var assistantOrb: OrbView? = null
    private var cardBackground: GradientDrawable? = null
    private var navigationInsetPx = 0
    private var keyboardVisible = false
    private var lastRootHeight = 0
    private var screenSelectionMode = false
    private var liveMode = false
    private var liveStartedAt = 0L
    private var contentHeightPx = 0
    private var dockText: TextView? = null
    private var dockHomeButton: View? = null
    private var dockSettingsButton: View? = null
    private var dockMicButton: View? = null

    private val sessionOverlayReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val script = when (intent?.action) {
                ACTION_OVERLAY_MIC -> "window.__allbatToggleMicrophone && window.__allbatToggleMicrophone();"
                ACTION_OVERLAY_CAMERA -> "window.__allbatToggleCamera && window.__allbatToggleCamera();"
                ACTION_OVERLAY_SCREEN -> "window.__allbatToggleScreen && window.__allbatToggleScreen();"
                ACTION_OVERLAY_END -> {
                    stopRequestedByUser = true
                    "window.__assistantNativeStopAll && window.__assistantNativeStopAll();"
                }
                ACTION_OVERLAY_STOP_RESPONSE -> "window.__allbatStopCurrentResponse && window.__allbatStopCurrentResponse();"
                else -> return
            }
            evaluate(script)
            if (intent?.action == ACTION_OVERLAY_END) {
                try { appContext.startService(Intent(appContext, SessionForegroundService::class.java).setAction(SessionForegroundService.ACTION_STOP_ALL)) } catch (_: Exception) { }
            }
        }
    }

    private fun registerSessionOverlayReceiver() {
        if (overlayReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(ACTION_OVERLAY_MIC)
            addAction(ACTION_OVERLAY_CAMERA)
            addAction(ACTION_OVERLAY_SCREEN)
            addAction(ACTION_OVERLAY_END)
            addAction(ACTION_OVERLAY_STOP_RESPONSE)
        }
        try {
            ContextCompat.registerReceiver(appContext, sessionOverlayReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            overlayReceiverRegistered = true
        } catch (error: Exception) {
            android.util.Log.w("AllBatOverlay", "Could not register system-assistant overlay controls", error)
        }
    }

    override fun onCreateContentView(): View {
        registerSessionOverlayReceiver()
        // Full-screen transparent layer: dark chat card on top, dock at the bottom.
        // The layout is forced LTR so the controls keep the exact positions of the reference design.
        val root = FrameLayout(context).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setOnClickListener { hide() } // tapping outside the card/dock closes the panel
            layoutTransition = android.animation.LayoutTransition().apply {
                enableTransitionType(android.animation.LayoutTransition.CHANGING)
            }
        }
        assistantRoot = root
        cardBackground = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.rgb(0, 0, 0), Color.rgb(32, 32, 32))
        ).apply { cornerRadius = dp(28).toFloat() }
        val card = FrameLayout(context).apply {
            background = cardBackground
            clipToOutline = true
            elevation = dp(10).toFloat()
            isClickable = true
        }
        assistantCard = card
        root.addView(
            card,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, defaultCardHeightPx(), Gravity.BOTTOM).apply {
                setMargins(dp(14), 0, dp(14), dp(92))
            }
        )


        val web = WebView(context).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                cacheMode = WebSettings.LOAD_DEFAULT
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                allowFileAccess = false
                allowContentAccess = false
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                safeBrowsingEnabled = true
                loadsImagesAutomatically = true
            }
            addJavascriptInterface(SessionBridge(), "AndroidAssistant")
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    mainHandler.post {
                        val origin = request.origin
                        if (!origin.scheme.equals("https", true) || !origin.host.equals(BuildConfig.SPACE_HOST, true)) {
                            request.deny()
                            return@post
                        }
                        val allowed = request.resources.filter { resource ->
                            when (resource) {
                                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                                else -> false
                            }
                        }.toTypedArray()
                        if (allowed.isNotEmpty()) request.grant(allowed) else request.deny()
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    if (uri.scheme.equals("https", true) && uri.host.equals(BuildConfig.SPACE_HOST, true)) return false
                    if (uri.scheme.equals("about", true) || uri.scheme.equals("blob", true) || uri.scheme.equals("data", true)) return false
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    pageLoaded = true
                    if (visible) evaluate("window.__allbatAssistantPanelMode && window.__allbatAssistantPanelMode(true);")
                    deliverPendingScreenshot()
                }
            }
        }
        assistantWebView = web
        ScreenCaptureService.frameSink = { frame ->
            mainHandler.post {
                if (pageLoaded && assistantWebView != null) {
                    assistantWebView?.evaluateJavascript(
                        "window.__assistantNativeFrame && window.__assistantNativeFrame(${JSONObject.quote(frame)});",
                        null
                    )
                }
            }
        }
        ScreenCaptureService.statusSink = { active ->
            mainHandler.post {
                if (assistantWebView != null) {
                    val function = if (active) "__assistantNativeScreenStarted" else "__assistantNativeScreenStopped"
                    assistantWebView?.evaluateJavascript("window.$function && window.$function();", null)
                }
            }
        }
        ScreenProjectionPermissionActivity.resultSink = { granted ->
            if (!granted) evaluate("window.__assistantNativeScreenDenied && window.__assistantNativeScreenDenied();")
        }
        card.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val backButton = chromeButton(R.drawable.ic_assistant_back, "Back") { hide() }
        card.addView(backButton, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.LEFT).apply { setMargins(dp(10), dp(10), 0, 0) })
        val closeButton = chromeButton(R.drawable.ic_assistant_close, "Close") { closeAssistant() }
        card.addView(closeButton, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.RIGHT).apply { setMargins(0, dp(10), dp(10), 0) })
        assistantBackButton = backButton
        assistantCloseButton = closeButton
        root.addView(
            buildDock(),
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(78), Gravity.BOTTOM).apply { setMargins(dp(14), 0, dp(14), dp(12)) }
        )
        installSystemInsetTracking(root)

        try {
            val html = appContext.assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            web.loadDataWithBaseURL(BuildConfig.SPACE_BASE_URL, html, "text/html", "UTF-8", null)
        } catch (error: Exception) {
            val safeError = error.javaClass.simpleName
            web.loadDataWithBaseURL(
                BuildConfig.SPACE_BASE_URL,
                "<!doctype html><html lang='fa' dir='rtl'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><body style='font-family:system-ui;padding:24px'><h3>رابط دستیار بارگذاری نشد</h3><p>ساخت برنامه را بررسی کن.</p><code>$safeError</code></body></html>",
                "text/html", "UTF-8", null
            )
        }
        return root
    }

    override fun onComputeInsets(outInsets: android.service.voice.VoiceInteractionSession.Insets) {
        super.onComputeInsets(outInsets)
        // Keep the underlying app full-size: the assistant is a floating layer, not a split view.
        outInsets.contentInsets.set(0, 0, 0, 0)
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        visible = true
        screenSelectionMode = false
        assistantWebView?.onResume()
        try {
            window?.setCancelable(true)
            window?.setCanceledOnTouchOutside(true)
            val activityWindow: Window? = window?.window
            activityWindow?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            activityWindow?.setWindowAnimations(R.style.AssistantSheetWindowAnimation)
            activityWindow?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
            activityWindow?.setGravity(Gravity.BOTTOM)
            val windowParams = activityWindow?.attributes
            if (windowParams != null) {
                windowParams.gravity = Gravity.BOTTOM
                windowParams.dimAmount = 0f
                windowParams.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                activityWindow.attributes = windowParams
            }
            relayoutAssistant()
        } catch (error: Exception) {
            android.util.Log.w("AllBatAssistant", "Could not configure assistant sheet window", error)
        }
        stopRequestedByUser = false
        liveMode = false
        dockText?.text = DOCK_HINT
        publishAssistantSurfaceVisibility(true)
        // Holding Home opens a fresh text conversation. Live is started only when the user
        // explicitly presses the microphone control inside the composer.
        if (pageLoaded) evaluate("window.__allbatAssistantPanelMode && window.__allbatAssistantPanelMode(true);")
        try { appContext.sendBroadcast(Intent(SessionForegroundService.ACTION_REFRESH_OVERLAY).setPackage(appContext.packageName)) } catch (_: Exception) { }
        deliverPendingScreenshot()
    }

    private fun defaultCardHeightPx(): Int {
        val screenHeight = context.resources.displayMetrics.heightPixels.coerceAtLeast(dp(420))
        val maxHeight = (screenHeight * 0.62f).toInt()
        val wanted = if (contentHeightPx > 0) contentHeightPx else dp(220)
        return wanted.coerceIn(dp(170), maxHeight)
    }

    private fun chromeButton(iconRes: Int, description: String, padding: Int = dp(10), onClick: () -> Unit): ImageView =
        ImageView(context).apply {
            setImageResource(iconRes)
            contentDescription = description
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(padding, padding, padding, padding)
            setOnClickListener { onClick() }
        }

    /** Bottom dock from the reference: home, glowing orb, "Ask anything......." pill with mic, settings. */
    private fun buildDock(): LinearLayout {
        val dock = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(4, 4, 4), Color.rgb(20, 20, 20))
            ).apply { cornerRadius = dp(39).toFloat() }
            elevation = dp(8).toFloat()
            setPadding(dp(18), dp(4), dp(18), dp(4))
            minimumHeight = dp(78)
            isClickable = true
        }
        val homeBtn = chromeButton(R.drawable.ic_assistant_home, "Open app", dp(5)) { openAppFromAssistant() }
        dockHomeButton = homeBtn
        dock.addView(homeBtn, LinearLayout.LayoutParams(dp(36), dp(44)))
        val orb = OrbView(context).apply {
            contentDescription = "Voice conversation"
            setOnClickListener { toggleLiveFromDock() }
        }
        assistantOrb = orb
        dock.addView(orb, LinearLayout.LayoutParams(dp(54), dp(54)).apply { setMargins(dp(4), 0, dp(4), 0) })

        val pill = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(21).toFloat()
                setColor(Color.rgb(43, 43, 43))
            }
            setPadding(dp(16), dp(8), dp(6), dp(8))
            minimumHeight = dp(42)
            setOnClickListener { if (!liveMode) focusComposer() }
        }
        val hint = TextView(context).apply {
            text = DOCK_HINT
            setTextColor(Color.rgb(236, 236, 236))
            textSize = 15f
            maxLines = 4
            ellipsize = android.text.TextUtils.TruncateAt.END
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        }
        dockText = hint
        pill.addView(hint, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val micBtn = chromeButton(R.drawable.ic_assistant_mic, "Start voice", dp(7)) { toggleLiveFromDock() }
        dockMicButton = micBtn
        pill.addView(micBtn, LinearLayout.LayoutParams(dp(34), dp(34)))
        dock.addView(pill, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(6), 0, dp(6), 0) })

        val settingsBtn = chromeButton(R.drawable.ic_assistant_settings, "Assistant settings", dp(5)) { openAssistantSettings() }
        dockSettingsButton = settingsBtn
        dock.addView(settingsBtn, LinearLayout.LayoutParams(dp(36), dp(44)))
        assistantDock = dock
        return dock
    }

    private fun installSystemInsetTracking(root: View) {
        root.setOnApplyWindowInsetsListener { _, insets ->
            @Suppress("DEPRECATION")
            var bottom = insets.stableInsetBottom
            if (bottom <= 0) {
                val id = context.resources.getIdentifier("navigation_bar_height", "dimen", "android")
                if (id > 0) bottom = context.resources.getDimensionPixelSize(id)
            }
            if (bottom != navigationInsetPx) {
                navigationInsetPx = bottom
                relayoutAssistant()
            }
            insets
        }
        root.viewTreeObserver.addOnGlobalLayoutListener {
            val height = root.height
            if (height > 0) {
                val screen = context.resources.displayMetrics.heightPixels
                val keyboard = height < screen * 0.75f
                if (keyboard != keyboardVisible || height != lastRootHeight) {
                    keyboardVisible = keyboard
                    lastRootHeight = height
                    relayoutAssistant()
                }
            }
        }
    }

    /** Positions the card above the dock; hides the dock while the keyboard is open or a region is being selected. */
    private fun relayoutAssistant() {
        val card = assistantCard ?: return
        val dock = assistantDock ?: return
        val root = assistantRoot ?: return
        val params = card.layoutParams as? FrameLayout.LayoutParams ?: return
        if (screenSelectionMode) {
            params.width = ViewGroup.LayoutParams.MATCH_PARENT
            params.height = ViewGroup.LayoutParams.MATCH_PARENT
            params.setMargins(0, 0, 0, 0)
            card.background = ColorDrawable(Color.TRANSPARENT)
            card.clipToOutline = false
            card.elevation = 0f
            dock.visibility = View.GONE
            assistantBackButton?.visibility = View.GONE
            assistantCloseButton?.visibility = View.GONE
        } else {
            val dockBottom = dp(12) + navigationInsetPx
            val bottomMargin = if (keyboardVisible) dp(8) else dp(78) + dockBottom + dp(14)
            val rootHeight = if (root.height > 0) root.height else context.resources.displayMetrics.heightPixels
            val available = (rootHeight - bottomMargin - dp(24)).coerceAtLeast(dp(180))
            params.width = ViewGroup.LayoutParams.MATCH_PARENT
            params.height = minOf(defaultCardHeightPx(), available)
            params.setMargins(dp(14), 0, dp(14), bottomMargin)
            card.background = cardBackground
            card.clipToOutline = true
            card.elevation = dp(10).toFloat()
            // Keep the WebView attached and visible in Live mode (Chromium throttles hidden views);
            // the card is just moved off-screen so only the dock is seen.
            card.visibility = View.VISIBLE
            card.alpha = if (liveMode) 0f else 1f
            card.translationY = if (liveMode) context.resources.displayMetrics.heightPixels.toFloat() else 0f
            assistantBackButton?.visibility = View.VISIBLE
            assistantCloseButton?.visibility = View.VISIBLE
            val chromeVisibility = if (liveMode) View.GONE else View.VISIBLE
            dockHomeButton?.visibility = chromeVisibility
            dockSettingsButton?.visibility = chromeVisibility
            dockMicButton?.visibility = chromeVisibility
            val dockParams = dock.layoutParams as? FrameLayout.LayoutParams
            if (dockParams != null) {
                dockParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
                dockParams.setMargins(dp(14), 0, dp(14), dockBottom)
                dock.layoutParams = dockParams
            }
            dock.visibility = if (keyboardVisible) View.GONE else View.VISIBLE
        }
        card.layoutParams = params
    }

    private fun setScreenSelectionMode(enabled: Boolean) {
        if (!visible || screenSelectionMode == enabled) return
        screenSelectionMode = enabled
        relayoutAssistant()
    }

    private fun setLiveMode(enabled: Boolean) {
        if (liveMode == enabled) return
        liveMode = enabled
        if (!enabled) dockText?.text = DOCK_HINT
        assistantOrb?.setPulsing(enabled)
        relayoutAssistant()
    }

    /** In Live mode the dock only shows the active orb and the live transcript text. */
    private fun updateDockText(userText: String?, answerText: String?, status: String?) {
        val text = when {
            !answerText.isNullOrBlank() -> answerText
            !userText.isNullOrBlank() -> userText
            else -> status.orEmpty()
        }.trim()
        dockText?.text = if (text.isEmpty()) "…" else text.takeLast(200)
    }

    private fun focusComposer() {
        val web = assistantWebView ?: return
        web.requestFocus()
        evaluate("(function(){var i=document.getElementById('inp'); if(i){i.focus();}})();")
        mainHandler.postDelayed({
            try {
                val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(web, InputMethodManager.SHOW_IMPLICIT)
            } catch (_: Exception) { }
        }, 120)
    }

    private fun toggleLiveFromDock() {
        evaluate("(function(){var b=document.getElementById('voiceChatBtn'); if(b){b.click();}})();")
    }

    private fun closeAssistant() {
        val live = appContext.getSharedPreferences("allbat_session_state", Context.MODE_PRIVATE).getBoolean("voice_active", false)
        if (live) {
            stopRequestedByUser = true
            evaluate("window.__assistantNativeStopAll && window.__assistantNativeStopAll();")
            try { appContext.startService(Intent(appContext, SessionForegroundService::class.java).setAction(SessionForegroundService.ACTION_STOP_ALL)) } catch (_: Exception) { }
        }
        hide()
    }

    private fun launchFromAssistant(intent: Intent) {
        try {
            if (Build.VERSION.SDK_INT >= 34) startAssistantActivity(intent, Bundle.EMPTY)
            else appContext.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (error: Exception) {
            Toast.makeText(appContext, "بازکردن این بخش ممکن نشد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openAppFromAssistant() {
        launchFromAssistant(Intent(appContext, MainActivity::class.java))
        hide()
    }

    private fun openAssistantSettings() {
        launchFromAssistant(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        hide()
    }

    private fun publishAssistantSurfaceVisibility(visible: Boolean) {
        appContext.getSharedPreferences("allbat_session_state", Context.MODE_PRIVATE).edit()
            .putBoolean("assistant_surface_visible", visible)
            .apply()
        try {
            appContext.sendBroadcast(Intent(SessionForegroundService.ACTION_SURFACE_VISIBILITY)
                .setPackage(appContext.packageName).apply {
                    putExtra(SessionForegroundService.EXTRA_SURFACE_OWNER, "assistant")
                    putExtra(SessionForegroundService.EXTRA_SURFACE_VISIBLE, visible)
                })
        } catch (error: Exception) {
            android.util.Log.w("AllBatOverlay", "Could not publish assistant surface visibility", error)
        }
    }

    override fun onHandleScreenshot(screenshot: Bitmap?) {
        if (screenshot == null) {
            pendingScreenshotDataUrl = null
            evaluate("window.__allbatAssistantScreenshotUnavailable && window.__allbatAssistantScreenshotUnavailable();")
            return
        }
        try {
            pendingScreenshotDataUrl = encodeScreenshot(screenshot)
            deliverPendingScreenshot()
        } catch (error: Exception) {
            pendingScreenshotDataUrl = null
            android.util.Log.w("AllBatAssistant", "Could not prepare assistant screenshot", error)
            evaluate("window.__allbatAssistantScreenshotUnavailable && window.__allbatAssistantScreenshotUnavailable();")
        }
    }

    private fun encodeScreenshot(source: Bitmap): String {
        var resized: Bitmap? = null
        val bitmap: Bitmap
        val ratio = min(1f, 1600f / source.width.toFloat())
        if (ratio < 1f) {
            resized = Bitmap.createScaledBitmap(source, maxOf(1, (source.width * ratio).toInt()), maxOf(1, (source.height * ratio).toInt()), true)
            bitmap = resized
        } else {
            bitmap = source
        }
        val out = ByteArrayOutputStream()
        try {
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 68, out)) throw IllegalStateException("JPEG encoding failed")
            return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } finally {
            if (resized != null && resized !== source) resized.recycle()
            try { out.close() } catch (_: Exception) { }
        }
    }

    private fun deliverPendingScreenshot() {
        if (!pageLoaded || !visible) return
        val data = pendingScreenshotDataUrl ?: return
        evaluate("window.__allbatAssistantSetScreenshot && window.__allbatAssistantSetScreenshot(${JSONObject.quote(data)});")
    }

    private fun evaluate(script: String) {
        mainHandler.post { assistantWebView?.evaluateJavascript(script, null) }
    }

    private fun prepareCommunicationAudio() {
        val manager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            if (previousAudioMode == null) previousAudioMode = manager.mode
            manager.mode = AudioManager.MODE_IN_COMMUNICATION
        } catch (error: Exception) {
            android.util.Log.w("AllBatAudio", "Could not set communication mode for assistant session", error)
        }
        try {
            val request = voiceAudioFocusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAcceptsDelayedFocusGain(false)
                .setOnAudioFocusChangeListener(voiceAudioFocusChangeListener)
                .build()
                .also { voiceAudioFocusRequest = it }
            manager.requestAudioFocus(request)
        } catch (error: Exception) {
            android.util.Log.w("AllBatAudio", "Could not acquire assistant-session audio focus", error)
        }
    }

    private fun restoreCommunicationAudio() {
        val manager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try { voiceAudioFocusRequest?.let { manager.abandonAudioFocusRequest(it) } } catch (_: Exception) { }
        voiceAudioFocusRequest = null
        val mode = previousAudioMode
        if (mode != null) {
            try { manager.mode = mode } catch (_: Exception) { }
            previousAudioMode = null
        }
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    override fun onHide() {
        visible = false
        screenSelectionMode = false
        publishAssistantSurfaceVisibility(false)
        pendingScreenshotDataUrl = null
        evaluate("window.__allbatAssistantClearScreenshot && window.__allbatAssistantClearScreenshot(); window.__allbatAssistantPanelMode && window.__allbatAssistantPanelMode(false);")
        // Dismissing the panel is not an implicit hang-up. A user-started Live session may continue
        // in the foreground service; the next Home invocation intentionally creates a new text chat.
        super.onHide()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            hide()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        visible = false
        screenSelectionMode = false
        publishAssistantSurfaceVisibility(false)
        try { if (overlayReceiverRegistered) appContext.unregisterReceiver(sessionOverlayReceiver) } catch (_: Exception) { }
        overlayReceiverRegistered = false
        if (stopRequestedByUser) {
            try { appContext.startService(Intent(appContext, SessionForegroundService::class.java).setAction(SessionForegroundService.ACTION_STOP_ALL)) } catch (_: Exception) { }
        }
        sessionVoiceServiceStarted = false
        sessionCameraServiceStarted = false
        val stillActive = appContext.getSharedPreferences("allbat_session_state", Context.MODE_PRIVATE).getBoolean("voice_active", false)
        if (stopRequestedByUser || !stillActive) restoreCommunicationAudio()
        ScreenCaptureService.frameSink = null
        ScreenCaptureService.statusSink = null
        ScreenProjectionPermissionActivity.resultSink = null
        assistantWebView?.apply {
            removeJavascriptInterface("AndroidAssistant")
            stopLoading()
            destroy()
        }
        assistantWebView = null
        super.onDestroy()
    }

    inner class SessionBridge {
        @android.webkit.JavascriptInterface
        fun selectScreenRegion() {
            mainHandler.post {
                if (pendingScreenshotDataUrl.isNullOrEmpty()) {
                    evaluate("window.__allbatAssistantScreenshotUnavailable && window.__allbatAssistantScreenshotUnavailable();")
                } else {
                    evaluate("window.__allbatAssistantStartRegionSelection && window.__allbatAssistantStartRegionSelection();")
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun beginScreenRegionSelection() {
            mainHandler.post { setScreenSelectionMode(true) }
        }

        @android.webkit.JavascriptInterface
        fun finishScreenRegionSelection() {
            mainHandler.post { setScreenSelectionMode(false) }
        }

        @android.webkit.JavascriptInterface
        fun startScreenShare() {
            mainHandler.post {
                try {
                    val request = Intent(appContext, ScreenProjectionPermissionActivity::class.java)
                    if (Build.VERSION.SDK_INT >= 34) startAssistantActivity(request, Bundle.EMPTY)
                    else appContext.startActivity(request.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (error: Exception) {
                    Toast.makeText(appContext, "بازکردن مجوز اشتراک صفحه ممکن نشد", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun stopScreenShare() {
            mainHandler.post { appContext.stopService(Intent(appContext, ScreenCaptureService::class.java)) }
        }

        @android.webkit.JavascriptInterface
        fun requestDefaultAssistant() {
            mainHandler.post {
                Toast.makeText(appContext, "برای تغییر دستیار پیش‌فرض، برنامه را از صفحهٔ اصلی باز کن", Toast.LENGTH_SHORT).show()
            }
        }

        @android.webkit.JavascriptInterface
        fun isDefaultAssistant(): Boolean = true

        @android.webkit.JavascriptInterface
        fun isAssistantSession(): Boolean = true

        @android.webkit.JavascriptInterface
        fun appVersion(): String = BuildConfig.VERSION_NAME

        // The microphone is enabled only when the user explicitly presses Live in the assistant.
        @android.webkit.JavascriptInterface
        fun prepareAudioSession() {
            mainHandler.post { prepareCommunicationAudio() }
        }

        @android.webkit.JavascriptInterface
        fun cancelAudioSession() {
            mainHandler.post { restoreCommunicationAudio() }
        }

        @android.webkit.JavascriptInterface
        fun startVoiceSession() {
            mainHandler.post {
                if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(appContext, "ابتدا برنامه را باز کن و مجوز میکروفون را بده.", Toast.LENGTH_LONG).show()
                    return@post
                }
                try {
                    prepareCommunicationAudio()
                    ContextCompat.startForegroundService(
                        appContext,
                        Intent(appContext, SessionForegroundService::class.java)
                            .setAction(SessionForegroundService.ACTION_START_VOICE)
                            .putExtra(SessionForegroundService.EXTRA_OVERLAY_OWNER, "system_assistant")
                    )
                    sessionVoiceServiceStarted = true
                    liveStartedAt = android.os.SystemClock.uptimeMillis()
                    setLiveMode(true)
                    // Live itself does not depend on overlay permission. The bubble is optional
                    // and appears later only if Android has granted draw-over-apps access.
                } catch (error: Exception) {
                    Toast.makeText(appContext, "شروع نشست صوتی ممکن نشد", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun stopVoiceSession() {
            mainHandler.post {
                sessionVoiceServiceStarted = false
                setLiveMode(false)
                appContext.startService(Intent(appContext, SessionForegroundService::class.java).setAction(SessionForegroundService.ACTION_STOP_VOICE))
                restoreCommunicationAudio()
            }
        }

        @android.webkit.JavascriptInterface
        fun startCameraSession() {
            mainHandler.post {
                if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(appContext, "برای روشن‌کردن دوربین، ابتدا برنامه را باز و مجوز دوربین را تأیید کن.", Toast.LENGTH_LONG).show()
                    return@post
                }
                try {
                    ContextCompat.startForegroundService(
                        appContext,
                        Intent(appContext, SessionForegroundService::class.java)
                            .setAction(SessionForegroundService.ACTION_START_CAMERA)
                            .putExtra(SessionForegroundService.EXTRA_OVERLAY_OWNER, "system_assistant")
                    )
                    sessionCameraServiceStarted = true
                } catch (_: Exception) { }
            }
        }

        @android.webkit.JavascriptInterface
        fun stopCameraSession() {
            mainHandler.post {
                sessionCameraServiceStarted = false
                appContext.startService(Intent(appContext, SessionForegroundService::class.java).setAction(SessionForegroundService.ACTION_STOP_CAMERA))
            }
        }

        @android.webkit.JavascriptInterface
        fun updateAssistantOverlay(
            userText: String?, answerText: String?, status: String?, generating: Boolean,
            micMuted: Boolean, cameraActive: Boolean, screenActive: Boolean
        ) {
            val liveActive = appContext.getSharedPreferences("allbat_session_state", Context.MODE_PRIVATE).getBoolean("voice_active", false)
            mainHandler.post {
                if (liveActive) setLiveMode(true)
                else if (android.os.SystemClock.uptimeMillis() - liveStartedAt > 4000L) setLiveMode(false)
                assistantOrb?.setPulsing(generating || liveMode)
                if (liveMode) updateDockText(userText, answerText, status)
            }
            val update = Intent(SessionForegroundService.ACTION_UPDATE_OVERLAY).setPackage(appContext.packageName).apply {
                putExtra(SessionForegroundService.EXTRA_USER_TEXT, userText.orEmpty().take(600))
                putExtra(SessionForegroundService.EXTRA_ANSWER_TEXT, answerText.orEmpty().take(3000))
                putExtra(SessionForegroundService.EXTRA_STATUS, status.orEmpty().take(100))
                putExtra(SessionForegroundService.EXTRA_GENERATING, generating)
                putExtra(SessionForegroundService.EXTRA_MIC_MUTED, micMuted)
                putExtra(SessionForegroundService.EXTRA_CAMERA_ACTIVE, cameraActive)
                putExtra(SessionForegroundService.EXTRA_SCREEN_ACTIVE, screenActive)
                putExtra(SessionForegroundService.EXTRA_OVERLAY_OWNER, "system_assistant")
            }
            try { appContext.sendBroadcast(update) } catch (_: Exception) { }
        }

        @android.webkit.JavascriptInterface
        fun setPanelContentHeight(cssPixels: Int) {
            mainHandler.post {
                contentHeightPx = (cssPixels * context.resources.displayMetrics.density).toInt()
                relayoutAssistant()
            }
        }

        @android.webkit.JavascriptInterface
        fun hasFloatingAssistantOverlayPermission(): Boolean =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.M || android.provider.Settings.canDrawOverlays(appContext)

        @android.webkit.JavascriptInterface
        fun requestFloatingAssistantOverlay() {
            mainHandler.post {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || android.provider.Settings.canDrawOverlays(appContext)) {
                    appContext.getSharedPreferences("allbat_overlay", Context.MODE_PRIVATE).edit()
                        .putBoolean("permission_available", true)
                        .apply()
                    try { appContext.sendBroadcast(Intent(SessionForegroundService.ACTION_REFRESH_OVERLAY).setPackage(appContext.packageName)) } catch (_: Exception) { }
                    return@post
                }
                try {
                    appContext.startActivity(
                        Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${appContext.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) {
                    Toast.makeText(appContext, "تنظیم حباب شناور در دسترس نیست", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @android.webkit.JavascriptInterface fun markNextFileChooserAsCamera() = Unit
    }
}

/** Dock silhouette: rounded top corners and concave "feet" flaring out at the bottom, like the reference. */
internal class DockBackground(private val flare: Float, private val radius: Float) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        val l = flare
        val r = w - flare
        path.reset()
        path.moveTo(0f, h)
        path.quadTo(l, h, l, h - flare)
        path.lineTo(l, radius)
        path.quadTo(l, 0f, l + radius, 0f)
        path.lineTo(r - radius, 0f)
        path.quadTo(r, 0f, r, radius)
        path.lineTo(r, h - flare)
        path.quadTo(r, h, w, h)
        path.close()
        paint.shader = LinearGradient(0f, 0f, 0f, h, Color.rgb(4, 4, 4), Color.rgb(22, 22, 22), Shader.TileMode.CLAMP)
    }

    override fun draw(canvas: Canvas) {
        canvas.drawPath(path, paint)
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
        invalidateSelf()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Glowing yellow-green to teal sphere shown in the dock. Pulses while a voice session or answer is active. */
internal class OrbView(context: Context) : View(context) {
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lightPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pulsing = false

    fun setPulsing(enabled: Boolean) {
        if (pulsing == enabled) return
        pulsing = enabled
        animate().cancel()
        if (enabled) pulseStep(true) else animate().scaleX(1f).scaleY(1f).setDuration(160).start()
    }

    private fun pulseStep(grow: Boolean) {
        if (!pulsing) return
        val target = if (grow) 1.1f else 0.95f
        animate().scaleX(target).scaleY(target).setDuration(650).withEndAction { pulseStep(!grow) }.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val outer = minOf(width, height) / 2f
        val r = outer * 0.74f
        glowPaint.shader = RadialGradient(
            cx, cy, outer,
            intArrayOf(Color.argb(150, 86, 217, 200), Color.argb(55, 86, 217, 200), Color.argb(0, 86, 217, 200)),
            floatArrayOf(0.55f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, outer, glowPaint)
        bodyPaint.shader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r,
            intArrayOf(Color.rgb(233, 245, 123), Color.rgb(181, 219, 79), Color.rgb(79, 185, 160), Color.rgb(60, 154, 203)),
            floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, bodyPaint)
        lightPaint.shader = RadialGradient(
            cx + r * 0.1f, cy + r * 0.38f, r * 0.8f,
            intArrayOf(Color.argb(210, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, lightPaint)
    }
}
