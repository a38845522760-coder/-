package com.allbat.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.content.pm.PackageManager
import android.net.Uri
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingCameraPhotoUri: Uri? = null
    private var pendingCameraPhotoFile: File? = null
    @Volatile private var forceNextFileChooserCamera = false
    private var previousAudioMode: Int? = null
    private var voiceAudioFocusRequest: AudioFocusRequest? = null
    private val voiceAudioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { _ -> /* Keep full-duplex Live audio active; the browser owns its stream lifecycle. */ }
    private var pendingWebPermission: PermissionRequest? = null
    private var pendingWebResources: Array<String> = emptyArray()
    private var pendingNativeAction: String? = null
    private var pendingForegroundPermission: String? = null
    private var pendingForegroundAction: String? = null
    private var pendingStopAction: String? = null
    private var pendingAssistantLaunch = false
    private var overlayReceiverRegistered = false
    private var offlineBotClient: OfflineBotClient? = null

    /** Companion app "All Bat آفلاین": answers questions on the phone when there is no internet. */
    val offlineBot: OfflineBotClient
        get() = offlineBotClient ?: OfflineBotClient(this) { id, kind, text, code ->
            runOnUiThread {
                if (::webView.isInitialized) {
                    webView.evaluateJavascript(
                        "window.__allbatOfflineBotEvent && window.__allbatOfflineBotEvent(" +
                            "${JSONObject.quote(id)},${JSONObject.quote(kind)},${JSONObject.quote(text)},${JSONObject.quote(code)});",
                        null
                    )
                }
            }
        }.also { offlineBotClient = it }
    private var pendingOverlayPermissionAfterMic = false

    private val overlayActionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            runOnUiThread {
                if (!::webView.isInitialized || isFinishing) return@runOnUiThread
                val script = when (action) {
                    ACTION_OVERLAY_MIC -> "window.__allbatToggleMicrophone && window.__allbatToggleMicrophone();"
                    ACTION_OVERLAY_CAMERA -> "window.__allbatToggleCamera && window.__allbatToggleCamera();"
                    ACTION_OVERLAY_SCREEN -> "window.__allbatToggleScreen && window.__allbatToggleScreen();"
                    ACTION_OVERLAY_END -> "window.__assistantNativeStopAll && window.__assistantNativeStopAll();"
                    ACTION_OVERLAY_STOP_RESPONSE -> "window.__allbatStopCurrentResponse && window.__allbatStopCurrentResponse();"
                    ACTION_OVERLAY_OPEN -> "window.__allbatOverlayOpenApp && window.__allbatOverlayOpenApp();"
                    else -> return@runOnUiThread
                }
                webView.evaluateJavascript(script, null)
                if (action == ACTION_OVERLAY_OPEN) {
                    try {
                        startActivity(Intent(this@MainActivity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                    } catch (_: Exception) { }
                }
            }
        }
    }

    companion object {
        const val ACTION_STOP_ALL = "com.allbat.assistant.action.STOP_ALL_FROM_NOTIFICATION"
        const val ACTION_STOP_SCREEN = "com.allbat.assistant.action.STOP_SCREEN_FROM_NOTIFICATION"
        const val ACTION_OVERLAY_MIC = "com.allbat.assistant.overlay.TOGGLE_MIC"
        const val ACTION_OVERLAY_CAMERA = "com.allbat.assistant.overlay.TOGGLE_CAMERA"
        const val ACTION_OVERLAY_SCREEN = "com.allbat.assistant.overlay.TOGGLE_SCREEN"
        const val ACTION_OVERLAY_END = "com.allbat.assistant.overlay.END_SESSION"
        const val ACTION_OVERLAY_STOP_RESPONSE = "com.allbat.assistant.overlay.STOP_RESPONSE"
        const val ACTION_OVERLAY_OPEN = "com.allbat.assistant.overlay.OPEN_APP"
        private const val REQUEST_FILE_CHOOSER = 4201
        private const val REQUEST_ASSISTANT_ROLE = 4203
        private const val REQUEST_WEB_PERMISSION = 4204
        private const val REQUEST_NATIVE_PERMISSION = 4205
        private const val REQUEST_NOTIFICATION_PERMISSION = 4206
        private const val REQUEST_CAMERA_FOR_CHOOSER = 4207
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingStopAction = intent?.action?.takeIf { it == ACTION_STOP_ALL || it == ACTION_STOP_SCREEN }
        pendingAssistantLaunch = intent?.getBooleanExtra("launched_from_assistant_role", false) == true
        warmUpSpace()
        configureWebView()
        attachScreenCaptureCallbacks()
        registerOverlayActionReceiver()
    }

    /**
     * Wakes the Hugging Face Space (free Spaces sleep when idle) and warms DNS/TLS in parallel with
     * the WebView start-up, so the first chat request does not pay the cold-start delay.
     * Best effort only: any failure is ignored and nothing is read from the response.
     */
    private fun warmUpSpace() {
        Thread {
            var connection: java.net.HttpURLConnection? = null
            try {
                connection = (java.net.URL(BuildConfig.SPACE_BASE_URL).openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "HEAD"
                    connectTimeout = 8000
                    readTimeout = 20000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "AllBatAndroid/warmup")
                }
                connection.responseCode
            } catch (_: Exception) {
            } finally {
                try { connection?.disconnect() } catch (_: Exception) {}
            }
        }.apply { isDaemon = true; name = "space-warmup" }.start()
    }

    private fun registerOverlayActionReceiver() {
        if (overlayReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(ACTION_OVERLAY_MIC)
            addAction(ACTION_OVERLAY_CAMERA)
            addAction(ACTION_OVERLAY_SCREEN)
            addAction(ACTION_OVERLAY_END)
            addAction(ACTION_OVERLAY_STOP_RESPONSE)
            addAction(ACTION_OVERLAY_OPEN)
        }
        try {
            ContextCompat.registerReceiver(this, overlayActionReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            overlayReceiverRegistered = true
        } catch (error: Exception) {
            android.util.Log.w("AllBatOverlay", "Could not register overlay controls", error)
        }
    }

    private fun broadcastOverlayUpdate(
        userText: String,
        answerText: String,
        status: String,
        generating: Boolean,
        micMuted: Boolean,
        cameraActive: Boolean,
        screenActive: Boolean
    ) {
        val intent = Intent(SessionForegroundService.ACTION_UPDATE_OVERLAY).setPackage(packageName).apply {
            putExtra(SessionForegroundService.EXTRA_USER_TEXT, userText.take(600))
            putExtra(SessionForegroundService.EXTRA_ANSWER_TEXT, answerText.take(3000))
            putExtra(SessionForegroundService.EXTRA_STATUS, status.take(100))
            putExtra(SessionForegroundService.EXTRA_GENERATING, generating)
            putExtra(SessionForegroundService.EXTRA_MIC_MUTED, micMuted)
            putExtra(SessionForegroundService.EXTRA_CAMERA_ACTIVE, cameraActive)
            putExtra(SessionForegroundService.EXTRA_SCREEN_ACTIVE, screenActive)
            putExtra(SessionForegroundService.EXTRA_OVERLAY_OWNER, "main")
        }
        try { sendBroadcast(intent) } catch (error: Exception) {
            android.util.Log.w("AllBatOverlay", "Could not publish assistant overlay state", error)
        }
    }

    private fun ensureFloatingOverlayPermission(forcePrompt: Boolean = false) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
            getSharedPreferences("allbat_overlay", MODE_PRIVATE).edit()
                .putBoolean("permission_available", true)
                .apply()
            // Permission alone never displays the orb. The foreground service shows it only
            // while Live is active and every app/assistant surface is in the background.
            sendBroadcast(Intent(SessionForegroundService.ACTION_REFRESH_OVERLAY).setPackage(packageName))
            return
        }
        val prefs = getSharedPreferences("allbat_overlay", MODE_PRIVATE)
        if (!forcePrompt && prefs.getBoolean("permission_prompted", false)) {
            showToast("برای نمایش حباب شناور، از ابزارهای دستیار گزینهٔ «فعال‌کردن حباب شناور» را بزن.")
            return
        }
        prefs.edit().putBoolean("permission_prompted", true).putBoolean("refresh_on_resume", true).apply()
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (_: Exception) {
            showToast("تنظیم نمایش روی برنامه‌های دیگر در این دستگاه در دسترس نیست")
        }
    }

    private fun attachScreenCaptureCallbacks() {
        ScreenCaptureService.frameSink = { frame ->
            runOnUiThread {
                if (::webView.isInitialized && !isFinishing) {
                    val safe = JSONObject.quote(frame)
                    webView.evaluateJavascript("window.__assistantNativeFrame && window.__assistantNativeFrame($safe);", null)
                }
            }
        }
        ScreenCaptureService.statusSink = { active ->
            runOnUiThread {
                if (::webView.isInitialized && !isFinishing) {
                    val function = if (active) "__assistantNativeScreenStarted" else "__assistantNativeScreenStopped"
                    webView.evaluateJavascript("window.$function && window.$function();", null)
                }
            }
        }
    }

    private fun configureWebView() {
        webView = WebView(this)
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        webView.setBackgroundColor(android.graphics.Color.rgb(242, 244, 248))
        setContentView(webView)

        // Remote WebView debugging would expose the page and its device bridge to anyone with adb access.
        WebView.setWebContentsDebuggingEnabled(false)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            safeBrowsingEnabled = true
            loadsImagesAutomatically = true
        }
        webView.addJavascriptInterface(NativeBridge(this), "AndroidAssistant")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { handleWebPermissionRequest(request) }
            }

            override fun onShowFileChooser(
                view: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                if (filePathCallback == null || fileChooserParams == null) return false
                fileChooserCallback?.onReceiveValue(null)
                clearPendingCameraCapture(deleteFile = true)
                fileChooserCallback = filePathCallback
                val forceCamera = forceNextFileChooserCamera
                forceNextFileChooserCamera = false
                return try {
                    // WebView's default file intent opens the gallery even for <input capture>.
                    // Route the explicit camera button (or capture-enabled image input) to Camera.
                    val wantsCamera = forceCamera ||
                        (fileChooserParams.isCaptureEnabled && acceptsImages(fileChooserParams))
                    if (wantsCamera) {
                        // ACTION_IMAGE_CAPTURE throws when CAMERA is declared but not granted; that used to
                        // silently fall back to the gallery. Ask for the permission, then open the camera.
                        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_FOR_CHOOSER)
                        } else if (!launchCameraCapture()) {
                            cancelFileChooser("بازکردن دوربین ممکن نشد")
                        }
                        true
                    } else {
                        val picker = fileChooserParams.createIntent().apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            if (fileChooserParams.mode == FileChooserParams.MODE_OPEN_MULTIPLE) {
                                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                            }
                        }
                        startActivityForResult(picker, REQUEST_FILE_CHOOSER)
                        true
                    }
                } catch (_: Exception) {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = null
                    clearPendingCameraCapture(deleteFile = true)
                    showToast("بازکردن دوربین یا انتخاب‌گر فایل ممکن نشد")
                    false
                }
            }

            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                // Pop-up windows are disabled so untrusted pages cannot acquire the JavaScript bridge.
                return false
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme?.lowercase().orEmpty()
                if (scheme == "https" || scheme == "http") {
                    if (uri.host.equals(BuildConfig.SPACE_HOST, ignoreCase = true)) return false
                    // Keep external pages out of the bridged WebView. Only an intentional link click
                    // can open an external URL, in the system's selected browser/app.
                    return try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                        true
                    } catch (_: Exception) {
                        showToast("برنامه‌ای برای بازکردن این پیوند پیدا نشد")
                        true
                    }
                }
                if (scheme == "about" || scheme == "blob" || scheme == "data") return false
                return true
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: android.net.http.SslError?) {
                handler?.cancel()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                when (pendingStopAction) {
                    ACTION_STOP_ALL -> stopSessionsFromNative()
                    ACTION_STOP_SCREEN -> stopScreenShareFromNative()
                }
                pendingStopAction = null
                if (pendingAssistantLaunch) {
                    pendingAssistantLaunch = false
                    webView.evaluateJavascript("window.__allbatAssistantPanelMode && window.__allbatAssistantPanelMode(true);", null)
                }
            }
        }

        try {
            val html = assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            webView.loadDataWithBaseURL(BuildConfig.SPACE_BASE_URL, html, "text/html", "UTF-8", null)
        } catch (e: Exception) {
            val message = ""
            val errorPage = """
                <!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
                <body style="font-family:system-ui;background:#f2f4f8;color:#222;padding:24px">
                <h2>فایل رابط برنامه پیدا نشد</h2><p>ساخت را دوباره اجرا کن تا index.html از Hugging Face دریافت شود.</p>
                <pre>${e.javaClass.simpleName}</pre></body></html>
            """.trimIndent()
            webView.loadDataWithBaseURL(BuildConfig.SPACE_BASE_URL, errorPage + message, "text/html", "UTF-8", null)
        }
    }

    private fun handleWebPermissionRequest(request: PermissionRequest) {
        if (!request.origin.scheme.equals("https", ignoreCase = true) ||
            !request.origin.host.equals(BuildConfig.SPACE_HOST, ignoreCase = true)) {
            request.deny()
            return
        }

        val safeResources = request.resources.filter {
            it == PermissionRequest.RESOURCE_AUDIO_CAPTURE || it == PermissionRequest.RESOURCE_VIDEO_CAPTURE
        }.toTypedArray()
        if (safeResources.isEmpty()) {
            request.deny()
            return
        }

        val missing = safeResources.mapNotNull { resource ->
            val permission = permissionForResource(resource) ?: return@mapNotNull null
            if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) null else permission
        }.distinct()

        if (missing.isEmpty()) {
            if (safeResources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) activateCommunicationAudio()
            request.grant(safeResources)
        } else {
            pendingWebPermission = request
            pendingWebResources = safeResources
            requestPermissions(missing.toTypedArray(), REQUEST_WEB_PERMISSION)
        }
    }

    private fun cancelFileChooser(message: String) {
        try { fileChooserCallback?.onReceiveValue(null) } catch (_: Exception) {}
        fileChooserCallback = null
        clearPendingCameraCapture(deleteFile = true)
        showToast(message)
    }

    private fun acceptsImages(params: WebChromeClient.FileChooserParams): Boolean {
        val types = params.acceptTypes.map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        return types.isNotEmpty() && types.any { it == "*/*" || it.startsWith("image/") }
    }

    private fun launchCameraCapture(): Boolean {
        return try {
            val directory = File(cacheDir, "camera")
            if (!directory.exists() && !directory.mkdirs()) throw IllegalStateException("Could not create camera cache")
            val photoFile = File.createTempFile("allbat_capture_", ".jpg", directory)
            val photoUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", photoFile)
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
                clipData = ClipData.newRawUri("All Bat camera capture", photoUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }
            pendingCameraPhotoFile = photoFile
            pendingCameraPhotoUri = photoUri
            startActivityForResult(cameraIntent, REQUEST_FILE_CHOOSER)
            true
        } catch (_: Exception) {
            clearPendingCameraCapture(deleteFile = true)
            false
        }
    }

    private fun clearPendingCameraCapture(deleteFile: Boolean) {
        if (deleteFile) {
            try { pendingCameraPhotoFile?.delete() } catch (_: Exception) {}
        }
        pendingCameraPhotoUri = null
        pendingCameraPhotoFile = null
    }

    /** Android WebView needs explicit communication mode/audio focus for reliable live microphone capture. */
    private fun activateCommunicationAudio() {
        val manager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            if (previousAudioMode == null) previousAudioMode = manager.mode
            manager.mode = AudioManager.MODE_IN_COMMUNICATION
        } catch (e: Exception) {
            android.util.Log.w("AllBatAudio", "Could not set communication audio mode", e)
        }
        try {
            val focusRequest = voiceAudioFocusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAcceptsDelayedFocusGain(false)
                .setOnAudioFocusChangeListener(voiceAudioFocusChangeListener)
                .build()
                .also { voiceAudioFocusRequest = it }
            manager.requestAudioFocus(focusRequest)
        } catch (e: Exception) {
            android.util.Log.w("AllBatAudio", "Could not acquire voice audio focus", e)
        }
    }

    private fun restoreCommunicationAudio() {
        val manager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try { voiceAudioFocusRequest?.let { manager.abandonAudioFocusRequest(it) } } catch (_: Exception) {}
        voiceAudioFocusRequest = null
        val mode = previousAudioMode
        if (mode != null) {
            try { manager.mode = mode } catch (e: Exception) {
                android.util.Log.w("AllBatAudio", "Could not restore previous audio mode", e)
            }
            previousAudioMode = null
        }
    }

    private fun permissionForResource(resource: String): String? = when (resource) {
        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
        else -> null
    }

    private fun requestNativePermissionThen(
        permission: String,
        action: String,
        notificationRequestComplete: Boolean = false
    ) {
        // Ask for notification permission before creating the visible foreground session.
        // Denying notifications does not silently grant capture; the required mic/camera and
        // MediaProjection permissions are still checked independently below.
        if (!notificationRequestComplete && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            pendingForegroundPermission = permission
            pendingForegroundAction = action
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATION_PERMISSION)
            return
        }
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            sendSessionAction(action)
            return
        }
        pendingNativeAction = action
        requestPermissions(arrayOf(permission), REQUEST_NATIVE_PERMISSION)
    }

    private fun sendSessionAction(action: String) {
        val serviceIntent = Intent(this, SessionForegroundService::class.java).setAction(action).apply {
            if (action == SessionForegroundService.ACTION_START_VOICE || action == SessionForegroundService.ACTION_START_CAMERA) {
                putExtra(SessionForegroundService.EXTRA_OVERLAY_OWNER, "main")
            }
        }
        try {
            if (action == SessionForegroundService.ACTION_START_VOICE || action == SessionForegroundService.ACTION_START_CAMERA) {
                ContextCompat.startForegroundService(this, serviceIntent)
            } else {
                SessionServiceControl.send(this, action)
            }
        } catch (e: Exception) {
            showToast("اجرای سرویس پس‌زمینه ممکن نشد: ${e.localizedMessage ?: "خطای اندروید"}")
        }
    }

    private fun startScreenCaptureConsent() {
        try {
            ScreenProjectionPermissionActivity.resultSink = { granted ->
                runOnUiThread {
                    if (!granted && ::webView.isInitialized) {
                        webView.evaluateJavascript("window.__assistantNativeScreenDenied && window.__assistantNativeScreenDenied();", null)
                    }
                }
            }
            // Do not use startActivityForResult from MainActivity: that promotes the app task
            // over the app the user is currently viewing. A separate, transparent task displays
            // Android's mandatory consent sheet and then returns to the previous app.
            val consentIntent = Intent(this, ScreenProjectionPermissionActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            }
            startActivity(consentIntent)
        } catch (e: Exception) {
            ScreenProjectionPermissionActivity.resultSink?.invoke(false)
            showToast("اشتراک‌گذاری صفحه در این دستگاه در دسترس نیست")
        }
    }

    private fun openAssistantRoleSettings() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val roleManager = getSystemService(RoleManager::class.java)
                if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) {
                    if (roleManager.isRoleHeld(RoleManager.ROLE_ASSISTANT)) {
                        showToast("این برنامه همین حالا دستیار پیش‌فرض است")
                    } else {
                        startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT), REQUEST_ASSISTANT_ROLE)
                    }
                    return
                }
            }
            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        } catch (_: Exception) {
            showToast("تنظیم انتخاب دستیار در این نسخهٔ اندروید در دسترس نیست")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_FILE_CHOOSER -> {
                val cameraUri = pendingCameraPhotoUri
                if (cameraUri != null) {
                    val photoFile = pendingCameraPhotoFile
                    val captured = resultCode == RESULT_OK && photoFile != null && photoFile.isFile && photoFile.length() > 0L
                    pendingCameraPhotoUri = null
                    pendingCameraPhotoFile = null
                    fileChooserCallback?.onReceiveValue(if (captured) arrayOf(cameraUri) else null)
                    fileChooserCallback = null
                    if (!captured) {
                        try { photoFile?.delete() } catch (_: Exception) {}
                        if (resultCode == RESULT_OK) showToast("دوربین تصویری ذخیره نکرد؛ دوباره امتحان کن")
                    }
                } else {
                    val result = if (resultCode == RESULT_OK && data != null) {
                        val clip = data.clipData
                        when {
                            clip != null -> Array(clip.itemCount) { index -> clip.getItemAt(index).uri }
                            data.data != null -> arrayOf(data.data!!)
                            else -> null
                        }
                    } else null
                    fileChooserCallback?.onReceiveValue(result)
                    fileChooserCallback = null
                }
            }
            REQUEST_ASSISTANT_ROLE -> showToast("وضعیت دستیار پیش‌فرض در تنظیمات اندروید قابل مشاهده است")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA_FOR_CHOOSER) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (fileChooserCallback == null) return
            if (!granted) cancelFileChooser("برای گرفتن عکس، مجوز دوربین لازم است")
            else if (!launchCameraCapture()) cancelFileChooser("بازکردن دوربین ممکن نشد")
        } else if (requestCode == REQUEST_WEB_PERMISSION) {
            val request = pendingWebPermission
            if (request != null) {
                val allowed = pendingWebResources.filter { resource ->
                    val permission = permissionForResource(resource)
                    permission != null && ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
                }.toTypedArray()
                if (allowed.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) activateCommunicationAudio()
                else if (pendingWebResources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) restoreCommunicationAudio()
                if (allowed.isNotEmpty()) request.grant(allowed) else request.deny()
            }
            pendingWebPermission = null
            pendingWebResources = emptyArray()
        } else if (requestCode == REQUEST_NATIVE_PERMISSION) {
            val action = pendingNativeAction
            pendingNativeAction = null
            val granted = action != null && permissions.isNotEmpty() && grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (granted && action != null) {
                sendSessionAction(action)
                if (action == SessionForegroundService.ACTION_START_VOICE && pendingOverlayPermissionAfterMic) {
                    pendingOverlayPermissionAfterMic = false
                    ensureFloatingOverlayPermission()
                }
            } else {
                pendingOverlayPermissionAfterMic = false
                showToast("مجوز لازم داده نشد؛ قابلیت فعال نشد")
            }
        } else if (requestCode == REQUEST_NOTIFICATION_PERMISSION) {
            val permission = pendingForegroundPermission
            val action = pendingForegroundAction
            pendingForegroundPermission = null
            pendingForegroundAction = null
            // Continue either way: Android may still run a foreground service when notifications
            // are denied, but the normal notification-drawer controls may not be visible.
            if (permission != null && action != null) {
                requestNativePermissionThen(permission, action, notificationRequestComplete = true)
            }
        }
    }

    private fun stopSessionsFromNative() {
        if (::webView.isInitialized) {
            webView.evaluateJavascript("window.__assistantNativeStopAll && window.__assistantNativeStopAll();", null)
        }
        sendSessionAction(SessionForegroundService.ACTION_STOP_ALL)
        restoreCommunicationAudio()
        stopService(Intent(this, ScreenCaptureService::class.java))
    }

    private fun stopScreenShareFromNative() {
        if (::webView.isInitialized) {
            webView.evaluateJavascript("window.__assistantNativeScreenStopped && window.__assistantNativeScreenStopped();", null)
        }
        stopService(Intent(this, ScreenCaptureService::class.java))
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("launched_from_assistant_role", false)) {
            pendingAssistantLaunch = true
            if (::webView.isInitialized && webView.progress >= 100) {
                webView.evaluateJavascript("window.__allbatAssistantPanelMode && window.__allbatAssistantPanelMode(true);", null)
                pendingAssistantLaunch = false
            }
            return
        }
        when (intent.action) {
            ACTION_STOP_ALL -> {
                pendingAssistantLaunch = false
                pendingStopAction = ACTION_STOP_ALL
                if (::webView.isInitialized && webView.progress >= 100) {
                    stopSessionsFromNative()
                    pendingStopAction = null
                }
            }
            ACTION_STOP_SCREEN -> {
                pendingAssistantLaunch = false
                pendingStopAction = ACTION_STOP_SCREEN
                if (::webView.isInitialized && webView.progress >= 100) {
                    stopScreenShareFromNative()
                    pendingStopAction = null
                }
            }
        }
    }

    private fun publishMainSurfaceVisibility(visible: Boolean) {
        getSharedPreferences("allbat_session_state", MODE_PRIVATE).edit()
            .putBoolean("main_surface_visible", visible)
            .apply()
        try {
            sendBroadcast(Intent(SessionForegroundService.ACTION_SURFACE_VISIBILITY).setPackage(packageName).apply {
                putExtra(SessionForegroundService.EXTRA_SURFACE_OWNER, "main")
                putExtra(SessionForegroundService.EXTRA_SURFACE_VISIBLE, visible)
            })
        } catch (error: Exception) {
            android.util.Log.w("AllBatOverlay", "Could not publish main surface visibility", error)
        }
    }

    override fun onResume() {
        super.onResume()
        publishMainSurfaceVisibility(true)
        if (::webView.isInitialized) attachScreenCaptureCallbacks()
        val prefs = getSharedPreferences("allbat_overlay", MODE_PRIVATE)
        if (prefs.getBoolean("refresh_on_resume", false)) {
            prefs.edit().putBoolean("refresh_on_resume", false).apply()
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                getSharedPreferences("allbat_overlay", MODE_PRIVATE).edit()
                    .putBoolean("permission_available", true)
                    .apply()
                sendBroadcast(Intent(SessionForegroundService.ACTION_REFRESH_OVERLAY).setPackage(packageName))
                showToast("مجوز نمایش شناور فعال شد؛ حباب فقط هنگام اجرای Live در پس‌زمینه دیده می‌شود.")
            } else {
                showToast("مجوز حباب داده نشد؛ گفت‌وگوی زنده در خود برنامه همچنان قابل استفاده است.")
            }
        }
    }

    /** Back must not finish the WebView that owns the Live WebSocket and microphone stream. */
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val sessionPrefs = getSharedPreferences("allbat_session_state", MODE_PRIVATE)
        val liveActive = sessionPrefs.getBoolean("voice_active", false)
        if (liveActive) {
            // Move to background, don't destroy the WebView or stop its foreground microphone service.
            moveTaskToBack(true)
            return
        }
        super.onBackPressed()
    }

    override fun onStop() {
        publishMainSurfaceVisibility(false)
        super.onStop()
    }

    override fun onDestroy() {
        try { offlineBotClient?.release() } catch (_: Exception) { }
        try { if (overlayReceiverRegistered) unregisterReceiver(overlayActionReceiver) } catch (_: Exception) { }
        overlayReceiverRegistered = false
        if (isFinishing) {
            val sessionPrefs = getSharedPreferences("allbat_session_state", MODE_PRIVATE)
            val liveActive = sessionPrefs.getBoolean("voice_active", false)
            val cameraActive = sessionPrefs.getBoolean("camera_active", false)
            // The WebView owns Live's socket and microphone stream. A real Activity finish
            // therefore ends the session; ordinary backgrounding only passes through onStop().
            if (liveActive || cameraActive) {
                sendSessionAction(SessionForegroundService.ACTION_STOP_ALL)
            } else {
                stopService(Intent(this, SessionForegroundService::class.java))
            }
            stopService(Intent(this, ScreenCaptureService::class.java))
            restoreCommunicationAudio()
        }
        ScreenCaptureService.frameSink = null
        ScreenCaptureService.statusSink = null
        if (::webView.isInitialized) {
            fileChooserCallback?.onReceiveValue(null)
            fileChooserCallback = null
            webView.removeJavascriptInterface("AndroidAssistant")
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    private fun showToast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    /** Shows the SMS review UI in the host Activity and waits for an explicit Send/Cancel choice. */
    private fun presentSmsConfirmation(data: JSONObject): String {
        val awaiterId = DeviceToolAwaiter.create()
        val ready = java.util.concurrent.CountDownLatch(1)
        val launched = java.util.concurrent.atomic.AtomicBoolean(false)
        runOnUiThread {
            try {
                val contact = data.optString("contact_name").take(100)
                val number = data.optString("number").take(40)
                val initialBody = data.optString("message").take(2000)
                var dialog: AlertDialog? = null
                val preview = SmsPreviewView(
                    this, contact, number, initialBody,
                    onCancel = {
                        if (DeviceToolAwaiter.isPending(awaiterId)) {
                            DeviceToolAwaiter.complete(awaiterId, JSONObject().put("ok", false)
                                .put("message", "کاربر ارسال پیامک را لغو کرد؛ هیچ پیامی ارسال نشد.").toString())
                        }
                        dialog?.dismiss()
                    },
                    onSend = { editedBody ->
                        dialog?.dismiss()
                        try {
                            startActivity(Intent(this, PhoneActionPermissionActivity::class.java).apply {
                                putExtra(PhoneActionPermissionActivity.EXTRA_SMS_AWAITER_ID, awaiterId)
                                putExtra(PhoneActionPermissionActivity.EXTRA_SMS_CONTACT, contact)
                                putExtra(PhoneActionPermissionActivity.EXTRA_SMS_NUMBER, number)
                                putExtra(PhoneActionPermissionActivity.EXTRA_SMS_BODY, editedBody.take(2000))
                            })
                        } catch (_: Exception) {
                            DeviceToolAwaiter.complete(awaiterId, JSONObject().put("ok", false)
                                .put("message", "پنجرهٔ تأیید ارسال پیامک باز نشد؛ پیام ارسال نشد.").toString())
                        }
                    }
                )
                dialog = AlertDialog.Builder(this).setView(preview).create()
                dialog?.setCancelable(false)
                dialog?.setCanceledOnTouchOutside(false)
                dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog?.show()
                dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                val width = (resources.displayMetrics.widthPixels - (24 * resources.displayMetrics.density).toInt())
                    .coerceAtMost((540 * resources.displayMetrics.density).toInt())
                dialog?.window?.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
                dialog?.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                launched.set(true)
            } catch (error: Exception) {
                DeviceToolAwaiter.complete(awaiterId, JSONObject().put("ok", false)
                    .put("message", "نمایش پیش‌نمایش پیامک ممکن نشد.").toString())
            } finally { ready.countDown() }
        }
        if (!ready.await(6, java.util.concurrent.TimeUnit.SECONDS) || !launched.get()) {
            DeviceToolAwaiter.complete(awaiterId, JSONObject().put("ok", false)
                .put("message", "نمایش تأیید پیامک شروع نشد.").toString())
        }
        return DeviceToolAwaiter.await(awaiterId, 120)
    }

    inner class NativeBridge(private val activity: MainActivity) {
        @android.webkit.JavascriptInterface
        fun isOfflineBotInstalled(): Boolean = activity.offlineBot.isInstalled()

        @android.webkit.JavascriptInterface
        fun askOfflineBot(id: String, text: String) {
            activity.runOnUiThread { activity.offlineBot.ask(id.take(80), text.take(4000)) }
        }

        @android.webkit.JavascriptInterface
        fun cancelOfflineBot(id: String) {
            activity.runOnUiThread { activity.offlineBot.cancel(id.take(80)) }
        }

        @android.webkit.JavascriptInterface
        fun openOfflineBotApp() {
            activity.runOnUiThread { activity.offlineBot.launchApp() }
        }

        @android.webkit.JavascriptInterface
        fun startVoiceSession() {
            activity.runOnUiThread {
                activity.activateCommunicationAudio()
                if (ContextCompat.checkSelfPermission(activity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    activity.requestNativePermissionThen(
                        Manifest.permission.RECORD_AUDIO,
                        SessionForegroundService.ACTION_START_VOICE,
                        notificationRequestComplete = true
                    )
                    activity.ensureFloatingOverlayPermission()
                } else {
                    activity.pendingOverlayPermissionAfterMic = true
                    activity.requestNativePermissionThen(
                        Manifest.permission.RECORD_AUDIO,
                        SessionForegroundService.ACTION_START_VOICE,
                        notificationRequestComplete = true
                    )
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun stopVoiceSession() {
            activity.runOnUiThread {
                activity.sendSessionAction(SessionForegroundService.ACTION_STOP_VOICE)
                activity.restoreCommunicationAudio()
            }
        }

        @android.webkit.JavascriptInterface
        fun prepareAudioSession() {
            // Prepare Android's communication route before Chromium opens the microphone.
            activity.runOnUiThread { activity.activateCommunicationAudio() }
        }

        @android.webkit.JavascriptInterface
        fun cancelAudioSession() {
            activity.runOnUiThread { activity.restoreCommunicationAudio() }
        }

        @android.webkit.JavascriptInterface
        fun markNextFileChooserAsCamera() {
            activity.forceNextFileChooserCamera = true
        }

        @android.webkit.JavascriptInterface
        fun startCameraSession() {
            activity.runOnUiThread {
                activity.requestNativePermissionThen(
                    Manifest.permission.CAMERA,
                    SessionForegroundService.ACTION_START_CAMERA,
                    notificationRequestComplete = true
                )
            }
        }

        @android.webkit.JavascriptInterface
        fun stopCameraSession() {
            activity.runOnUiThread { activity.sendSessionAction(SessionForegroundService.ACTION_STOP_CAMERA) }
        }

        @android.webkit.JavascriptInterface
        fun startScreenShare() {
            activity.runOnUiThread { activity.startScreenCaptureConsent() }
        }

        @android.webkit.JavascriptInterface
        fun stopScreenShare() {
            activity.runOnUiThread { activity.stopScreenShareFromNative() }
        }

        @android.webkit.JavascriptInterface
        fun requestDefaultAssistant() {
            activity.runOnUiThread { activity.openAssistantRoleSettings() }
        }

        @android.webkit.JavascriptInterface
        fun isDefaultAssistant(): Boolean {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
            return try {
                val roleManager = activity.getSystemService(RoleManager::class.java)
                roleManager?.isRoleHeld(RoleManager.ROLE_ASSISTANT) == true
            } catch (_: Exception) {
                false
            }
        }

        @android.webkit.JavascriptInterface
        fun updateAssistantOverlay(
            userText: String?, answerText: String?, status: String?, generating: Boolean,
            micMuted: Boolean, cameraActive: Boolean, screenActive: Boolean
        ) {
            activity.broadcastOverlayUpdate(
                userText.orEmpty(), answerText.orEmpty(), status.orEmpty(), generating,
                micMuted, cameraActive, screenActive
            )
        }

        @android.webkit.JavascriptInterface
        fun hasFloatingAssistantOverlayPermission(): Boolean =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(activity)

        @android.webkit.JavascriptInterface
        fun shouldPromptFloatingAssistantOverlay(): Boolean =
            !activity.getSharedPreferences("allbat_overlay", MODE_PRIVATE).getBoolean("permission_prompted", false)

        @android.webkit.JavascriptInterface
        fun requestFloatingAssistantOverlay() {
            activity.runOnUiThread { activity.ensureFloatingOverlayPermission(forcePrompt = true) }
        }

        @android.webkit.JavascriptInterface
        fun hideFloatingAssistantOverlay() {
            activity.runOnUiThread {
                SessionServiceControl.send(activity, SessionForegroundService.ACTION_HIDE_ORB)
            }
        }

        @android.webkit.JavascriptInterface
        fun executeDeviceTool(name: String?, argsJson: String?): String {
            val toolName = name.orEmpty().take(80)
            val toolArgs = argsJson.orEmpty().take(4000)
            if (toolName.isBlank()) return JSONObject().put("ok", false).put("message", "نام ابزار خالی است.").toString()
            return try {
                val outcome = PhoneActionEngine.executeTool(activity.applicationContext, toolName, toolArgs)
                if (outcome.permissions.isNotEmpty()) {
                    val id = DeviceToolAwaiter.create()
                    val started = java.util.concurrent.CountDownLatch(1)
                    val launchOk = java.util.concurrent.atomic.AtomicBoolean(false)
                    activity.runOnUiThread {
                        try {
                            activity.startActivity(Intent(activity, PhoneActionPermissionActivity::class.java).apply {
                                putExtra(PhoneActionPermissionActivity.EXTRA_TOOL_NAME, toolName)
                                putExtra(PhoneActionPermissionActivity.EXTRA_TOOL_ARGS, toolArgs)
                                putExtra(PhoneActionPermissionActivity.EXTRA_AWAITER_ID, id)
                            })
                            launchOk.set(true)
                        } catch (_: Exception) {
                            DeviceToolAwaiter.complete(id, JSONObject().put("ok", false).put("message", "صفحهٔ مجوز اندروید باز نشد.").toString())
                        } finally { started.countDown() }
                    }
                    if (!started.await(6, java.util.concurrent.TimeUnit.SECONDS) || !launchOk.get()) {
                        DeviceToolAwaiter.complete(id, JSONObject().put("ok", false).put("message", "صفحهٔ مجوز اندروید شروع نشد.").toString())
                    }
                    val permissionResult = DeviceToolAwaiter.await(id, 90)
                    val parsed = JSONObject(permissionResult)
                    val returnedData = parsed.optJSONObject("data")
                    if (toolName == "create_sms_draft" && parsed.optBoolean("ok") &&
                        returnedData?.optString("action") == "sms_confirmation_required") {
                        return activity.presentSmsConfirmation(returnedData)
                    }
                    return permissionResult
                }
                if (toolName == "create_sms_draft" && outcome.data.optString("action") == "sms_confirmation_required") {
                    return activity.presentSmsConfirmation(outcome.data)
                }
                if (outcome.intent != null) {
                    val started = java.util.concurrent.CountDownLatch(1)
                    val launchOk = java.util.concurrent.atomic.AtomicBoolean(false)
                    activity.runOnUiThread {
                        try { activity.startActivity(outcome.intent); launchOk.set(true) }
                        catch (_: Exception) { launchOk.set(false) }
                        finally { started.countDown() }
                    }
                    if (!started.await(6, java.util.concurrent.TimeUnit.SECONDS) || !launchOk.get()) {
                        JSONObject().put("ok", false).put("message", "اندروید اجازهٔ بازکردن مقصد را نداد.").toString()
                    } else outcome.toJson()
                } else outcome.toJson()
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                JSONObject().put("ok", false).put("message", "درخواست ابزار متوقف شد.").toString()
            } catch (_: Exception) {
                JSONObject().put("ok", false).put("message", "اجرای ابزار ناموفق بود.").toString()
            }
        }

        @android.webkit.JavascriptInterface
        fun appVersion(): String = BuildConfig.VERSION_NAME
    }
}
