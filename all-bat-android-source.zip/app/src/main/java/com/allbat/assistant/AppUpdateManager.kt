package com.allbat.assistant

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * GitHub-Releases based in-app updater.
 *
 * The release contains:
 *   - AllBat.apk
 *   - update.json
 *
 * Android still displays its own installation confirmation. This class never attempts
 * a silent install and never bypasses Android's package/signature checks.
 */
internal class AppUpdateManager(private val activity: MainActivity) {
    private val prefs = activity.getSharedPreferences("allbat_app_updates", android.content.Context.MODE_PRIVATE)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val checking = AtomicBoolean(false)
    private val downloading = AtomicBoolean(false)

    private data class RemoteUpdate(
        val versionCode: Long,
        val versionName: String,
        val packageName: String,
        val apkUrl: String,
        val apkSha256: String,
        val releaseNotes: String
    )

    fun checkForUpdates(force: Boolean = false) {
        if (activity.isFinishing || !checking.compareAndSet(false, true)) return

        val now = System.currentTimeMillis()
        val lastCheck = prefs.getLong(KEY_LAST_CHECK, 0L)
        if (!force && now - lastCheck < CHECK_INTERVAL_MS) {
            checking.set(false)
            return
        }

        Thread({
            try {
                val update = findAvailableUpdate()
                prefs.edit().putLong(KEY_LAST_CHECK, System.currentTimeMillis()).apply()
                if (update == null) {
                    if (force) mainHandler.post {
                        if (!activity.isFinishing) toast("برنامه به‌روز است.")
                    }
                    return@Thread
                }

                val dismissedCode = prefs.getLong(KEY_DISMISSED_VERSION, -1L)
                if (!force && dismissedCode >= update.versionCode) return@Thread

                mainHandler.post {
                    if (!activity.isFinishing) showUpdateDialog(update)
                }
            } catch (error: Exception) {
                android.util.Log.w(TAG, "Update check failed", error)
                if (force) mainHandler.post {
                    if (!activity.isFinishing) toast("بررسی بروزرسانی انجام نشد؛ اتصال اینترنت یا انتشار GitHub را بررسی کن.")
                }
            } finally {
                checking.set(false)
            }
        }, "allbat-update-check").apply { isDaemon = true }.start()
    }

    /** Called from MainActivity.onResume after returning from Android's install-permission screen. */
    fun onActivityResumed() {
        val pending = prefs.getString(KEY_PENDING_INSTALL, null) ?: return
        val file = File(pending)
        if (!file.isFile || file.length() < MIN_APK_BYTES) {
            prefs.edit().remove(KEY_PENDING_INSTALL).apply()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val allowed = try { activity.packageManager.canRequestPackageInstalls() } catch (_: Exception) { false }
            if (!allowed) return
        }
        prefs.edit().remove(KEY_PENDING_INSTALL).apply()
        launchPackageInstaller(file)
    }

    private fun findAvailableUpdate(): RemoteUpdate? {
        val repository = BuildConfig.UPDATE_REPOSITORY.trim()
        val parts = repository.split("/")
        require(parts.size == 2 && parts.all { it.matches(Regex("[A-Za-z0-9_.-]+")) }) {
            "GitHub update repository is not configured"
        }

        val releaseUrl = "https://api.github.com/repos/$repository/releases/latest"
        val release = requestJson(releaseUrl, API_HOST)
        val assets = release.optJSONArray("assets") ?: return null
        var manifestUrl: String? = null
        for (i in 0 until assets.length()) {
            val item = assets.optJSONObject(i) ?: continue
            if (item.optString("name") == MANIFEST_ASSET) {
                manifestUrl = item.optString("browser_download_url").takeIf { it.isNotBlank() }
                break
            }
        }
        val url = manifestUrl ?: throw IllegalStateException("The latest GitHub release does not contain update.json")
        val manifest = requestJson(url, GITHUB_HOST)

        val remote = RemoteUpdate(
            versionCode = manifest.optLong("versionCode", -1L),
            versionName = manifest.optString("versionName", "").take(40),
            packageName = manifest.optString("packageName", "").take(160),
            apkUrl = manifest.optString("apkUrl", "").take(2048),
            apkSha256 = manifest.optString("apkSha256", "").lowercase(Locale.ROOT),
            releaseNotes = manifest.optString("releaseNotes", "").take(2500)
        )

        require(remote.versionCode > 0L) { "Invalid update versionCode" }
        require(remote.packageName == activity.packageName) { "The update package does not match this app" }
        require(remote.versionName.isNotBlank()) { "Invalid update versionName" }
        require(remote.apkSha256.matches(Regex("^[0-9a-f]{64}$"))) { "Invalid update checksum" }
        validateHttpsUrl(remote.apkUrl, GITHUB_HOST)
        val currentCode = currentVersionCode()
        return remote.takeIf { it.versionCode > currentCode }
    }

    private fun showUpdateDialog(update: RemoteUpdate) {
        if (activity.isFinishing || activity.isDestroyed) return
        val message = buildString {
            append("نسخهٔ ")
            append(update.versionName)
            append(" آماده است.")
            if (update.releaseNotes.isNotBlank()) {
                append("\n\n")
                append(update.releaseNotes)
            }
            append("\n\nپس از دریافت، تأیید نصب با پنجرهٔ رسمی اندروید انجام می‌شود.")
        }
        AlertDialog.Builder(activity)
            .setTitle("بروزرسانی All Bat")
            .setMessage(message)
            .setPositiveButton("دریافت و نصب") { _, _ -> downloadAndInstall(update) }
            .setNegativeButton("بعداً") { _, _ ->
                prefs.edit().putLong(KEY_DISMISSED_VERSION, update.versionCode).apply()
            }
            .setNeutralButton("نادیده‌گرفتن این نسخه") { _, _ ->
                prefs.edit().putLong(KEY_DISMISSED_VERSION, update.versionCode).apply()
            }
            .show()
    }

    private fun downloadAndInstall(update: RemoteUpdate) {
        if (!downloading.compareAndSet(false, true)) return
        val progress = ProgressDialog(activity).apply {
            setTitle("دریافت بروزرسانی")
            setMessage("در حال دریافت نسخهٔ ${update.versionName}…")
            setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
            setProgress(0)
            setMax(100)
            setCancelable(false)
            setCanceledOnTouchOutside(false)
            show()
        }

        Thread({
            var connection: HttpURLConnection? = null
            var partFile: File? = null
            try {
                validateHttpsUrl(update.apkUrl, GITHUB_HOST)
                connection = openHttps(update.apkUrl, GITHUB_ASSET_HOSTS)
                val status = connection.responseCode
                require(status == HttpURLConnection.HTTP_OK) { "GitHub download returned HTTP $status" }

                val total = connection.contentLengthLong
                require(total <= MAX_APK_BYTES) { "APK size exceeds the allowed limit" }
                val updateDir = File(activity.cacheDir, "updates").apply { mkdirs() }
                val tempFile = File(updateDir, "AllBat.apk.part")
                partFile = tempFile
                if (tempFile.exists()) tempFile.delete()
                val targetFile = File(updateDir, "AllBat.apk")

                var received = 0L
                BufferedInputStream(connection.inputStream).use { input ->
                    FileOutputStream(tempFile).use { output ->
                        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            received += count
                            require(received <= MAX_APK_BYTES) { "APK size exceeds the allowed limit" }
                            output.write(buffer, 0, count)
                            if (total > 0L) {
                                val percent = ((received * 100L) / total).toInt().coerceIn(0, 100)
                                mainHandler.post { if (progress.isShowing) progress.progress = percent }
                            }
                        }
                        output.fd.sync()
                    }
                }
                require(received >= MIN_APK_BYTES) { "Downloaded APK is incomplete" }
                require(sha256(tempFile).equals(update.apkSha256, ignoreCase = true)) {
                    "The downloaded APK checksum does not match the release manifest"
                }
                verifyApk(tempFile, update)

                if (targetFile.exists()) targetFile.delete()
                check(tempFile.renameTo(targetFile)) { "Could not finalize the downloaded APK" }
                mainHandler.post {
                    if (progress.isShowing) progress.dismiss()
                    if (!activity.isFinishing) installOrRequestPermission(targetFile)
                }
            } catch (error: Exception) {
                android.util.Log.e(TAG, "Update download or validation failed", error)
                try { partFile?.delete() } catch (_: Exception) {}
                mainHandler.post {
                    if (progress.isShowing) progress.dismiss()
                    if (!activity.isFinishing) toast("دریافت یا بررسی بروزرسانی ناموفق بود: ${friendlyError(error)}")
                }
            } finally {
                try { connection?.disconnect() } catch (_: Exception) {}
                downloading.set(false)
            }
        }, "allbat-update-download").apply { isDaemon = true }.start()
    }

    private fun verifyApk(file: File, update: RemoteUpdate) {
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            PackageManager.GET_SIGNING_CERTIFICATES
        } else {
            @Suppress("DEPRECATION")
            PackageManager.GET_SIGNATURES
        }
        val info = activity.packageManager.getPackageArchiveInfo(file.absolutePath, flags)
            ?: throw IllegalStateException("Downloaded file is not a valid Android APK")
        require(info.packageName == activity.packageName) { "APK package name does not match the installed app" }

        val apkVersionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode else info.versionCode.toLong()
        require(apkVersionCode == update.versionCode) { "APK version does not match update.json" }

        val expectedSigner = BuildConfig.APP_SIGNING_CERT_SHA256.trim().lowercase(Locale.ROOT)
        require(expectedSigner.matches(Regex("^[0-9a-f]{64}$"))) {
            "This installation does not contain a trusted release-signing fingerprint"
        }

        @Suppress("DEPRECATION")
        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.signingInfo?.apkContentsSigners ?: emptyArray()
        } else {
            info.signatures ?: emptyArray()
        }
        val actualSigners = signatures.map { signature ->
            MessageDigest.getInstance("SHA-256").digest(signature.toByteArray())
                .joinToString("") { byte -> "%02x".format(byte) }
        }
        require(actualSigners.size == 1 && actualSigners.single() == expectedSigner) {
            "The update was not signed with the original All Bat release key"
        }
    }

    private fun installOrRequestPermission(file: File) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val allowed = try { activity.packageManager.canRequestPackageInstalls() } catch (_: Exception) { false }
            if (!allowed) {
                prefs.edit().putString(KEY_PENDING_INSTALL, file.absolutePath).apply()
                AlertDialog.Builder(activity)
                    .setTitle("مجوز نصب بروزرسانی")
                    .setMessage("برای نصب نسخهٔ جدید، اجازهٔ «نصب برنامه‌های ناشناس» را برای All Bat فعال کن. سپس به برنامه برگرد.")
                    .setPositiveButton("بازکردن تنظیمات") { _, _ ->
                        try {
                            activity.startActivity(
                                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
                            )
                        } catch (_: Exception) {
                            toast("بازکردن تنظیمات نصب برنامه ممکن نشد.")
                        }
                    }
                    .setNegativeButton("بعداً", null)
                    .show()
                return
            }
        }
        launchPackageInstaller(file)
    }

    private fun launchPackageInstaller(file: File) {
        try {
            val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, APK_MIME)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivity(intent)
        } catch (error: Exception) {
            android.util.Log.e(TAG, "Could not launch Android package installer", error)
            toast("بازکردن نصب‌کنندهٔ اندروید ممکن نشد.")
        }
    }

    private fun currentVersionCode(): Long {
        val info = activity.packageManager.getPackageInfo(activity.packageName, 0)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode else info.versionCode.toLong()
    }

    private fun requestJson(url: String, initialHost: String): JSONObject {
        validateHttpsUrl(url, initialHost)
        val connection = openHttps(url, setOf(API_HOST, GITHUB_HOST, GITHUB_ASSET_HOST))
        try {
            val status = connection.responseCode
            require(status == HttpURLConnection.HTTP_OK) { "GitHub API returned HTTP $status" }
            val data = connection.inputStream.use { it.readBytesLimited(MAX_JSON_BYTES) }
            return JSONObject(data.toString(Charsets.UTF_8))
        } finally {
            connection.disconnect()
        }
    }

    private fun openHttps(url: String, allowedFinalHosts: Set<String>): HttpURLConnection {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            instanceFollowRedirects = true
            useCaches = false
            setRequestProperty("User-Agent", "AllBat-Android-Updater")
            setRequestProperty("Accept", "application/vnd.github+json, application/json, application/octet-stream")
            setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        }
        // Accessing responseCode follows permitted HTTPS redirects; inspect the final host before reading.
        val status = connection.responseCode
        if (status in 200..299) {
            val finalUri = Uri.parse(connection.url.toString())
            val finalHost = finalUri.host?.lowercase(Locale.ROOT)
            require(finalUri.scheme == "https" && finalHost != null && allowedFinalHosts.contains(finalHost)) {
                connection.disconnect()
                throw IllegalArgumentException("GitHub redirected the download to an untrusted host")
            }
        }
        return connection
    }

    private fun validateHttpsUrl(url: String, expectedHost: String) {
        val uri = Uri.parse(url)
        require(uri.scheme == "https" && uri.host?.equals(expectedHost, ignoreCase = true) == true) {
            "Update URL is not from the expected HTTPS host"
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { byte -> "%02x".format(byte) }
    }

    private fun java.io.InputStream.readBytesLimited(maxBytes: Int): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = read(buffer)
            if (count < 0) break
            total += count
            require(total <= maxBytes) { "GitHub JSON response is too large" }
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private fun friendlyError(error: Exception): String {
        val message = error.message.orEmpty()
        return when {
            message.contains("checksum", true) -> "صحت فایل تأیید نشد"
            message.contains("signature", true) || message.contains("sign", true) -> "امضای نسخه با کلید اصلی یکسان نیست"
            message.contains("package name", true) -> "شناسهٔ برنامه متفاوت است"
            message.contains("HTTP 404", true) -> "نسخهٔ منتشرشده پیدا نشد"
            else -> message.take(150).ifBlank { "خطای نامشخص" }
        }
    }

    private fun toast(message: String) {
        Toast.makeText(activity, message, Toast.LENGTH_LONG).show()
    }

    companion object {
        private const val TAG = "AllBatUpdater"
        private const val API_HOST = "api.github.com"
        private const val GITHUB_HOST = "github.com"
        private const val GITHUB_ASSET_HOST = "release-assets.githubusercontent.com"
        private val GITHUB_ASSET_HOSTS = setOf(GITHUB_HOST, GITHUB_ASSET_HOST, "objects.githubusercontent.com")
        private const val MANIFEST_ASSET = "update.json"
        private const val APK_MIME = "application/vnd.android.package-archive"
        private const val KEY_LAST_CHECK = "last_check_ms"
        private const val KEY_DISMISSED_VERSION = "dismissed_version_code"
        private const val KEY_PENDING_INSTALL = "pending_install_path"
        private const val CHECK_INTERVAL_MS = 6L * 60L * 60L * 1000L
        private const val CONNECT_TIMEOUT_MS = 15000
        private const val READ_TIMEOUT_MS = 45000
        private const val MAX_JSON_BYTES = 512 * 1024
        private const val MAX_APK_BYTES = 250L * 1024L * 1024L
        private const val MIN_APK_BYTES = 100L * 1024L
    }
}
