#!/usr/bin/env python3
"""Static checks for the All Bat GitHub release / in-app updater contract."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP_GRADLE = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
WORKFLOW = (ROOT / ".github/workflows/build-apk.yml").read_text(encoding="utf-8")
UPDATER = (ROOT / "app/src/main/java/com/allbat/assistant/AppUpdateManager.kt").read_text(encoding="utf-8")
MAIN = (ROOT / "app/src/main/java/com/allbat/assistant/MainActivity.kt").read_text(encoding="utf-8")
MANIFEST_PATH = ROOT / "app/src/main/AndroidManifest.xml"
FILE_PATHS = ROOT / "app/src/main/res/xml/file_paths.xml"

def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"Updater contract failed: {message}")

manifest = ET.parse(MANIFEST_PATH).getroot()
android_ns = "{http://schemas.android.com/apk/res/android}"
permissions = {
    item.attrib.get(android_ns + "name")
    for item in manifest.findall("uses-permission")
}
provider_paths = ET.parse(FILE_PATHS).getroot()
cache_paths = {item.attrib.get("path") for item in provider_paths}

require('applicationId = "com.allbat.assistant"' in APP_GRADLE, "applicationId changed unexpectedly")
require('buildConfigField("String", "UPDATE_REPOSITORY"' in APP_GRADLE, "update repository not injected")
require("1_000_000 + it" in APP_GRADLE and "1000000 + GITHUB_RUN_NUMBER" in WORKFLOW, "CI versionCode is not a high-water monotonic counter")
require("android.permission.REQUEST_INSTALL_PACKAGES" in permissions, "Android install-source permission missing")
require("updates/" in cache_paths, "FileProvider does not expose the private updates cache")
require("releases/latest" in UPDATER, "updater does not query the latest GitHub release")
require("apkSha256" in UPDATER and "sha256(" in UPDATER, "APK checksum verification missing")
require("getPackageArchiveInfo" in UPDATER and "APP_SIGNING_CERT_SHA256" in UPDATER, "APK package/signature verification missing")
require("canRequestPackageInstalls" in UPDATER, "Android 8+ install permission flow missing")
require("ACTION_VIEW" in UPDATER and "FileProvider.getUriForFile" in UPDATER, "system package installer flow missing")
require("AppUpdateManager(this)" in MAIN and "checkForUpdates" in MAIN, "startup/manual updater hooks missing")
require("softprops/action-gh-release@v2" in WORKFLOW, "GitHub Releases publishing step missing")
require("release-assets/AllBat.apk" in WORKFLOW and "release-assets/update.json" in WORKFLOW, "release assets missing")
require("permissions:" in WORKFLOW and "contents: write" in WORKFLOW, "release write permission missing")
require('"packageName": "com.allbat.assistant"' in WORKFLOW, "release package name does not match applicationId")

print("All Bat automatic-update contract: PASS")
