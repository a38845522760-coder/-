# All Bat — GitHub Release + Automatic Update

این بسته، سورس Android پروژهٔ All Bat را با سیستم انتشار نسخه و بروزرسانی داخل برنامه آماده می‌کند.

## قابلیت‌های اضافه‌شده

- بررسی نسخهٔ جدید از GitHub Releases هنگام بازشدن برنامه (با فاصلهٔ حداقل ۶ ساعت).
- بررسی دستی از طریق پل Android با `AndroidAssistant.checkForUpdates()`.
- دریافت APK با نوار پیشرفت.
- بررسی SHA-256 فایل دانلودشده.
- کنترل شناسهٔ بسته، `versionCode` و گواهی امضای APK پیش از تحویل به نصب‌کننده.
- استفاده از FileProvider و نصب‌کنندهٔ رسمی Android؛ نصب بی‌اجازه یا بی‌صدا انجام نمی‌شود.
- پس از فعال‌کردن مجوز «نصب برنامه‌های ناشناس» برای All Bat، نصب‌کنندهٔ رسمی Android باز می‌شود.
- هر Push موفق به شاخهٔ `main` یک GitHub Release جدید شامل `AllBat.apk` و `update.json` می‌سازد.
- `versionCode` در CI با `1,000,000 + GITHUB_RUN_NUMBER` افزایش می‌یابد تا از شماره‌نسخه‌های قبلی این پروژه بالاتر باشد و `versionName` از شمارهٔ اجرای همان workflow ساخته می‌شود.

## راه‌اندازی در GitHub

محتویات پوشهٔ پروژه را در ریشهٔ مخزن Android قرار بده؛ workflow باید در مسیر زیر باشد:

`.github/workflows/build-apk.yml`

در GitHub → Settings → Secrets and variables → Actions، این Secrets باید موجود باشند:

- `ALLBAT_KEYSTORE_BASE64`
- `ALLBAT_KEYSTORE_PASSWORD`
- `ALLBAT_KEY_ALIAS`

از همان keystore، password و alias نسخهٔ امضاشدهٔ قبلی استفاده کن. مقدارها را تغییر نده و فایل keystore یا رمز آن را وارد مخزن نکن. workflow اثر انگشت گواهی عمومی را در `.github/allbat-signing-cert.sha256` قفل می‌کند و با تغییر ناخواستهٔ کلید، ساخت Release را متوقف می‌کند.

`ALLBAT_OFFLINE_CERT_SHA256` اختیاری است و مانند قبل فقط برای بررسی برنامهٔ همراه آفلاین استفاده می‌شود.

بعد از Push روی `main`:
1. GitHub Actions رابط فعلی Hugging Face را دریافت و به پل بومی Android متصل می‌کند.
2. APK امضاشده را می‌سازد و گواهی را بررسی می‌کند.
3. Release را با `AllBat.apk` و `update.json` منتشر می‌کند.
4. برنامه‌های نصب‌شده‌ای که این updater را دارند، Release جدید را بررسی می‌کنند.

## نکتهٔ مهم دربارهٔ نسخهٔ قبلی

این نسخه، شناسهٔ بستهٔ موجود در سورس مبنا را حفظ کرده است: `com.allbat.assistant`.

نسخه‌های قدیمی‌ای که هنوز کد updater را ندارند، نمی‌توانند خودشان این قابلیت را از راه دور دریافت کنند. برای فعال‌کردن زنجیرهٔ بروزرسانی، این نسخهٔ اولیهٔ دارای updater را یک بار به‌صورت دستی نصب کن. بعد از آن، نسخه‌های جدید از داخل برنامه بررسی، دریافت و برای نصب به Android سپرده می‌شوند.

نصب به‌عنوان بروزرسانی روی نسخهٔ قبلی فقط وقتی ممکن است که شناسهٔ بسته و گواهی امضا با نسخهٔ نصب‌شده یکسان باشند. اگر نسخهٔ نصب‌شده با package دیگری مثل `com.aibale.assistant` ساخته شده باشد، Android اجازهٔ جایگزینی آن با `com.allbat.assistant` را نمی‌دهد؛ تغییر نام بسته قابل جبران با updater نیست.

همچنین اگر keystore فعلی با کلید نسخهٔ نصب‌شده فرق کند، Android نصب به‌روزرسانی را رد می‌کند. کلید امضای اصلی باید حفظ شود.

## هماهنگی مدل‌ها و Hugging Face

در فرایند CI، `scripts/prepare_web_assets.py` رابط Mini App فعلی را از Hugging Face Space می‌گیرد و پل بومی را به آن تزریق می‌کند. بنابراین گزینه‌ها و مدل‌هایی که در بک‌اند/رابط Space منتشر شده‌اند، هنگام ساخت APK بعدی داخل برنامه هم قرار می‌گیرند. تغییر مدل سمت سرور به‌تنهایی APK جدید نمی‌خواهد؛ تغییرات Android نیازمند Release جدید است.

## بررسی‌های قابل اجرا

```bash
python -m py_compile scripts/prepare_web_assets.py scripts/validate_device_tool_contract.py scripts/validate_update_contract.py
node --check app/src/main/assets/native-bridge.js
node --check app/src/main/assets/fb-widget.js
node scripts/test_device_command_parser.js
python scripts/validate_device_tool_contract.py
python scripts/validate_update_contract.py
```

ساخت کامل APK نیازمند Android SDK، Gradle، دسترسی شبکه به Hugging Face و GitHub و Secrets امضای معتبر است؛ بررسی نهایی Build در GitHub Actions انجام می‌شود.
