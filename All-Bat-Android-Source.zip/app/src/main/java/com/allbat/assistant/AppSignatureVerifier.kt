package com.allbat.assistant

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import java.security.MessageDigest

/**
 * Checks the installed APK's signing certificate against the public certificate fingerprint
 * injected by the trusted GitHub Actions build. No private key or keystore password is stored
 * in the APK. Android's package installer independently enforces signer continuity on updates.
 */
internal object AppSignatureVerifier {
    fun isTrusted(context: Context): Boolean {
        val expected = BuildConfig.APP_SIGNING_CERT_SHA256.trim().lowercase()
        // Local debug builds are intentionally unsigned with the production certificate.
        if (expected.isEmpty()) return BuildConfig.DEBUG
        if (!expected.matches(Regex("^[0-9a-f]{64}$"))) return false
        return signerDigests(context).singleOrNull() == expected
    }

    @Suppress("DEPRECATION")
    private fun signerDigests(context: Context): List<String> = try {
        val pm = context.packageManager
        val signatures: Array<Signature> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            info.signingInfo?.apkContentsSigners ?: emptyArray()
        } else {
            pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES).signatures ?: emptyArray()
        }
        signatures.map { signature ->
            MessageDigest.getInstance("SHA-256").digest(signature.toByteArray())
                .joinToString("") { byte -> "%02x".format(byte) }
        }
    } catch (_: Exception) {
        emptyList()
    }
}
