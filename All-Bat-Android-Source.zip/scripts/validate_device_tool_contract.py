#!/usr/bin/env python3
"""Static contract checks for Gemini function declarations and Android native tools."""
from __future__ import annotations

import re
import sys
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
JS = ROOT / "app/src/main/assets/native-bridge.js"
ENGINE = ROOT / "app/src/main/java/com/allbat/assistant/PhoneActionEngine.kt"
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"
GRADLE = ROOT / "app/build.gradle.kts"
EXTRAS = ROOT / "app/src/main/java/com/allbat/assistant/DeviceExtras.kt"


def fail(message: str) -> None:
    print(f"DEVICE TOOL CONTRACT ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


js = JS.read_text(encoding="utf-8")
engine = ENGINE.read_text(encoding="utf-8")
manifest = ET.parse(MANIFEST).getroot()
gradle = GRADLE.read_text(encoding="utf-8").lower()

extras = EXTRAS.read_text(encoding="utf-8")
ocr_dispatchers = re.findall(r"(?m)^\s*fun ocrImageRequest\(\): ToolOutcome", extras)
if len(ocr_dispatchers) != 1:
    fail(f"DeviceExtras must define exactly one ocrImageRequest dispatcher; found {len(ocr_dispatchers)}")

js_start = js.find("const DEVICE_FUNCTION_DECLARATIONS = [")
if js_start < 0:
    fail("Gemini function declarations are missing")
js_end = js.find("\n  ];", js_start)
if js_end < 0:
    fail("Gemini function declaration array is not closed")
declarations = js[js_start:js_end]
declared = set(re.findall(r"\bname:\s*'([a-z_]+)'", declarations))

engine_start = engine.find("fun executeTool(")
engine_end = engine.find("fun requiredPermission(", engine_start)
if engine_start < 0 or engine_end < 0:
    fail("PhoneActionEngine.executeTool dispatch is missing")
dispatch = engine[engine_start:engine_end]
implemented = set(re.findall(r'"([a-z_]+)"\s*->', dispatch))
if not declared:
    fail("no function names found in JS declarations")
if declared != implemented:
    fail(f"JS/Android tool mismatch: declared-only={sorted(declared-implemented)}, android-only={sorted(implemented-declared)}")

required_permissions = {
    node.attrib.get("{http://schemas.android.com/apk/res/android}name")
    for node in manifest.findall("uses-permission")
}
for permission in ("android.permission.READ_CONTACTS", "android.permission.CALL_PHONE", "android.permission.SEND_SMS"):
    if permission not in required_permissions:
        fail(f"required manifest permission absent: {permission}")
if 'Intent.ACTION_CALL' not in engine:
    fail("direct ACTION_CALL implementation missing")
if "toolResponse: { functionResponses" not in js:
    fail("Live function response round-trip missing")
if "runOneShotDeviceAgent" not in js or "window.__allbatAssistantSend" not in js:
    fail("one-shot agent route for text/default-assistant input missing")
if "tools: [{ functionDeclarations: DEVICE_FUNCTION_DECLARATIONS }]" not in js:
    fail("text-mode one-shot agent does not expose native functions independently of Live UI setup")
if "openAppIntent" not in js or "newSession('text')" not in js:
    fail("text-mode device routing does not cover arbitrary launcher-app labels or the first Home-screen request")
if "sms_confirmation_required" not in engine or "sendConfirmedSms" not in engine:
    fail("SMS preview/confirmed-send split is missing")
permission_activity = (ROOT / "app/src/main/java/com/allbat/assistant/PhoneActionPermissionActivity.kt").read_text(encoding="utf-8")
if "smsFlowCompleted" not in permission_activity:
    fail("SMS permission activity must not overwrite a completed send result during onDestroy")
if "presentSmsConfirmationInAssistant" not in (ROOT / "app/src/main/java/com/allbat/assistant/AllBatVoiceInteractionSession.kt").read_text(encoding="utf-8"):
    fail("system-assistant SMS confirmation card is missing")
sms_view = (ROOT / "app/src/main/java/com/allbat/assistant/SmsPreviewView.kt").read_text(encoding="utf-8")
if 'text = "ویرایش"' not in sms_view or 'text = "ارسال"' not in sms_view or 'text("پیامک"' not in sms_view:
    fail("native SMS preview is missing its editable Send/Modify confirmation UI")
if "Intent.ACTION_SENDTO" in engine or "smsto:" in engine:
    fail("SMS tool must not open the messaging app; use the native confirmation view")
if "presentSmsConfirmation" not in (ROOT / "app/src/main/java/com/allbat/assistant/MainActivity.kt").read_text(encoding="utf-8"):
    fail("main-app SMS confirmation dialog is missing")

if "minsdk = 27" not in gradle:
    fail("minSdk must be 27 (Android 8.1)")
if "contact_choice_required" not in engine or "contact_choice_required" not in js:
    fail("ambiguous-contact choice flow is missing on the Android or JS side")
if "SessionServiceControl" not in (ROOT / "app/src/main/java/com/allbat/assistant/SessionServiceControl.kt").read_text(encoding="utf-8") or \
        "stopService" not in (ROOT / "app/src/main/java/com/allbat/assistant/SessionServiceControl.kt").read_text(encoding="utf-8"):
    fail("background-safe service stop fallback is missing")
if "releaseLiveResources" not in js or "__allBatSafeStop" not in js:
    fail("Live shutdown guard is missing")

for tool in ("close_app", "install_offline_speech"):
    if tool not in declared:
        fail(f"{tool} is not declared for Gemini")
manifest_text = MANIFEST.read_text(encoding="utf-8")
for permission in ("android.permission.KILL_BACKGROUND_PROCESSES", "android.permission.ACCESS_NETWORK_STATE"):
    if permission not in manifest_text:
        fail(f"manifest permission absent: {permission}")
offline_src = (ROOT / "app/src/main/java/com/allbat/assistant/OfflineSpeech.kt").read_text(encoding="utf-8")
if "vosk-android" not in GRADLE.read_text(encoding="utf-8") or "OfflineVoiceRecognizer" not in offline_src:
    fail("offline speech recognition (Vosk) is not wired into the build")
if "startOfflineCommandRecognition" not in (ROOT / "app/src/main/java/com/allbat/assistant/AllBatVoiceInteractionSession.kt").read_text(encoding="utf-8"):
    fail("assistant session does not use the offline recognizer")
if "parseOfflineDeviceCommand" not in js or "speakOffline" not in js:
    fail("offline command parser / offline speech output missing in the bridge")
# Online text commands covered by the strict local parser must execute before a new
# Gemini Live websocket is opened; otherwise simple calls incur a second model round-trip.
route_start = js.find("const runRoute = async () => {")
route_end = js.find("const intercept = event => {", route_start)
route = js[route_start:route_end] if route_start >= 0 and route_end > route_start else ""
if "const directCommands = parseOfflineDeviceCommand(textValue)" not in route or route.find("const directCommands = parseOfflineDeviceCommand(textValue)") > route.find("runOneShotDeviceAgent(textValue, chat)"):
    fail("online direct commands must use the local fast path before one-shot Gemini")
if "api('/api/live-save'" not in route or "runOfflineCommands(directCommands)" not in route:
    fail("online local device actions must execute through the native allow-list and persist their result")
permission_activity = (ROOT / "app/src/main/java/com/allbat/assistant/PhoneActionPermissionActivity.kt").read_text(encoding="utf-8")
if "continueWithPermission()" not in permission_activity[permission_activity.find("override fun onRequestPermissionsResult"):]:
    fail("staged device-tool permissions must be re-evaluated after each grant")
awaiter = (ROOT / "app/src/main/java/com/allbat/assistant/DeviceToolAwaiter.kt").read_text(encoding="utf-8")
if "completed.compareAndSet(false, true)" not in awaiter:
    fail("device-tool results must be completed only once")
if '"cancelled", true' not in permission_activity or "isFinishing" not in permission_activity:
    fail("dismissing the permission Activity must release a waiting device-tool call")
if "Manifest.permission.CALL_PHONE" not in engine or "READ_CONTACTS" not in engine:
    fail("contact calling must keep explicit contacts and call permissions")

NEW_TOOLS = ("navigate_to", "web_search", "share_text", "media_control", "set_ringer_mode", "device_status", "get_datetime",
             "create_calendar_event", "list_calendar_events", "save_note", "list_notes", "search_notes",
             "open_document", "share_document", "add_contact", "find_phone", "read_sms", "screen_control", "read_notifications",
             "read_screen_text", "ocr_image", "set_display_settings", "set_do_not_disturb", "battery_analysis")
for tool in NEW_TOOLS:
    if tool not in declared:
        fail(f"{tool} is not declared for Gemini")
for service in ("AllBatAccessibilityService", "AllBatNotificationListener"):
    if service not in manifest_text:
        fail(f"{service} is not registered in the manifest")
if "android.permission.READ_SMS" not in manifest_text:
    fail("READ_SMS permission is missing for read_sms")
extras_src = (ROOT / "app/src/main/java/com/allbat/assistant/DeviceExtras.kt").read_text(encoding="utf-8")
if "android.permission.READ_CALENDAR" not in manifest_text or "Manifest.permission.READ_CALENDAR" not in extras_src:
    fail("calendar reading must use the explicit READ_CALENDAR runtime permission")
notes_src = (ROOT / "app/src/main/java/com/allbat/assistant/LocalNotesStore.kt").read_text(encoding="utf-8")
if "SQLiteOpenHelper" not in notes_src or "allbat_local_notes.db" not in notes_src:
    fail("local notes must be persisted in the app-private SQLite database")
document_activity = (ROOT / "app/src/main/java/com/allbat/assistant/DeviceDocumentPickerActivity.kt").read_text(encoding="utf-8")
main_activity = (ROOT / "app/src/main/java/com/allbat/assistant/MainActivity.kt").read_text(encoding="utf-8")
voice_session = (ROOT / "app/src/main/java/com/allbat/assistant/AllBatVoiceInteractionSession.kt").read_text(encoding="utf-8")
if "document_picker_required" not in extras_src or "ACTION_OPEN_DOCUMENT" not in document_activity:
    fail("file access must use the Android Storage Access Framework picker")
if "DeviceDocumentPickerActivity.createIntent" not in main_activity or "DeviceDocumentPickerActivity.createIntent" not in voice_session:
    fail("document picking must be available from both the app and system assistant surfaces")
if "READ_EXTERNAL_STORAGE" in manifest_text or "MANAGE_EXTERNAL_STORAGE" in manifest_text:
    fail("do not add broad storage permissions for the SAF file picker")
# Round 2: explicit OCR, visible-screen read, display controls, DND, battery analysis.
if "com.google.mlkit:text-recognition:16.0.1" not in GRADLE.read_text(encoding="utf-8"):
    fail("bundled on-device OCR dependency is missing")
if "recognizeImage" not in document_activity or "TextRecognition.getClient" not in document_activity:
    fail("user-selected image OCR is not implemented in the document picker")
if "readVisibleText" not in (ROOT / "app/src/main/java/com/allbat/assistant/AllBatAccessibilityService.kt").read_text(encoding="utf-8"):
    fail("explicit active-window text extraction is missing")
for permission in ("android.permission.WRITE_SETTINGS", "android.permission.ACCESS_NOTIFICATION_POLICY"):
    if permission not in manifest_text:
        fail(f"special settings permission absent: {permission}")
if "Settings.System.canWrite(context)" not in extras_src or "ACTION_MANAGE_WRITE_SETTINGS" not in extras_src:
    fail("display changes must be gated by the Android special access screen")
if "isNotificationPolicyAccessGranted" not in extras_src or "ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS" not in extras_src:
    fail("DND changes must be gated by Android notification-policy access")
if "batteryAnalysis" not in extras_src or "isPowerSaveMode" not in extras_src:
    fail("read-only battery analysis is incomplete")
if "facingMode: { exact: 'environment' }" not in js or "facingMode: { ideal: 'environment' }" in js:
    fail("Live camera must require the rear-facing camera, not only prefer it")
# Round 3: assistant animations and a real response-cancel control separate from Live hang-up.
voice_session = (ROOT / "app/src/main/java/com/allbat/assistant/AllBatVoiceInteractionSession.kt").read_text(encoding="utf-8")
floating_overlay = (ROOT / "app/src/main/java/com/allbat/assistant/FloatingAssistantOverlay.kt").read_text(encoding="utf-8")
if "dockStopResponseButton" not in voice_session or "stopCurrentResponse()" not in voice_session:
    fail("system assistant dock must expose a separate stop-response button")
if "fun setPanelText(text: String?, thinking: Boolean, generating: Boolean)" not in voice_session:
    fail("native assistant must receive the generating state independently of the thinking indicator")
if "window.__allbatStopCurrentResponse" not in js or "sendButton.classList.contains('stopmode')" not in js:
    fail("text response stop must invoke the page's stop-mode control")
if "ACTION_STOP_RESPONSE" not in floating_overlay or 'setKind(if (lastState.generating) "stop" else "arrow")' not in floating_overlay:
    fail("floating assistant stop-response control must update dynamically while generating")
if "allbatMessageIn" not in js or "allbatPanelIn" not in js or "PathInterpolator" not in voice_session:
    fail("smooth assistant panel and message animations are missing")
voice_session_path = ROOT / "app/src/main/java/com/allbat/assistant/AllBatVoiceInteractionSession.kt"
voice_session = voice_session_path.read_text(encoding="utf-8")
if "dockCropButton" in voice_session or "selectRegionFromDock" in voice_session:
    fail("the old dock crop button must be removed")
if (ROOT / "app/src/main/res/drawable/ic_assistant_crop.xml").exists():
    fail("the unused old dock crop icon must be removed")
if "ic_assistant_mic" not in voice_session or "startCommandSpeechRecognition(forDictation = true)" not in voice_session:
    fail("assistant dock microphone must start speech-to-text dictation")
if "private fun stopCommandSpeechRecognition()" not in voice_session:
    fail("dictation must have a defined recognizer stop path")
if "createScreenSelectionGestureLayer()" not in voice_session or "__allbatAssistantStartRegionSelection($rect)" not in voice_session:
    fail("screen-region selection must start directly from an on-screen swipe")
if "EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS" not in engine or "EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS" not in engine:
    fail("speech recognition must use bounded end-of-speech windows")
if "allbat-panel-region" in js or "applyInitialRect" not in js:
    fail("region selection must not require a dock button and must accept the swipe rectangle")
if 'versionName = "1.7.9"' not in GRADLE.read_text(encoding="utf-8"):
    fail("All Bat Gemini 4 Hydrogen update must use versionName 1.7.9")
for marker in ("contactSearchVariants", "contactNameMatches", "contactNameAliasGroups", "محمدی", "rezaei", "ali"):
    if marker not in engine:
        fail(f"bilingual contact matching is missing: {marker}")
for marker in ("Intent.ACTION_POWER_USAGE_SUMMARY", "Settings.ACTION_INTERNAL_STORAGE_SETTINGS", "Settings.ACTION_LOCATION_SOURCE_SETTINGS", "Settings.ACTION_ALL_APPS_NOTIFICATION_SETTINGS", "Settings.ACTION_ACCESSIBILITY_SETTINGS"):
    if marker not in engine:
        fail(f"direct settings navigation is missing: {marker}")
for marker in ("settingSections", "'battery'", "'storage'", "'location'", "'notifications'"):
    if marker not in js:
        fail(f"fast settings-command parser is missing: {marker}")
if "Rear camera is unavailable; selfie fallback is disabled." not in js:
    fail("Live camera must refuse a silent selfie-camera fallback")
gradle_text = GRADLE.read_text(encoding="utf-8")
if "signingConfigs" not in gradle_text or 'getByName("update")' not in gradle_text:
    fail("fixed signing config is missing; builds could not update the installed app")
# The signing key must come from GitHub Secrets / keystore.properties; a key or password in the repository is a leak.
if any(ROOT.glob("app/keystore/*.p12")) or any(ROOT.glob("**/*.jks")):
    fail("a signing key is committed in the repository; move it to GitHub Secrets (see SECURITY.md)")
_gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
if "storePassword = \"" in _gradle or "?: \"pzYQ" in _gradle:
    fail("a keystore password is hard-coded in app/build.gradle.kts")

if 'supportsLaunchVoiceAssistFromKeyguard="true"' not in (ROOT / "app/src/main/res/xml/voice_interaction_service.xml").read_text(encoding="utf-8"):
    fail("the assistant must be launchable from the lock screen")
if "safeWhenLocked" not in engine or "isPhoneLocked" not in engine:
    fail("sensitive tools must be blocked while the phone is locked")

for forbidden in ("com.google.android.gms", "play-services", "firebase-messaging"):
    if forbidden in gradle:
        fail(f"unexpected Google Play Services dependency detected: {forbidden}")

print("Device tool contract: OK")
print("Declared tools:", ", ".join(sorted(declared)))
print("Direct call permissions and model tool-response paths: OK")
